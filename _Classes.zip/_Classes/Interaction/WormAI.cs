﻿using UnityEngine;

public class WormAI : InteractionScript {

	public AudioClip moveSound;
	SpriteRenderer mySpr;
	public Wormy worm;

	public GameObject wormInfo;
	public GameObject worm_egg;
	public float speed = 4f;
	Rigidbody myRB;
	public string myname = "Unknown Worm";

	//worm will periodically seek a target to consume
	bool check = false;
	bool laid_egg = false;
	Vector3 target;
	Rot targetRot;
	Flower targetFlower;
	Rot[] rot;
	//public int things_eaten = 0;

	//worms move by teleporting periodically
	float jump_time, j_timer; //how soon they move
	float fade_time, f_timer; //animation timer
	int moveState = 0; //normal, fade out, fade in

	public bool isNameable;

	public void Set(Wormy ws){
		myname = ws.name;
		worm = ws;
		laid_egg = ws.laid_egg;
		Debug.Log(worm.hunger + "WORM HUNGER");
		UpdateMyEnvironment();
		if(ws.name != "Unnamed Worm") isNameable = false;
		else isNameable = true;
	}

	void Start(){
		Debug.Log("JUMP TIME" + jump_time);
		mySpr = GetComponentInChildren<SpriteRenderer>();
		myRB = GetComponent<Rigidbody>();
		moveState = 0;
		jump_time = j_timer = 4f;
		fade_time = f_timer = 0.5f;
	}

	public void NameMe(string n){
		worm.name = n;
		myname = n;
		isNameable = false;
	}

	public override void OnInteract(){
		GlobalStateMachine.GPause();
		GameObject.Instantiate(wormInfo, GameObject.Find("UI").transform).GetComponent<WormUI>().Set(this);
	}


	public override string LabelDesc(){
		return myname;
	} 
	public void UpdateMyEnvironment(){
		//create a soil buddy if full
		/*
		if (worm.hunger <= 0){
			GameObject sb = Prefabber.me.GetFromName("Soil Buddy");
			sb = GameObject.Instantiate(sb, Zone.currentZone.addedPrefabs.transform);
			sb.gameObject.name = "Soil Buddy";
			sb.transform.position = transform.position;
		}
		*/
		target = transform.position;
		LookForRot();

	}
	public void AdvanceTime(){
		bait[] baits = Zone.currentZone.GetComponentsInChildren<bait>();
		if(baits != null)
			foreach(bait b in baits){
				if(!b.taken){
					transform.position = b.transform.position;
					b.taken = true;
					GameObject.Destroy(b.gameObject);
				}
			}
		target = transform.position;
	}
	void LookForRot(){
		if (worm.hunger <= 0){
			
			if(laid_egg == false && worm.age >= 7){
				FloatingTextSpawner.SpawnText("Oof", Color.green, transform);

				GameObject g = GameObject.Instantiate(worm_egg, Zone.currentSubZone.addedPrefabs.transform);
				g.transform.position = transform.position;
				laid_egg = worm.laid_egg = true;
				Debug.Log("LAID EGG ALERT");
			}

			return;
		}
		rot = Environment.me.GetComponentsInChildren<Rot>();
		float d = 100f;
		//Debug.Log("LOOKG FOR ROT AMT " + rot.Length);
		for(int i = 0; i < rot.Length ; i++){
			if (Vector3.Distance(rot[i].transform.position, transform.position) < d && rot[i].fading == false){
				target = rot[i].transform.position;
				targetRot = rot[i];
				d = Vector3.Distance(rot[i].transform.position, transform.position);
			}
		}
		if(targetRot == null){
			Flower[] ffs = Zone.currentZone.GetComponentsInChildren<Flower>();
			float n = 100f;
			foreach(Flower ff in ffs){
				float nn = Vector3.Distance(transform.position, ff.transform.position);
				if(ff.GetState() == Growable.G.withered && nn < n){
					n = nn;
					targetFlower = ff;
					target = ff.transform.position;
				}
			}
		}
	}
	void Update(){
		
		if (check == false && worm.hunger > 0){
			LookForRot();
			check = true;
		}
	}

	void Eat(){

		worm.hunger--;
		check = false;
		worm.age++;
		if (worm.hunger <= 0)
			FloatingTextSpawner.SpawnText("I am full...", Color.green, transform);
	}
	void FixedUpdate(){
		if(worm == null) Debug.Log("MISSING WOROROORM");
		if (target == null || Vector3.Distance(target ,transform.position) < 1f){
			if (targetRot != null){
				targetRot.fading = true;
				targetRot = null;
				FloatingTextSpawner.SpawnText("Yum!", Color.green, transform);
				Eat();
			}
			if (targetFlower != null){
				targetFlower.gameObject.AddComponent<DeathAnimator>();
				targetFlower = null;
				FloatingTextSpawner.SpawnText("Yum!", Color.green, transform);
				Eat();
			}
			LookForRot();
			target = new Vector3((Random.value-0.5f)*12, 0f, (Random.value-0.5f)*12);
		}
		else if (GlobalStateMachine.paused == false){
			if (j_timer > 0f){
				
				Jump();
				j_timer -= Time.deltaTime;
			}
			else{
				check = false;
				moveState = 0;
				j_timer = jump_time;
			}
		}
	}

	void Jump(){
		if (moveState == 0){
			moveState = 1;
			f_timer = fade_time;
		}
		if (moveState == 1){
			f_timer -= Time.deltaTime;
			float alphaAmt = f_timer / fade_time;
			if (alphaAmt < 0f) alphaAmt = 0f;
			mySpr.color = new Color(1f, 1f, 1f, alphaAmt);
			if (alphaAmt == 0f){
				MoveToTarget();
			}
		}
		else if (moveState == 2)
		{
			f_timer += Time.deltaTime;
			if (f_timer > fade_time) f_timer = fade_time;
			float alphaAmt = f_timer / fade_time;
			mySpr.color = new Color(1f, 1f, 1f, alphaAmt);
		}
	}

	void MoveToTarget(){
		LocalSfx.PlayFx(transform, moveSound, false);
		//Debug.Log("JMUPJMPUJMPUJMPUJMPU~");
		if(worm.hunger > 0){
			//Debug.Log("worm " + worm.hunger);
			FloatingTextSpawner.SpawnText("hungry~", Color.green, transform);
		}
		myRB.position =
		Vector3.MoveTowards(transform.position, target, speed);

		if (target.x < transform.position.x) mySpr.flipX = true;
		else mySpr.flipX = false;

		moveState = 2;
	}

}
