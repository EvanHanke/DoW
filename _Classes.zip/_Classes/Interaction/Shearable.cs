﻿using UnityEngine;

public class Shearable : AltInteractionScript {

	public Item shearableItem;
	public int bounty; //number of times this object can be sheared

	public override char IsValid(){
		
		if (PlayerStats.getCEquip() != null){
			//Debug.Log(PlayerStats.getCEquip().whatami);
			if (PlayerStats.getCEquip().whatami is GardeningShears){

				return 'c';
				}
		}
		if (PlayerStats.getXEquip() != null){
			
			if (PlayerStats.getXEquip().whatami is GardeningShears){
				return 'x';
			}
		}
		return ' ';
	}

	public override void OnInteract(){
		if (bounty > 0){
			PlayerController.me.AcquireItem(shearableItem, bounty, 0, "snip1");
			bounty = 0;
		}
		else{
			PushMessage.Push("There is nothing to harvest");
		}
	}


	public override string Label(){return "Shear plant";}
}
