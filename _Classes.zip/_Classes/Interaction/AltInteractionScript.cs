﻿
using UnityEngine;

public class AltInteractionScript : MonoBehaviour {

	public UsableItem requiredItem;
	public virtual void OnInteract(){}
	public virtual string Label(){return "";}


	//check if the player has the required item equipped
	public virtual char IsValid(){
		return ' ';
	}

}
