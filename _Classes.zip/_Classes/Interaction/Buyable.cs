﻿using UnityEngine;

public class Buyable : InteractionScript {


	public Item tradeWithItem;
	public Item takeItem;
	public int giveAmt;
	public int takeAmt;


	ItemBuyer ib;
	GameObject prefab;
	GameObject active;
	bool a = false;

	public override void OnInteract(){
		GameObject go = GameObject.Instantiate(ui.buySellItemPrefab, ui.transform, false);
		go.AddComponent<ItemBuyer>().Set(go, tradeWithItem, takeItem, giveAmt, takeAmt);
		ui.RemoveLabel();
		active = go;
		a = true;
	}

	public void Update(){
		if (active == null && GlobalStateMachine.paused && a){
			GetComponentInParent<GlobalStateMachine>().Unpause();
			a = false;
		}
	}

	public override string LabelDesc(){
		return "Trade for " + takeItem.name;
	}

	public override void OnLeave(){
		ui.RemoveLabel();
	}

}
