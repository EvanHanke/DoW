﻿using UnityEngine;

[System.Serializable]
public class Line{
	[TextArea(0,3)]
	public string message;
	public Branch[] branches;
	public DialogueEvent dEvent;
	[HideInInspector]
	public Dialogue myDiag;


	public void CheckBranches(){
		foreach(Branch b in branches){
			b.choiceEvent.myDialogue = myDiag;
			b.CheckAlts();
		}
	}
}

[System.Serializable]
public class Branch{
	public string text;
	public int pointer;
	public AltBranch alternate;
	public DialogueEvent choiceEvent;

	public void CheckAlts(){
		AltBranch b = alternate;
		if (b.check.Check()){
			text = b.text;
			pointer = b.pointer;
		}
	}
}
[System.Serializable]
public class AltBranch{
	public CheckCondition check;
	public string text;
	public int pointer;
}

public class Dialogue : InteractionScript {
	/*
	 * Attach to a game object to create an interactable dialogue
	 * 
	 */ 

	TextBox textBox; //controls the visualization of the UI element
	public DialogueBox dBox; //controls the logic of input and 

	public string dName; //name of this dialogue to distinguish from other dialogues
	public Line[] msg;

	public override void OnInteract(){
		for (int i = 0; i < msg.Length;i++){
			Line l = msg[i];
			l.dEvent.myDialogue = this;
			l.myDiag = this;
			l.CheckBranches();
		}

		GetComponentInParent<GlobalStateMachine>().Pause();
		dBox = new DialogueBox(msg, ui);
		dBox.Launch();
	}


	void Update(){
		if (dBox == null) return;
		if (dBox.Loop()){
			GetComponentInParent<GlobalStateMachine>().Unpause();
			dBox = null;
		}
	}

}
