﻿using UnityEngine;

public class ViroTransform : MonoBehaviour {

	public GameObject transform_into;
	public int threshold = 0;
	public bool below = false;

	public void Check(LocalGrowArea lga){
		if(lga.CheckContained(transform.position)){
			if( (lga.area_health > threshold) == !below ){
				GameObject new_g = GameObject.Instantiate(transform_into, transform.position, 
					Quaternion.identity, transform.parent);
				GameObject.Destroy(gameObject);
			}
		}
	}
}
