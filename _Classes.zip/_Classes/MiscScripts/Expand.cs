﻿using UnityEngine;

public class Expand : MonoBehaviour {

	public float time;
	public float magnitude;

	public void Update(){
		if(GlobalStateMachine.paused == false){
			transform.localScale += Vector3.one*magnitude*Time.deltaTime;
			time -= Time.deltaTime;
			if(time <= 0f){
				GameObject.Destroy(gameObject);
			}
		}
	}
}
