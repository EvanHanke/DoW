﻿using UnityEngine;

public class ViroThresh : MonoBehaviour {

	public int threshold;
	public bool negative_thresh = false;

	public static void CheckAll(){
		ViroThresh[] vs = Zone.currentZone.GetComponentsInChildren<ViroThresh>(true);
		foreach(ViroThresh vt in vs){
			vt.Check();
		}
	}

	void Check(){
		int vi = Environment.me.GetCurrentHealth();
		//Debug.Log("CHECKING " + vi);
		if(!negative_thresh){
			if (vi < threshold && threshold >= 0){
				gameObject.SetActive(false);
			}
			else if (threshold < 0 && vi < threshold){
				gameObject.SetActive(false);
			}
			else{
				gameObject.SetActive(true);
			}
		}
		else{
			if (vi < threshold){
				gameObject.SetActive(false);
			}
			else{
				gameObject.SetActive(true);
			}
		}
	}

}
