﻿using UnityEngine;

public class EvaporatingText : MonoBehaviour {

	TextMesh text;
	SpriteRenderer back;

	float startTime;
	float lifeTime = 2;

	void Awake () {
		startTime = Time.time;
		text = GetComponent<TextMesh>();
		back = GetComponentInChildren<SpriteRenderer>();
	}

	void Update () {
		text.transform.position += new Vector3(0, 1f * Time.deltaTime, 0);
		if (Time.time > startTime+lifeTime){
			GameObject.Destroy(gameObject);
		}
	}
}
