﻿using UnityEngine;

public class Respawner : MonoBehaviour {

	//Respawn an object which falls out of bounds
	Vector3 myPos;
	Rigidbody myRB;


	void Start(){
		myPos = transform.position;
		myRB = GetComponent<Rigidbody>();
	}

	void Update () {
		if (transform.position.y < Zone.currentZone.lowerBound){
			myRB.velocity = Vector3.zero;
			transform.position = myPos;
		}
	}

	void OnCollisionEnter(Collision c){
		if (c.collider.gameObject.tag == "Respawn"){
			myRB.velocity = Vector3.zero;
			transform.position = myPos;
		}
	}
}
