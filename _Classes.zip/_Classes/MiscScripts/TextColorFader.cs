﻿using UnityEngine;
using UnityEngine.UI;

public class TextColorFader : MonoBehaviour {

	Text myText;
	public Color a, b;
	public float fade_time;
	float timer;
	float direction = 1f;

	void OnEnable () {
		myText = GetComponent<Text>();
		timer = 0;
	}
		
	void Update () {
		if (timer + Time.deltaTime > fade_time && direction == 1f){
			direction = -1f;
		}
		else if (timer - Time.deltaTime < 0f && direction == -1f){
			direction = 1f;
		}

		timer += direction * Time.deltaTime;

		myText.color = Color.Lerp(a, b, timer / fade_time);
	}
}
