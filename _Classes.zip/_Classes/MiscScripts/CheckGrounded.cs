﻿using UnityEngine;

public class CheckGrounded{

	public static bool Check(Vector3 pos){
		if (Physics.Raycast(new Ray(pos, Vector3.down), 1f)){
			return true;
		}
		else return false;
	
	}

	public static bool Check(Vector3 pos, BoxCollider bc){
		RaycastHit[] hits;
		hits = Physics.BoxCastAll(pos+bc.center, bc.bounds.extents, Vector3.down, bc.transform.rotation, bc.bounds.extents.y+0.1f);
		if(hits!=null){
			foreach(RaycastHit hit in hits){
				if(hit.collider.name != bc.name){
					//Debug.Log(bc.name + "hit" + hit.collider.gameObject.name);
					return true;
				}
				else{
					//Debug.Log("hit self");
					return false;
				}
			}
		}
		return false;

	}

	public static Vector3 Check1(Vector3 pos, BoxCollider bc){
		RaycastHit[] hits;
		hits = Physics.BoxCastAll(bc.bounds.center, 
			bc.bounds.extents, 
			Vector3.down, 
			bc.transform.rotation,
			bc.bounds.extents.y+0.1f);
		if(hits!=null){
			foreach(RaycastHit hit in hits){
				if(hit.collider.name != bc.name && hit.collider.bounds.center.y+hit.collider.bounds.extents.y <= pos.y){
					//Debug.Log(bc.name + "hit" + hit.collider.gameObject.name);
					return hit.normal;
				}
				else{
					//Debug.Log("hit self");
					return Vector3.zero;
				}
			}
		}
		return Vector3.zero;

	}
}
