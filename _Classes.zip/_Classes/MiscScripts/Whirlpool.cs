﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Whirlpool : MonoBehaviour {

	public GameObject wavePrefab;
	List<GameObject> waves;
	List<GameObject> toremove;
	GameObject player;

	float timer;
	public float radius = 8f;

	void Start(){
		waves = new List<GameObject>();
		toremove = new List<GameObject>();
		player = GameObject.Find("Boat");
		SpawnCircle();
	}

	public void SpawnCircle(){
		for(int i = 0; i < 8; i++){
			GameObject wave = GameObject.Instantiate(wavePrefab, transform);
			Vector3 pos = new Vector3(Mathf.Sin(Mathf.PI*2f*((float) i / 8f))*radius, .5f,
				Mathf.Cos(Mathf.PI*2f*((float) i / 8f))*radius );
			wave.transform.position = transform.position + pos;

			wave.transform.LookAt(transform.position);

			waves.Add(wave);
			//Debug.Log(waves.Count);
		}


		for(int i = 0; i < toremove.Count; i++){
			GameObject.Destroy(toremove[i]);
		}
		toremove.Clear();

		timer = 3f;
	}

	public void FixedUpdate(){
		timer -= Time.deltaTime;

		foreach(GameObject g in waves){
			if(g!=null){
				g.transform.position = Vector3.MoveTowards(g.transform.position, transform.position, Time.deltaTime);
				if(Vector3.Distance( g.transform.position , transform.position) < 0.1f){
					toremove.Add(g);
				}
			}
		}

		if(timer < 0f){
			SpawnCircle();
		}


		if(player != null)
		if(Vector3.Distance(player.transform.position, transform.position) < radius){
			float py = player.transform.position.y;
			player.transform.position = Vector3.MoveTowards(player.transform.position, transform.position, Time.deltaTime * 2f);
		}

	}

}
