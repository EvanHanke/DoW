﻿using UnityEngine;

public class PressF : MonoBehaviour {

	public GameObject spawn;
	public Vector3 spawn_offset;
	bool spawned;
	public AudioClip audio;

	void Start(){
		spawned = false;
	}
	void Update(){
		if(Input.GetKeyDown(KeyCode.F)){
			if(spawned == false){
				if(Vector3.Distance(transform.position, PlayerController.me.transform.position) < 4f){
					LocalSfx.PlayFx(transform, audio, false, 0.4f, 0.5f);
					GameObject a = GameObject.Instantiate(spawn, transform.parent);
					a.transform.position = transform.position + spawn_offset;
					spawned = true;

				}
			}
		}
	}
}
