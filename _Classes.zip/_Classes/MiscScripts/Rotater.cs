﻿using UnityEngine;

public class Rotater : MonoBehaviour {

	public float xSpeed = 1;
	public float ySpeed = 1;
	public float zSpeed = 1;

	void Update(){
		transform.Rotate(Time.deltaTime * xSpeed, Time.deltaTime * ySpeed , Time.deltaTime * zSpeed);
	}
}
