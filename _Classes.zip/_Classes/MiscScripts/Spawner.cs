﻿using UnityEngine;

public class Spawner : MonoBehaviour {
	public GameObject prefab;
	public CheckCondition condition;
	public bool respawn;
	bool spawned = false;

	StateSaver s;
	void Awake(){
		s = gameObject.AddComponent<StateSaver>();
		s.onInit = Check;
		Invoke("Kill", 0.1f);
	}

	public void Load(){
		
		spawned = (s.my_state == 1);
		Check();

	}

	void Kill(){
		GameObject.Destroy(gameObject);
	}

	public void Check(){
		
		if(condition == null || condition.target_name.Length == 0 || condition.Check())
		if(!spawned){
			GameObject o = GameObject.Instantiate(prefab, Zone.currentSubZone.addedPrefabs.transform, true);
				o.transform.position = transform.position;
				o.transform.localScale =transform.localScale;
				s.my_state  =1;
			}

	}
}
