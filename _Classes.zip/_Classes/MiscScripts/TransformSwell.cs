﻿using UnityEngine;

public class TransformSwell : MonoBehaviour {

	public float scaleXmax, scaleXmin;
	public float scaleYmax, scaleYmin;
	public float speedMod;

	void FixedUpdate () {
		transform.localScale = new Vector3(Mathf.Abs((Mathf.Sin(Time.time) * scaleXmax)) + scaleXmin, Mathf.Abs((Mathf.Sin(Time.time)) * scaleYmax) + scaleYmin, 0);
	}
}
