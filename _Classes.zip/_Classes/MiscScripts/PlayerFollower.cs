﻿
using UnityEngine;

public class PlayerFollower : MonoBehaviour {
	Vector3 offset;

	Transform player;

	void Start(){
		player = GameObject.Find("Player").transform;
		offset = transform.position - player.position;
	}
	void Update(){
		transform.position = player.position + offset;
	}

}
