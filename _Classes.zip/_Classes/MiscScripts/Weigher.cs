﻿using UnityEngine;

public class Weigher : MonoBehaviour {

	float timer = 5f;

	void Awake(){
		timer = 5f;
	}

	void Update(){
		if(timer > 0f){
			PlayerMovement.me.input_paused = true;
			timer -= Time.deltaTime;
		}
		else{
			Debug.Log("trigger");
			GetComponent<Interactable>().OnInteract();
			GameObject.Destroy(this);
		}
	}
}
