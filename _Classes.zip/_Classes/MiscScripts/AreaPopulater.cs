﻿using UnityEngine;

public class AreaPopulater : MonoBehaviour {

	//disperses gameobjects over a zone

	public int seed = 0;
	public MyWorldObj[] worldObjs;
	public bool instantiated = false;

	public float xRange = 1;
	public float zRange = 1;
	public float density = 0;

	public bool OnSurfaceOnly = false;

	GameObject last;

	StateSaver ss;

	void Awake(){
		ss = gameObject.AddComponent<StateSaver>();
		ss.onInit = OnInit;
		ss.onLoad = OnLoad;
	}

	void OnLoad(){
		instantiated = (ss.my_state == 1);
		Debug.Log("loaded " + instantiated);
	}

	void OnInit(){
		Debug.Log("Init");
		Invoke("Spawn", 0.1f);
	}

	void Spawn () {
		Debug.Log("SPAWN SPAWN SPAWN");
		if (worldObjs != null && instantiated == false){
			Random.InitState(seed);
			foreach(MyWorldObj mwo in worldObjs){
				for(int i = 0 ; i < mwo.number ; i++){
					Populate(mwo.prefab, mwo);
				}
			}
			instantiated = true;
			ss.my_state = 1;
		}
	}

	void Populate(GameObject go, MyWorldObj mwo){
		bool valid = false;
		int safety = 3;
		Vector3 pos = transform.position;
		do{
			float x = Random.Range(-xRange, xRange);
			float z = Random.Range(-zRange, zRange);
			pos = (transform.position + new Vector3(x, 0, z));

			if(OnSurfaceOnly){
				RaycastHit[] hit;
				hit = Physics.RaycastAll(pos+Vector3.up, Vector3.down);
				if(hit!=null && hit.Length > 0){
					Vector3 highest = Vector3.down*100f;
					foreach(RaycastHit h in hit){
						if(h.collider.GetComponent<Damager>() == null && h.point.y > highest.y) highest = h.point;
					}
					if(highest != Vector3.down*100f){
						pos = highest;
						valid = true;
					}
				}
				else valid = false;
			}
			else{
				valid = true;
			}
			safety--;
		}
		while(safety > 0 && !valid);

		if(safety == 0) return;

		GameObject newGo = GameObject.Instantiate(go);
		newGo.transform.position = pos;
		newGo.transform.SetParent(Zone.currentSubZone.addedPrefabs.transform);
		StateSaver s = newGo.GetComponent<StateSaver>();

		if (s != null){
			s.my_state = mwo.state;
			s.onLoad();
		}

	}
	
	void OnDrawGizmos () {
		//UnityEditor.Handles.Label(transform.position, name);
		Gizmos.DrawWireCube(transform.position, new Vector3(xRange*2, 1f, zRange*2));
	}


}

[System.Serializable]
public class MyWorldObj{
	public GameObject prefab;
	public int number;
	public int state;
}