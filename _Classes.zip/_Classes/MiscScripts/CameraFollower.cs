﻿using UnityEngine;

public class CameraFollower : MonoBehaviour {

	public static CameraFollower me;
	public GameObject leader;
	public Skybox skybox;

	Vector3 startPos;
	Vector3 zoneOffest = Vector3.zero;
	Vector3 startTilt;
	Vector3 zoneTilt = Vector3.zero;
	Vector3 vecDif;

	Vector3 shownOffset, shownTilt;

	Vector3 dialogueOffest, dialogueTilt;

	Vector3 leaderPos{
		get{
			return leader.transform.position;
		}
	}
		
	float shakeTimer =0f;
	float mag = 20f;

	public void SetLine(Line2 line){
		if(line == null){
			dialogueOffest = dialogueTilt = Vector3.zero;
		}
		else{
			dialogueOffest = line.cameraOffset;
			dialogueTilt = line.cameraTilt;
		}
	}

	void Awake () {
		skybox = GetComponent<Skybox>();
		shownOffset = startPos = transform.position;
		shownTilt = startTilt = transform.eulerAngles;
		if(gameObject.tag == "MainCamera")
			me = this;
		Debug.Log("camera is followed");
		//vecDif = new Vector3(0f, 5f, -8.5f);
		vecDif = new Vector3(startPos.x - leaderPos.x, startPos.y - leaderPos.y, startPos.z - leaderPos.z) ;

		dialogueOffest = dialogueTilt = Vector3.zero;
	}

	void Start(){
		ZoneUpdate(Zone.currentSubZone);
	}

	void FixedUpdate () {
		
		float speed = Time.deltaTime * 4f;
		Vector3 target = startTilt + Zone.currentSubZone.cameraTilt + dialogueTilt;
		if(shownTilt != target){
			float t = Vector3.Distance(target, shownTilt);
			speed += t / 20f;
			shownTilt = Vector3.MoveTowards(shownTilt, target, speed);
		}
		if(Zone.currentSubZone.staticCamera == false)
			target = leaderPos + Zone.currentSubZone.cameraOffest + vecDif + dialogueOffest;
		else
			target = Zone.currentSubZone.cameraOffest + vecDif + dialogueOffest;
		if(transform.position != target ){
			float d = Vector3.Distance(target, transform.position);
			speed += d / 20f;
			transform.position = Vector3.MoveTowards(transform.position, target, speed);
		}
		transform.eulerAngles = shownTilt;
		//transform.position = target;

		if (shakeTimer > 0){
			Random.InitState((int)(Time.time*50f));
			transform.position += new Vector3((Random.value-0.5f)*mag, (Random.value-0.5f)*mag, (Random.value-0.5f)*mag);
			shakeTimer -= Time.deltaTime;
		}

	}

	public void Shake(float magnitude, float duration){
		shakeTimer = duration;
		mag = magnitude;
	}

	public void ZoneUpdate(Zone zone){
		Debug.Log("ZONE UPDATED");
		GetComponent<Camera>().backgroundColor = zone.backgroundColor;
		zoneOffest = zone.cameraOffest;
		zoneTilt = zone.cameraTilt;

		transform.position = new Vector3(leaderPos.x, 
			leaderPos.y, 
			leaderPos.z);

		Material sky = zone.skybox_mat;
		if(sky!=null){
			GetComponent<Camera>().clearFlags = CameraClearFlags.Skybox;
			skybox.material = sky;
		}
		else{
			GetComponent<Camera>().clearFlags = CameraClearFlags.SolidColor;
		}
	}
}
