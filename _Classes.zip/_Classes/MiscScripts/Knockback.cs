﻿using UnityEngine;

public class Knockback : MonoBehaviour {

	PlayerMovement pm;
	Entity e;
	float timer;
	Rigidbody myRB;
	Vector3 dir;
	float mag;

	public void Set(Vector3 direction, float amount){
		pm = GetComponent<PlayerMovement>();
		e = GetComponent<Entity>();
		myRB = GetComponent<Rigidbody>();
		dir = direction;
		mag = amount;
		if (pm != null){
			pm.ground = null;
			pm.enabled = false;
		}
		if(e != null){
			GroundFollower gf = e.GetComponent<GroundFollower>();
			if(gf!=null)
				gf.ground = null;
			e.knocked = true;
		}
		timer = 0.5f;

		//myRB.AddForce(dir*mag*Time.deltaTime*amount, ForceMode.VelocityChange);
	}

	public void FixedUpdate(){
		
		if(GlobalStateMachine.paused == false){
			timer -= Time.deltaTime;
			//Vector3 newPos = transform.position + (dir*mag*Time.deltaTime);
			myRB.MovePosition( transform.position + dir*mag*Time.deltaTime);
			//myRB.MovePosition(newPos);
			if(timer <= 0f){
				GameObject.Destroy(this);
			}
		}

	}

	void OnDestroy(){
		if (pm != null){
			pm.enabled = true;
		}
		if(e != null){
			e.knocked = false;
		}
	}
}
