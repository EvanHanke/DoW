﻿using UnityEngine;
using UnityEngine.UI;


public class TextCycle : MonoBehaviour {

	public string[] msg;
	public float timer;
	float timer1;
	int curr;
	Text t;

	public void Awake(){
		t = GetComponentInChildren<Text>();
		curr = 0;
	}

	void Update(){
		if(timer1 < 0 && !GlobalStateMachine.paused){
			curr++;
			if(curr == msg.Length) curr = 0;
			t.text = msg[curr];
			timer1 = timer;
		}
		else{
			timer1 -= Time.deltaTime;
		}
	}
}
