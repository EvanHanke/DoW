﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StayStill : MonoBehaviour {
	Vector3 pos;
	void Awake(){
		pos = transform.position;
	}

	void LateUpdate(){
		transform.position = pos;
	}
}
