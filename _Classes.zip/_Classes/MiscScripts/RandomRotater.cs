﻿using UnityEngine;

public class RandomRotater : MonoBehaviour {

	public bool rotateX = false;
	public bool rotateY = false;
	public bool rotateZ = false;

	void Awake () {
		float rx = (!rotateX)? 0f: Random.Range(0f, 360f);
		float ry = (!rotateY)? 0f: Random.Range(0f, 360f);
		float rz = (!rotateZ)? 0f: Random.Range(0f, 360f);

		transform.Rotate(rx, ry, rz);
	}
}
