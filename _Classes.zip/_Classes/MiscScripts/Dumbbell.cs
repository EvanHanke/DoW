﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dumbbell : InteractionScript {

	public int pow_req;
	int times_lifted;

	float timer = 0f;

	public void Start(){
		times_lifted = 0;
	}

	public override void OnInteract(){
		if(PlayerStats.myStats.GetStat("power") >= pow_req){
			if(times_lifted < 10){
				SpriteRenderer s = GetComponentInChildren<SpriteRenderer>();
				GlobalStateMachine.GPause();
				PlayerController.me.Display(s.sprite, 1f, transform.localScale);
				FloatingTextSpawner.SpawnText("oof");
				timer = 1f;
				s.enabled = false;
				GymTracker.me.Log(pow_req);
				times_lifted++;
			}
			else{
				PushMessage.Push("That's enough for today");
			}
		}
		else{
			PushMessage.Push("Your power is too low to lift that weight");
		}
	}

	public void Update(){
		if (timer > 0f){
			timer -= Time.deltaTime;
			if (timer <= 0f){
				GlobalStateMachine.GUnpause();
				GetComponentInChildren<SpriteRenderer>(true).enabled = true;
			}
		}
	}

	public override string LabelDesc(){
		return "Lift weight";
	}
}
