﻿using UnityEngine;
using System.Collections.Generic;
public class Itemer : MonoBehaviour {

	//LOAD ITEMS AT RUNTIME WITH DICTIONARY

	public static Itemer me;
	Dictionary<string, Item> allItems;

	void Start () {
		me = this;
		allItems = new Dictionary<string, Item>();
		Item[] itms = Resources.LoadAll<Item>("Items/");
		foreach(Item itm in itms){
			allItems.Add(itm.name, itm);
		}
		Debug.Log("loaded " + allItems.Keys.Count + " items");
	}

	public Item GetItem(string name){
		return allItems[name];
	}
}
