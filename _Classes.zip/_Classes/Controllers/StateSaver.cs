﻿using UnityEngine;
using System.Collections.Generic;

public class StateSaver : MonoBehaviour {
	//for writing state data to the save file
	public int my_state;
	public int my_time;
	public int extra;

	[SerializeField]
	public List<MySavedKeys> myFlags;
	public bool loaded = false;

	public delegate void OnLoad();
	public OnLoad onLoad, onInit;

	void Awake(){
		loaded = true;
		myFlags = new List<MySavedKeys>();
	}

	public void LoadFromJSON(string json){
		JsonUtility.FromJsonOverwrite(json, this);
		//Debug.Log(json);
		if(onLoad != null)
		onLoad();
	}

	//saves a key/value pair to custom serializable list
	public void Save(string key, string val){
		MySavedKeys existing = null;
		foreach(MySavedKeys mk in myFlags){
			if(mk.key == key){
				mk.value = val;
				return;
			}
		}
		if(existing == null){
			myFlags.Add(new MySavedKeys(key, val));
		}
	}

	public string Get(string key){
		foreach(MySavedKeys mk in myFlags){
			if(mk.key == key){
				return mk.value;
			}
		}
		return null;
	}

	public void Init(){
		if(onInit != null)
			onInit();
	}
}

[System.Serializable]
public class MySavedKeys{
	public string key, value;

	public MySavedKeys(string a, string b){
		key = a;
		value = b;
	}
}