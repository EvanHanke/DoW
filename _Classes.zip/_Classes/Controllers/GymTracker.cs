﻿using UnityEngine;

public class GymTracker : MonoBehaviour {

	bool went_today;
	int week_started = -1;
	int day_last_went = 0;

	public static GymTracker me;

	int weight_lifted = 0;

	int current_bonus = 0;

	public Effect gymEffect;

	public void Awake(){
		me= this;
	}

	public void AdvanceTime(){
		Check();
		Debug.Log("checking gym. \nweek started = " + week_started + "\nday last went = " + day_last_went + "\nweight lifted = " +weight_lifted);
	}

	public void Log(int weight){
		weight_lifted += weight;
		day_last_went = TimeTracker.me.day;

		if(TimeTracker.me.day - week_started >= 7 || week_started == -1){
			week_started = TimeTracker.me.day;
		}
	}

	public void Check(){
		if(TimeTracker.me.day == day_last_went + 1){
			week_started = TimeTracker.me.day;
			if(weight_lifted >= PlayerStats.myStats.GetStat("power") * 10){
				weight_lifted = 0;
				PushMessage.Push("You gain a gym bonus.");
				current_bonus++;
				SetEffect();
			}
		}
		else if (current_bonus > 0){
			PushMessage.Push("You have lost a gym bonus.");
			current_bonus--;
			SetEffect();
		}

	}

	public void SetEffect(){
		if (current_bonus > 0){
			gymEffect.effectDescription = "+" + current_bonus * 3 + " power and armor.";

			gymEffect.myModifiers = new Modifier[2];
			gymEffect.myModifiers[0] = new Modifier("power", 1f, current_bonus*3);
			gymEffect.myModifiers[1] = new Modifier("armor", 1f, current_bonus*3);

			PlayerStats.myStats.AddEffect(gymEffect);
		}
		else{
			PlayerStats.myStats.RemoveEffect(gymEffect);
		}
	}
}
