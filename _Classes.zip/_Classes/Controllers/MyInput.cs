﻿using UnityEngine;

//UNIVERSAL INPUT CONTROLLER, CAN BE STATICALLY REFERENCED WITH GETSTATE
public class MyInput : MonoBehaviour {

	public static MyInput me;

	//Buttons: Z, X, C, SHIFT, SPACE, UP, DOWN, LEFT, RIGHT
	//returns 0 = free, 1 = pressed, 2 = held, 3 = released
	public Button[] btns = new Button[16]; 
	char[] states = {'f', 'p', 'h', 'r', 'c'};

	//init
	void Awake () {
		me = this;
		btns[0] = new Button("Z", "Select", KeyCode.Z);
		btns[1] = new Button("X", "Item 1", KeyCode.X);
		btns[2] = new Button("C", "Item 2", KeyCode.C);
		btns[3] = new Button("SHIFT", "Menu",  KeyCode.LeftShift);
		btns[4] = new Button("SPACE", "Jump", KeyCode.Space);
		btns[5] = new Button("UP", "Up", KeyCode.UpArrow);
		btns[6] = new Button("DOWN", "Down", KeyCode.DownArrow);
		btns[7] = new Button("LEFT", "Left", KeyCode.LeftArrow);
		btns[8] = new Button("RIGHT", "Right", KeyCode.RightArrow);
		btns[9] = new Button("ENTER", "Enter Text", KeyCode.Return);
		btns[10] = new Button("T", "Talk", KeyCode.T);
		btns[11] = new Button("BAG", "Pockets", KeyCode.E);
		btns[12] = new Button("QST", "Quest", KeyCode.Q);
		btns[13] = new Button("SLF", "Status", KeyCode.A);
		btns[14] = new Button("SPLS", "Spells", KeyCode.S);
		btns[15] = new Button("CONFIG", "Config", KeyCode.Tab);
	}

	public Button GetButton(string btnName){
		foreach(Button b in btns){
			if (b.name.Equals(btnName)) return b;
		}
		Debug.Log("Trying to read a button which does not exist");
		return null;
	}

	public string GetButtonKey(string btnName){
		foreach(Button b in btns){
			if (b.name.Equals(btnName)) return b.key.ToString();
		}
		Debug.Log("Trying to read a button which does not exist");
		return null;
	}
		
	//0 = free, 1 = pressed, 2 = held, 3 = released
	public static char GetState(string btnName){
		return GetState(btnName, false);
	}

	public static char GetState(string btnName, bool reset){
		char s = me.states[me.GetButton(btnName).GetState()];
		if (reset && s == 'p'){
			me.GetButton(btnName).Pressed();
			//Debug.Log("GetState () pressed reset" + btnName + "  " + s + " at time " + Time.frameCount);
		}
		return s;
	}

	public static void Clear(){
		Debug.Log("Inputed Clear()'ed");
		foreach(Button b in me.btns){
			b.Clear();
		}
	}

	//Must update button states every frame
	void LateUpdate () {
		foreach(Button b in btns){
			b.Refresh();
		//if (b.GetState() == 1) Debug.Log(b.name + " button pressed");
		}
	}
}

public class Button {
	int state;
	int lastState;
	public string name, formal_name;
	public KeyCode key;

	float direction = 1f; //modified in case button takes a negative input axis input


	//constructor in case button receives input axis not 1
	public Button(string a, string b, KeyCode c){
		name = a;
		formal_name = b;
		key = c;
		lastState = 0;
	}

	public void Clear(){
		state = lastState = 3;
	}

	public int GetState(){
		return state;
	}

	//for updating state
	public int Refresh(){
		if(state == 4){
			state = 0;
			lastState = 0;
			return 0;
		}

		int i = (Input.GetKey(key))? 1 : 0;

		if (lastState == 0 && i == 1){ 
			//Debug.Log(name + " pressed");
			state = 1;
		}
		else if (lastState == 1 && i == 1) state = 2; 
		else if (lastState == 2 && i == 0){
			state = 3;
		}
		else if (i == 0){
			state = 0;
		}

		lastState = state;
		return state;
	}

	public void Pressed(){
		//prevent multiple reads on a single press
		//Debug.Log(name + " Pressed()");
		lastState = 1;
		state = 2;
	}

}
