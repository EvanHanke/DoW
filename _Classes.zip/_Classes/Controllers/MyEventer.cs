﻿using UnityEngine;

public class MyEventer : MonoBehaviour {

	/*
	 * For synchronizing shader efx with game state transformations
	 */ 

	public static CameraEfx camFX;



	public static void GOTransition(GameObject a, GameObject b){

	}
}
