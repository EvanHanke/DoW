﻿using UnityEngine;

public class GlobalStateMachine : MonoBehaviour {

	//pauser and unpauser

	public enum States {free, paused};
	public static States currentState;
	public static bool paused{
		get{
			return (currentState==States.paused) ;
		}
	}

	bool canpause = true; //since unity likes to broadcast pause multiple times since it is slow

	static GlobalStateMachine me;

	void Awake(){
		Screen.SetResolution(1024, 576, false);
		me = this;
	}

	public static void GPause(){
		me.Pause();
	}

	public static void GUnpause(){
		me.Unpause();
	}

	public void Pause(){
		//if (!canpause) return;
		if (currentState == States.paused) return;
		BroadcastMessage("OnPause");
		currentState = States.paused;
		Debug.Log("pause");
	}

	public void Unpause(){
		if (currentState == States.free) return;
		BroadcastMessage("OnUnpause");
		currentState = States.free;
		Debug.Log("unpause");
	}

	public bool IsPaused(){
		return (currentState == States.paused)? true:false; 
	}

}
