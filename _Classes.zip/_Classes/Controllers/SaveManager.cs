﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

public class SaveManager : MonoBehaviour {
	//for translating file data to accessible save data
	static string openSave;
	public static SaveManager me;

	List<ZoneSave> modifiedZones = new List<ZoneSave>();

	public void Awake(){ me = this;}

	public void LoadFromSave(Save s){
		if (s != null){
			ZoneSave[] zss = s.GetZoneSaves();
			if(zss != null)
			foreach(ZoneSave zs in zss){
				modifiedZones.Add(zs);
				Debug.Log("loading zone " + zs.saveID + " with " + zs.items + " item data");
			}
		}
	}

	public ZoneSave[] GetModifiedZones(){
		return modifiedZones.ToArray();
	}

	public void SaveZone(Zone zone){
		//does a save profile for this zone already exist?
		ZoneSave zoneSave = null;
		foreach(ZoneSave z in modifiedZones){
			if (zone.myID == z.saveID){
				zoneSave = z;
			}
		}
		//else create new save profile for this zone
		if (zoneSave == null){
			zoneSave = new ZoneSave(zone);
			modifiedZones.Add(zoneSave);
		}
		//modify zone save
		zoneSave.Save(zone);
	}

	public ZoneSave RetrieveSave(int id){
		foreach(ZoneSave z in modifiedZones){
			if (id == z.saveID){
				return z;
			}
		}
		return null;
	}

}

//note: Zone saving done on a zone basis not sub zone
//sub zones load from parent zone data
[System.Serializable]
public class ZoneSave{
	public int saveID;
	public int last_updated; //time value

	public string n;

	//test saving states to Json
	public string[] states;

	//collectable items store whether they have been picked up or not
	public int items;
	public byte[] itemData;

	//Prefab save stores extra prefabs added to the scene
	public PrefabSave[] prefabs;


	public float[] vehicles;


	public override string ToString ()
	{
		return "ZONESAVE " + saveID + "\n ADDED ITEMS: " + prefabs.Length;
	}

	//insantiate zone save profile
	public ZoneSave(Zone zone){
		//create chest save data
		n = zone.name;


		//create item save data
		items = zone.items.Length;
		itemData = new byte[items];
		//
		states = new string[zone.states.Length];

		last_updated = TimeTracker.me.day;
	}

	//save zone data to this object 
	public void Save(Zone zone){
		saveID = zone.myID;
		last_updated = TimeTracker.me.day;
		//state machines
		Debug.Log("Saving... save file " + n + " zone " + zone.name); 
		//save states to JSON
		if(zone.states.Length > states.Length){
			states = new string[zone.states.Length];
		}
		for(int i = 0; i < zone.states.Length; i++){
			states[i] = JsonUtility.ToJson(zone.states[i]);
			//Debug.Log(states[i]);
		}
			
		//save item info
		//Debug.Log("Saving... save file items" + items + " zone items" + zone.items.Length);
		if(zone.items.Length > itemData.Length){
			itemData = new byte[zone.items.Length];
		}
		for(int i = 0; i < zone.items.Length; i++){
			if(zone.items[i] != null){
				itemData[i] = (byte) 1;
			}
			else{
				//Debug.Log("saving item removed");
				itemData[i] = (byte) 0;
			}
		}
			
		//save added prefabs.
		if (zone.addedPrefabs == null){
			prefabs = new PrefabSave[0];
		}
		else{
			int added = zone.addedPrefabs.transform.childCount;
			//Debug.Log("saving " + added + " added items");
			Transform root = zone.addedPrefabs.transform;
			prefabs = new PrefabSave[added];

			//Debug.Log("added items = " + added);
			for(int i = 0; i < added; i++){
				//Debug.Log("attempting to save " + root.GetChild(i).name);
				prefabs[i] = new PrefabSave(root.GetChild(i).gameObject, 
					root.GetChild(i).position, 
					zone.myID);
			}
		}
		
	}

	//Load zone save info
	public void Load(Zone zone){
		Debug.Log("Loading... save file size " + itemData.Length); 
		Debug.Log("zone size " + zone.items.Length); 
		//Debug.Log("Loading zone save");

		if(itemData.Length == 0) return;

		//Debug.Log("Loading... save file items" + items + " zone items" + zone.items.Length);
		//load item... just delete items which have been flagged for removal
		for(int i = 0; i < zone.items.Length && i < itemData.Length; i++){
			if (itemData[i] == (byte) 0)
				GameObject.Destroy(zone.items[i].gameObject);
		}

		//load added prefabs
		for(int i = 0; i < prefabs.Length; i++){
			//Debug.Log("loading " + prefabs.Length + " added items");
			GameObject g_p = Prefabber.me.PrefabOfIndex(prefabs[i].prefab);
			if(g_p != null){
				Vector3 pos = new Vector3(prefabs[i].posx, prefabs[i].posy, prefabs[i].posz);
				GameObject loaded = GameObject.Instantiate( g_p, 
					pos, Quaternion.identity, zone.addedPrefabs.transform);
				StateSaver ss = loaded.GetComponent<StateSaver>();
				if (ss != null){
					Debug.Log(prefabs[i].stateJSON);
					ss.LoadFromJSON(prefabs[i].stateJSON);
				}
			}
		}

		for(int i = 0; i < zone.states.Length; i++){

			zone.states[i].LoadFromJSON(states[i]);
			if(zone.states[i].onLoad!=null)
			zone.states[i].onLoad();
		}


	}
}

[System.Serializable]
public class PrefabSave{
	public int prefab; //prefab id
	public float posx, posy, posz;
	public int myZone; //subzone id

	public string stateJSON;

	public PrefabSave(GameObject go, Vector3 pos, int z){
		//Debug.Log("new prefab save " +go.name);
		prefab = Prefabber.me.IndexOfGameObject(go);
		//Debug.Log("prefab save id " + prefab);
		posx = pos.x;
		posy = pos.y;
		posz = pos.z;
		myZone = z;
		StateSaver ss = go.GetComponent<StateSaver>();
		if (go.GetComponent<StateSaver>() != null){
			stateJSON = JsonUtility.ToJson(ss);
		}
		else stateJSON = null;
	}
}