﻿using UnityEngine;
using UnityEngine.UI;

public class NewGameController : MonoBehaviour {

	float how_long = 30;

	//Print words
	float initial_delay = 10;
	Text storyText;
	string[] words;
	float[] word_alpha_values;
	int counter;
	float speed = 1.5f;

	void Start(){
		
		initial_delay = Time.time + initial_delay;
		how_long += Time.time;

		storyText = GetComponentInChildren<Text>();
		words = storyText.text.Split(' ');
		word_alpha_values = new float[words.Length];
		counter = 0;
		for(int i = 0; i < words.Length; i++){
			word_alpha_values[i] = 0f;
		}
		storyText.text = TextWordAlpha();
	}

	void Update(){
		if(counter < word_alpha_values.Length && Time.time > initial_delay){
			if (word_alpha_values[counter] < 1f){
				if (word_alpha_values[counter] == 0f) 				
					AudioLoader.PlaySound("Glitch_4.L");
				word_alpha_values[counter] += Time.deltaTime*speed;
			}
			else{
				counter++;
			}
		}
		storyText.text = TextWordAlpha();

		if(how_long < Time.time || MyInput.GetState("ENTER", true) == 'p'){
			this.enabled = false;
			CameraEfx.FadeInOut(3f, InitFirstZone);
		}
	}

	void InitFirstZone(){
		Debug.Log("INIT Z Z");
		gameObject.SetActive(false);
		SaveFiler.theGlobe.gameObject.SetActive(true);
	}

	string TextWordAlpha(){
		string newString = "";
		for(int i = 0; i < words.Length ; i++){
			string new_word;
			Color word_color = new Color(1f, 1f, 1f, word_alpha_values[i]);
			new_word = words[i].Insert(0, "<color=#" + ColorUtility.ToHtmlStringRGBA(word_color) + ">") + "</color>";
			newString += (new_word + " ");
		}
		return newString;
	}
}
