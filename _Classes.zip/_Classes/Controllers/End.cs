﻿using UnityEngine;

public class End : MonoBehaviour {

	GameObject player;

	SpriteRenderer s1;
	GameObject snakes;
	Interactable ib;

	float blink_timer = 2f;
	float blink_timer2 = 0.2f;
	bool blink = true;
	float rise_timer = 5f;
	bool dialogue = false;

	void Awake(){
		gameObject.name = "ENDING";
		player = PlayerController.me.gameObject;
		Vector3 pt = player.transform.position;
		player.transform.position = new Vector3(0f, pt.y, pt.z);
		PausePlayer();
		player.transform.parent = transform;
		snakes = transform.GetChild(0).gameObject;
		AudioLoader.PlaySound("reveal");
		ib = GetComponent<Interactable>();
		ib.enabled = false;
	}

	void Update(){
		if(blink_timer > 0f){
			blink_timer2 -= Time.deltaTime;
			if(blink_timer2 < 0f){
				s1.enabled = blink;
				snakes.SetActive(!blink);
				blink = !blink;
				blink_timer2 = 0.1f;
			}
			blink_timer -= Time.deltaTime;

			if(blink_timer <= 0f){
				s1.enabled = false;
				snakes.SetActive(true);
			}
		}

		else if(rise_timer > 0f){
			transform.position += Vector3.up * Time.deltaTime * 2f;
			rise_timer -= Time.deltaTime;
			snakes.transform.localScale = Vector3.Lerp(Vector3.one, Vector3.one*2f, (5f-rise_timer) / 5f);
		}

		else if (!dialogue){
			GetComponent<NPC2>().OnInteract();
			dialogue = true;
			ib.enabled = true;
		}
	}

	void PausePlayer(){
		GameObject.Find("Oro").SetActive(false);
		player.GetComponent<PlayerMovement>().enabled = false;
		player.GetComponent<Interactor>().nearest = null;
		player.GetComponent<Rigidbody>().useGravity = false;
		player.GetComponent<PlayerController>().enabled = false;
		player.GetComponent<PlayerStats>().enabled = false;
		player.GetComponent<ConstantForce>().enabled = false;
		UIController.me.RemoveLabel();
		player.GetComponent<Interactor>().enabled = false;                           
		s1 = player.GetComponentInChildren<SpriteRenderer>();
		foreach(SpriteRenderer s in player.GetComponentsInChildren<SpriteRenderer>()){
			s.enabled = false;
		}
	}
}
