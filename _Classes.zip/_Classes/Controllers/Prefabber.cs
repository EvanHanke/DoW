﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Prefabber : MonoBehaviour {
	//for converting game objects to index IDs and vice versa
	public static Prefabber me;
	GameObject[] prefabs;
	public GameObject buildParticles;

	void Awake () {
		me = this;
		prefabs = Resources.LoadAll<GameObject>("Prefabs/");
		Debug.Log("loaded " + prefabs.Length + " prefabs");
	}

	//find prefab via name matching (might have to be careful about naming)
	public int IndexOfGameObject(GameObject go){
		for(int i = 0; i < prefabs.Length; i++){
			if (go.name.Contains(prefabs[i].name)){
				return i;
			}
		}
		Debug.Log("No prefab found for gameobject " + go.name);
		return -1;
	}

	//find prefab via index
	public GameObject PrefabOfIndex(int i){
		if (i == -1) return null;
		if (prefabs.Length > i){
			return prefabs[i];
		}
		Debug.Log("Requesting invalid prefab id");
		return null;
	}

	public GameObject GetFromName(string n){
		foreach(GameObject g in prefabs){
			if (g.name == n) return g;
		}
		return null;
	}
}
