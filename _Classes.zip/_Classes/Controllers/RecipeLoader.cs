﻿using System.Collections.Generic;
using UnityEngine;

public class RecipeLoader : MonoBehaviour {

	//LOAD RECIPE OBJECTS AT RUNTIME WITH DICTIONARY

	public static RecipeLoader me;
	Dictionary<string, BuildRecipe> allPrefabs;

	void Start () {
		me = this;
		allPrefabs = new Dictionary<string, BuildRecipe>();
		BuildRecipe[] rcpes = Resources.LoadAll<BuildRecipe>("BuildRecipes/");
		foreach(BuildRecipe rcpe in rcpes){
			allPrefabs.Add(rcpe.buildName, rcpe);
		}
		Debug.Log("loaded " + allPrefabs.Keys.Count + "  build recipes");
	}

	public GameObject GetRecipeObj(string name){
		if(!allPrefabs.ContainsKey(name)) return null;
		return allPrefabs[name].buildPrefab;
	}
}
