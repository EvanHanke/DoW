﻿using UnityEngine;
using System.Collections.Generic;
using System.IO;

using System;

public class SaveFiler : MonoBehaviour {
	public static List<string> save_files;
	public static List<Save> saves;

	public static SaveFiler me;
	public static Save activeSave;

	FileStream file_reader;

	public static Transform theGlobe;
	public static Transform mainMenu;

	public GameObject globe, main_menu;

	void Start(){
		me = this;
		save_files = new List<string>();
		saves = new List<Save>();

		theGlobe = globe.transform;
		mainMenu = main_menu.transform;



		//Get the current save files
		Debug.Log("Working directory " + Application.persistentDataPath);
		if (!Directory.Exists(Application.persistentDataPath+"/Dreams")){
			Debug.Log("No save directory found");
			Directory.CreateDirectory(Application.persistentDataPath+"/Dreams");
		}
		else Debug.Log("Save directory found");

		string[] files = Directory.GetFiles(Application.persistentDataPath+"/Dreams");
		foreach(string s in files){
			if (s.EndsWith(".dream")){
				save_files.Add(s);
			}
		}

		//DeSerialize the save files

		foreach(string s in save_files){
			
			string sf = File.ReadAllText(s);

			try{
				Save ns = (Save) JsonUtility.FromJson<Save>(sf);
				saves.Add(ns);
				Debug.Log("Loaded save " + s);
			}
			catch(Exception e){
				Debug.Log("Invalid save detected");
				File.Delete(s);
			}
		}


		Debug.Log(saves.Count + " save files loaded");

		//activeSave = CreateNewSave("Debug");
	}

	public static Save CreateNewSave(string name){
		Save news = new Save(name, (Application.persistentDataPath+"/Dreams/"+name + ".dream"));
		string sss = JsonUtility.ToJson(news, true);
		File.WriteAllText(Application.persistentDataPath +"/Dreams/"+name + ".dream", sss);
		Debug.Log("New save file created");
		saves.Add(news);
		save_files.Add("/Dreams/"+name);
		return news;
	}

	public static void DeleteSave(int which){
		Save s = saves[which];
		saves.Remove(s);
		File.Delete(s.myFile);
		Debug.Log("DELETEING SAVE ?");
	}

	public static void SaveGame(){
		Zone.Save();
		if (activeSave == null){
			Debug.Log("Saving to debug file");

			activeSave = CreateNewSave("Debug");
		}

		Debug.Log("trying to save to path " + activeSave.myFile);
		activeSave.SetZoneSaves(SaveManager.me.GetModifiedZones());
		activeSave.currentZone = Zone.currentZone.name;
		activeSave.currentSubZone = Zone.currentSubZone.name;
		activeSave.GetZoneSaves();
		activeSave.global_states_json = GlobalStater.me.Save();
		activeSave.playerData.UpdateFromPlayerTransform(PlayerStats.me.transform);

		string sss = JsonUtility.ToJson(activeSave);
		File.WriteAllText(Application.persistentDataPath +"/Dreams/"+activeSave.name + ".dream", sss);

	}

	public static void LoadGame(int which){
		activeSave = saves[which];
		LoadGame();
	}
	public static void LoadGame(){
		theGlobe.gameObject.SetActive(true);
		mainMenu.gameObject.SetActive(false);


		if(activeSave!=null){
			

			Debug.Log("Loading save" + activeSave.name);
			Debug.Log("Current zone" + activeSave.currentZone);

			activeSave.Load();
			SaveManager.me.LoadFromSave(activeSave);

			Debug.Log("LOAD GAME" + activeSave.name);
		}
	}


	public static int GetDifficulty(){
		if(activeSave != null) return activeSave.playerData.mode;
		else return 1;
	}
}

[System.Serializable]
public class Save{

	public bool active;
	public string name;
	public int level;

	public string currentZone;
	public string currentSubZone;
	public int saveTarget;

	public string myFile;
	public ZoneSave[] myZoneSaves;

	public PlayerSave playerData;
	public TimeSave timeSave;
	public string wormHoleSave;
	public string global_states_json;

	public Save(string name, string f){
		this.name = name;
		this.myFile = f;
		level = 1;
		myZoneSaves = new ZoneSave[0];
		currentZone = "Area_1";
		currentSubZone = null;
		timeSave = TimeTracker.TimeSave();
		global_states_json = GlobalStater.me.Save();
		wormHoleSave = JsonUtility.ToJson( Wormholer.me );
	}

	public void Load(){
		//load player data
		if(playerData == null){
			Debug.Log("No new player data");
			playerData = new PlayerSave();
		}

		//load time data
		if (timeSave != null)
			TimeTracker.LoadSave(timeSave);
		//load global state data
		if(global_states_json.Length > 1)
			GlobalStater.me.Load(global_states_json);

		Vector3 pos = new Vector3(playerData.x, playerData.y, playerData.z);
		Zone.ChangeZone(currentZone, currentSubZone, pos);
		playerData.Load(PlayerStats.me.transform);
		Wormholer.me.Load(wormHoleSave);
	}

	public void SetZoneSaves(ZoneSave[] zs){
		myZoneSaves = zs;
	}
	public ZoneSave[] GetZoneSaves() { return myZoneSaves; }


}
