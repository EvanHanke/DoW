﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DayActivator : MonoBehaviour {

	public static List<DayActivator> all;
	public string[] myDays;

	public void Awake(){
		if (all == null) all = new List<DayActivator>();
		all.Add(this);
	}

	public static void Check(){
		if (all != null)
		foreach(DayActivator da in all){
			if (da != null)
			foreach(string myDay in da.myDays){
				if(TimeTracker.me.today != myDay){
					da.gameObject.SetActive(false);
				}
				else{
					da.gameObject.SetActive(true);
					break;
				}
			}
		}
	}
}