﻿using UnityEngine;
using System.Collections.Generic;

[System.Serializable]
public class WormTracker : MonoBehaviour{
	[HideInInspector]
	public List<Wormy> worms;
	[HideInInspector]
	public GameObject worm_group;
	GameObject worm_prefab;
	public static WormTracker me;

	public void Awake(){
		me = this;
		worms = new List<Wormy>();
		worm_group = GameObject.Instantiate(new GameObject("worm group"), transform);

	}
	void Start(){
		worm_prefab = Prefabber.me.GetFromName("Wormy");
	}

	public void RefreshZone(){
		ClearWorms();
		CheckSpawn();
	}

	public void AddHunger(){
		foreach(Wormy w in worms){
			w.hunger++;
			if(w.hunger > 1) w.hunger = 1;
		}
	}

	public void SpawnNewWorm(Vector3 pos){
		Wormy new_w = new Wormy();
		GameObject nw = GameObject.Instantiate(worm_prefab, worm_group.transform);
		nw.transform.position = pos+Vector3.back;
		new_w.zone = Zone.currentZone.name;

		worms.Add(new_w);
		nw.GetComponent<WormAI>().Set(new_w);

		Debug.Log(JsonUtility.ToJson(new_w));
	}

	public void CheckSpawn(){
		foreach(Wormy w in worms){
			Debug.Log("checking worm spawn in "  +Zone.currentZone.name + " worm zone "  +w.zone);
			if (Zone.currentZone.name == w.zone){
				SpawnWorm(w);
			}
		}
	}

	public void SpawnWorm(Wormy w){
		
		LocalGrowArea[] lgas = GrowArea.me.allGrowAreas.ToArray();
		Debug.Log("trying to spawn worm in area with " + lgas.Length + " grow areas");
		Vector3 pos = Vector3.zero;
		if(lgas != null && lgas.Length > 0){
			int random_index = (int)((float)(lgas.Length-1)*Random.value);
			pos = lgas[random_index].GetRandomPosInBounds();
		}
		GameObject nw = 
			GameObject.Instantiate(worm_prefab, worm_group.transform);
		nw.transform.position = pos;
		nw.GetComponent<WormAI>().Set(w);
	}

	public void ClearWorms(){
		Transform[] all = worm_group.transform.GetComponentsInChildren<Transform>();
		foreach(Transform t in all){
			if(t.gameObject != worm_group)
				GameObject.Destroy(t.gameObject);
		}
	}

	public string[] Save(){
		string[] save = new string[worms.Count];
		for(int i = 0; i < save.Length; i++){
			save[i] = JsonUtility.ToJson( worms[i] );
		}
		return save;
	}

	public void Load(string[] save){
		foreach(string s in save){
			Wormy w = JsonUtility.FromJson<Wormy>(s);
			worms.Add(w);
		}
	}
}