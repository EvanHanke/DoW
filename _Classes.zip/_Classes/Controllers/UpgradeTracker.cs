﻿using UnityEngine;
using System.Collections.Generic;

public class UpgradeTracker : MonoBehaviour {
	public static UpgradeTracker me;
	public WearableItem[] all_wearable;
	public Upgrade[] all_upgrades;
	public CastableItem[] all_castable;

	public void Awake(){
		me = this;
		all_upgrades = Resources.LoadAll<Upgrade>("Upgrades/");

		all_wearable = Resources.LoadAll<WearableItem>("Items/clothes/");
		foreach(WearableItem w_i in all_wearable){
			w_i.effects[0].upgrades.Clear();
			w_i.equipped = "";
		}

		all_castable = Resources.LoadAll<CastableItem>("Item/Weapons/");
		foreach(CastableItem c in all_castable){
			c.upgraded = false;
		}
			
		foreach(Item i in Resources.LoadAll<Item>("Items/")){
			i.equipped = "";
		}
	}

	public UpgradeSave Save(){
		InvEntry[] my_wearable = PlayerStats.playerInv.GetItems<WearableItem>();
		List<string> ws = new List<string>();
		foreach(InvEntry ww in my_wearable){
			WearableItem w = (WearableItem) ww.itm;
			if(w.effects[0].upgrades.Count > 0){
				string s = w.name;
				foreach(Upgrade u in w.effects[0].upgrades){
					s += (","+u.name);
				}
				ws.Add(s);
			}
		}
		InvEntry[] my_cast = PlayerStats.playerInv.GetItems<CastableItem>();
		List<string> c= new List<string>();
		foreach(InvEntry cc in my_cast){
			CastableItem ci = (CastableItem) cc.itm;
			if(ci.upgraded) c.Add(ci.name);
		}

		UpgradeSave us = new UpgradeSave();
		us.castable_upgraded = c.ToArray();
		us.wearable_upgraded = ws.ToArray();
		return us;
	}

	public void Load(UpgradeSave us){
		//find and relink armor upgrades
		if(us.wearable_upgraded != null)
		foreach(string cc in us.wearable_upgraded){
			string[] abc = cc.Split(',');
			string a = abc[0]; // name
			WearableItem w = null;
			foreach(WearableItem ww in all_wearable){
				if(ww.name == a){
					w = ww;
					break;
				}
			}
			if(w != null)
			for(int i = 1; i < abc.Length;i++){
				foreach(Upgrade u in all_upgrades){
					if(u.name == abc[i]){
							w.effects[0].upgrades.Add(u);
					}
				}
			}
		}
		//weapons
		if(us.castable_upgraded != null)
		foreach(string cc in us.castable_upgraded){
			foreach(CastableItem ac in all_castable){
				if(ac.name == cc){
					ac.upgraded = true;
				}
				else{
					ac.upgraded = false;
				}
			}
		}

	}
}

[System.Serializable]
public class UpgradeSave{
	public string[] castable_upgraded;
	public string[] wearable_upgraded;
}