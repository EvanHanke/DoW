﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class End2 : MonoBehaviour {

	float float_timer = 3.5f;
	bool dialogue = false;

	void Awake(){
		AudioLoader.PlaySound("reveal", 1.2f);
		//GameObject.Find("ENDING").GetComponent<Interactable>().enabled = false;
		GameObject.Find("Player").GetComponent<Interactor>().nearest = null;  
	}

	void Update(){

		if(float_timer > 0f){
			transform.position -= Vector3.up * Time.deltaTime * 2f;
			float_timer -= Time.deltaTime;
		}

		else if (!dialogue){
			GetComponent<NPC2>().OnInteract();
			dialogue = true;
		}
	}
}
