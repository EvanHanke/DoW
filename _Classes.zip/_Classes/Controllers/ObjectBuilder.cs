﻿using UnityEngine;

public class ObjectBuilder : MonoBehaviour {

	//builds slowly over time

	GameObject buildInto;
	SpriteRenderer buildSprite;
	float buildTime, maxTime;
	float size;
	MeshRenderer sphereObj;
	public bool built = false;

	void Awake(){
		buildSprite = GetComponentInChildren<SpriteRenderer>();
		sphereObj = GetComponentInChildren<MeshRenderer>();
		sphereObj.transform.localScale = Vector3.zero;
		built = false;
	}

	public void Set(GameObject g, float t, float ss){
		buildInto = g;
		SpriteRenderer s = buildInto.GetComponentInChildren<SpriteRenderer>();
		if (s != null && s.sprite != null){
			buildSprite.sprite = s.sprite;
			buildSprite.color = Color.clear;
			buildSprite.transform.localPosition = s.transform.localPosition;
			buildSprite.transform.localScale = s.transform.lossyScale;
		}
		buildTime = maxTime = t;
		size = ss;
	}

	void Update(){
		if(GlobalStateMachine.paused == false && buildTime != null && built == false){
			buildTime -= Time.deltaTime;
			if (buildTime > 0f){
				sphereObj.transform.localScale = Vector3.one * size * (1f - buildTime / maxTime);
				buildSprite.color = Color.white * (1f - buildTime / maxTime);
			}
			else{
				built = true;
				GameObject.Instantiate(buildInto, transform.position, Quaternion.identity, transform.parent);
				GameObject.Destroy(gameObject);
			}
		}
	}
}
