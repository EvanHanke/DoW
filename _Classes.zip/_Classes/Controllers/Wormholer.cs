﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Wormholer : MonoBehaviour{
	public static Wormholer me;
	public List<WormHoleSave> wormholes;
	//track location of all wormholes

	public void Awake(){
		wormholes = new List<WormHoleSave>();
		me = this;
	}

	public void Load(string file){
		Wormholer wh = JsonUtility.FromJson<Wormholer>(file);
		if(wh!=null)
			wormholes = wh.wormholes;
	}

	public WormHoleSave GetNextLink(WormHoleSave curr){
		if(wormholes.Count > 1){
			int b = 0;
			int a = wormholes.IndexOf(curr);
			if (a < wormholes.Count-1) b = a + 1;
			return wormholes[b];
		}
		else return null;
	}

	public WormHoleSave GetFromLoc(Vector3 loc){
		string s = loc.ToString();
		foreach(WormHoleSave ws in wormholes){
			if(ws.x == loc.x && ws.y == loc.y && ws.z == loc.z) return ws;
		}
		return null;
	}

	public void Remove(WormHoleSave whs){
		if(wormholes.Contains(whs)){
			wormholes.Remove(whs);
		}
	}

	public WormHoleSave AddNew(Transform t){
		Debug.Log("new wormhole " + wormholes.Count);
		WormHoleSave whs = new WormHoleSave();
		whs.x = t.position.x;
		whs.y = t.position.y;
		whs.z = t.position.z;
		whs.zone = Zone.currentZone.name;
		whs.subzone = Zone.currentSubZone.name;
		whs.richname = Zone.currentSubZone.displayName;
		wormholes.Add(whs);
		QuestTracker.UpdateQuests();
		return whs;
	}

}

[System.Serializable]
public class WormHoleSave{
	public string zone, subzone, richname;
	public float x, y, z;
}
