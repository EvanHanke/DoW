﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class ScreenShotter : MonoBehaviour {

	public static ScreenShotter me;
	public string s_name;
	public Book lookBook;

	void Awake(){
		me = this;
		if (!Directory.Exists(Application.persistentDataPath+"/Dreams/Screens")){
			Directory.CreateDirectory(Application.persistentDataPath+"/Dreams/Screens");
		}
	}

	void Start(){
		Invoke("RefreshLB", 0.5f);
	}

	public void RefreshLB(){
		lookBook.pictures = ScreenShotter.GetLookBook();;
	}

	public static Sprite[] GetLookBook(){
		string[] pics = Directory.GetFiles(Application.persistentDataPath+"/Dreams/Screens/");
		List<string> looks = new List<string>();
		foreach(string f in pics){
			if(f.Contains(SaveFiler.activeSave.name + "_look_")){
				looks.Add(f);
			}
		}
		Sprite[] t = new Sprite[looks.Count];
		for(int i = 0; i < looks.Count; i++){
			Texture2D tex =  LoadCroppedPic(looks[i]);
			t[i] = Sprite.Create(tex, new Rect(Vector2.zero, new Vector2(tex.width, tex.height)), Vector2.zero);
		}
		return t;
	}

	public void RegisterLook(string n){
		string f_name = SaveFiler.activeSave.name + "_look_" + n;
		InvokeSS(f_name, 3f);
	}

	public void InvokeSS(string n, float t){
		s_name = n;
		Invoke("TakePresetPic", t);
		Invoke("RefreshLB", t+0.1f);
	}

	public void TakePresetPic(){
		TakePic(me.s_name);
	}

	public static void TakePic(string name){
		PushMessage.Push("Picture taken!");
		Application.CaptureScreenshot(Application.persistentDataPath+"/Dreams/Screens/"+ name+".png");
	}

	public static Texture2D LoadPic(string name){
		Texture2D load = new Texture2D(1600, 900);
		load.LoadImage(File.ReadAllBytes(name));
		return load;
	}

	public static Texture2D LoadCroppedPic(string name){
		Texture2D load = LoadPic(name);
		int x = load.width/2 - load.width/8;
		int y = 0;
		int xx = load.height/2;
		Color[] cropped = load.GetPixels(x, y, xx, xx);
		Texture2D load2 = new Texture2D(xx, xx);
		load2.SetPixels(cropped);
		load2.Apply();
		return load2;
	}
}
