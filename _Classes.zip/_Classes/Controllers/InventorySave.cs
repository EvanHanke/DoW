﻿using UnityEngine;
using System.Collections.Generic;

[System.Serializable]
public class InventorySave{
	
	public InventorySave[] allItems;

	public int state;
	public string itemName;
	public int amount;
	public int charge;

	public void SaveFromInventory(Inventory inv){
		InvEntry[] ies = inv.GetAllItems();
		allItems = new InventorySave[ies.Length];
		for (int i = 0; i < ies.Length; i++){
			allItems[i] = new InventorySave();
			allItems[i].state = ies[i].state;
			allItems[i].itemName = ies[i].itm.name;
			allItems[i].amount = ies[i].amt;

			if(ies[i].itm is CastableItem){
				CastableItem c = (CastableItem) ies[i].itm;
				if(c.charged)
					allItems[i].charge = c.charges;
			}
		}
	}

}
