﻿using System.Collections.Generic;

[System.Serializable]
public class CharacterSave{
	//for saving character sheet data
	public string[] stat_names;
	public int[] stat_vals;
	public EffectSave[] efs;

	public CharacterSave(Character c){
		stat_names = new string[c.CopyOfStats().Keys.Count];
		c.CopyOfStats().Keys.CopyTo(stat_names, 0);
		stat_vals= new int[stat_names.Length];
		for(int i = 0; i < stat_names.Length; i++){
			stat_vals[i] = c.GetStatRaw(stat_names[i]);
		}
		Effect[] es = c.GetAllEffects();
		efs = new EffectSave[es.Length];
		for(int i = 0; i < es.Length; i++){
			efs[i] = new EffectSave(es[i]);
		}
	}

	public int GetStat(string key){
		for(int i = 0; i < stat_names.Length; i++){
			if(stat_names[i] == key) return stat_vals[i];
		}
		return 0;
	}

}

[System.Serializable]
public class EffectSave{
	
	public float duration; //seconds
	public float timeLeft;
	public int stacks;
	public int maxStacks; //default
	public string effectName;
	public string effectDescription;
	public bool isStackable;
	public string particleName;

	public ModifierSave[] modifiers;

	public EffectSave(Effect e){
		duration = e.duration;
		timeLeft = e.GetTimeLeft();
		stacks = e.GetStacks();
		maxStacks = e.maxStacks;
		effectName = e.effectName;
		effectDescription = e.effectDescription;
		isStackable = e.isStackable;
		if(e.particlesPrefab!= null)
			particleName = e.particlesPrefab.name;
		else
			particleName = "none";

		modifiers = new ModifierSave[e.myModifiers.Length];
		for (int i = 0; i < e.myModifiers.Length; i++) {
			modifiers[i] = new ModifierSave(e.myModifiers[i]);
		}
	}

	public Effect Get(){
		Modifier[] ms = new Modifier[modifiers.Length];
		for(int i = 0; i < ms.Length; i++){
			ms[i] = modifiers[i].Get();
		}
		Effect e = new Effect(ms);
		e.duration = duration;
		e.timeLeft = timeLeft;
		e.stacks = stacks;
		e.maxStacks = maxStacks;
		e.effectName = effectName;
		e.effectDescription = effectDescription;
		e.isStackable = isStackable;
		if(particleName != "none")
			e.particlesPrefab = Prefabber.me.GetFromName(particleName);

		return e;
	}
}

[System.Serializable]
public class ModifierSave{
	public int stacks;
	public string statName;
	public float modVal;
	public int bonus;

	public ModifierSave(Modifier m){
		stacks = m.GetStacks();
		statName = m.statName;
		modVal = m.modVal;
		bonus = m.flatBonus;
	}

	public Modifier Get(){
		return new Modifier(statName, modVal, bonus, stacks);
	}
}