﻿using UnityEngine;

public class GlobalStater : MonoBehaviour {


	//Globally accessible state machine saver and timer

	public static GlobalStater me;
	StateSaver my_saver;


	void Awake(){
		my_saver = gameObject.AddComponent<StateSaver>();
		me = this;
	}

	public void SetState(string key, string value){
		my_saver.Save(key, value);
	}

	public string GetState(string key){
		return my_saver.Get(key);
	}

	public string Save(){
		return JsonUtility.ToJson(my_saver);
	}

	public void Load(string data){
		my_saver.LoadFromJSON(data);
	}
}
