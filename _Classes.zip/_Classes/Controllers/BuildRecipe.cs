﻿using UnityEngine;

[CreateAssetMenu]
public class BuildRecipe : ScriptableObject {

	public GameObject buildPrefab;
	public string buildName;

}
