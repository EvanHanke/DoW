﻿using UnityEngine;
using System.Collections.Generic;
public class Particallor : MonoBehaviour {

	//LOAD PARTICLE PREFABS AT RUNTIME WITH DICTIONARY

	public static Particallor me;
	Dictionary<string, GameObject> allPrefabs;

	void Start () {
		me = this;
		allPrefabs = new Dictionary<string, GameObject>();
		GameObject[] itms = Resources.LoadAll<GameObject>("Particles/");
		foreach(GameObject itm in itms){
			allPrefabs.Add(itm.name, itm);
		}
		Debug.Log("loaded " + allPrefabs.Keys.Count + " paricle prefabs");
	}

	public GameObject GetParticle(string name){
		return allPrefabs[name];
	}
}
