﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tutorial : MonoBehaviour {

	public string flagname;
	[TextArea(0,4)]
	public string text;
	public float delay;
	public bool auto_unpause;
	public bool is_ui;
	public GameObject uiprefab;

	public void Awake(){
		Invoke("Launch", delay);
	}

	void Launch(){
		if(GlobalStateMachine.paused == is_ui){
			if(GlobalStater.me.GetState(flagname) != "shown" && 
				GlobalStater.me.GetState("Tutorial") != "0"){
				GlobalStater.me.SetState(flagname, "shown");
				GlobalStateMachine.GPause();

				GameObject ui = GameObject.Instantiate(uiprefab, GameObject.Find("UI").transform);
				TutorialUI t_ui = ui.GetComponent<TutorialUI>();
				t_ui.Set(text);

				if(auto_unpause) t_ui.onEnd += GlobalStateMachine.GUnpause;
				if(is_ui){
					A();
					t_ui.onEnd += B;
				}
			}
		}
		else{
			Invoke("Launch", delay);
		}
	}

	public void A(){
		foreach(MonoBehaviour mb in GetComponents<MonoBehaviour>()){
			mb.enabled = false;
		}
	}

	public void B(){
		if(gameObject!=null)
		if(GetComponents<MonoBehaviour>() != null)
		foreach(MonoBehaviour mb in GetComponents<MonoBehaviour>()){
			mb.enabled = true;
		}
	}
}
