﻿using UnityEngine;

public class TextColorer{

	public static string ToColor(string plain, Color c){
		
		return "<color=#" + ColorUtility.ToHtmlStringRGBA(c) + ">" + plain + "</color>";
	}

	public static string StatName(string realName){
		string[] a_texts = {"Health", "Mana" , "Power", "Magic Power", "Armor" , "Magic Armor", "Jump Height", "Speed", "Jumps", "Size"};
		string[] statNames = {"maxhp", "maxmp", "power", "magic_pow", "armor","magic_def", "jump", "speed", "extra_jumps", "size"};
		for(int i = 0; i < a_texts.Length; i++){
			if(realName == statNames[i]) return a_texts[i];
		}
		return realName;
	}
}
