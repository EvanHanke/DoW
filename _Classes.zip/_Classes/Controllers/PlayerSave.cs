﻿using UnityEngine;
[System.Serializable]
public class PlayerSave {
	//For consolidating necesary player-specific save data
	public int mode = 0; // 0 = explorer difficulty, 1 = gamer difficulty
	public string xEqpName, cEqpName, headgear, clothes;
	public int karma;
	public InventorySave playerInv;
	public CharacterSave playerStats;
	public QuestSaver[] quests;
	public SpellSaver[] spells;
	public SpawnSave spawn;
	public UpgradeSave upgrades;
	public string riding_obj;
	public string[] followerSave;
	public string[] wormySave;
	public float x, y, z;

	public void UpdateFromPlayerTransform(Transform PT){
		playerInv = new InventorySave();
		playerInv.SaveFromInventory(PT.GetComponent<Inventory>());

		xEqpName = PlayerStats.getXEquip().myName;
		cEqpName = PlayerStats.getCEquip().myName;
		headgear = (PlayerStats.headEquip == null)? null :PlayerStats.headEquip.name;
		clothes = (PlayerStats.bodyEquip == null)? null :PlayerStats.bodyEquip.name;
		playerStats = new CharacterSave(PT.GetComponent<Character>());
		quests = QuestSaver.Save();
		spells = SpellSaver.Save();
		spawn = SpawnPoint.Save();
		followerSave = FollowerTracker.me.Save();
		upgrades = UpgradeTracker.me.Save();
		wormySave = WormTracker.me.Save();

		if(PlayerController.me.ride != null){
			riding_obj= PlayerController.me.ride.name;
		}

		karma = PlayerStats.me.karma;

		x = PT.position.x;
		y = PT.position.y;
		z = PT.position.z;
	}

	public void Load(Transform PT){
		//load stats
		PlayerStats.me.karma = karma;
		SpawnPoint.Load(spawn);

		PT.transform.position = new Vector3(x, y, z);


		//quests, spells
		if(quests != null)
			QuestSaver.Load(quests);

		if(spells != null)
			SpellSaver.Load(spells);

		//load stats
		PlayerStats.myStats.Load(playerStats);

		//load inventory
		if(playerInv != null)
			PT.GetComponent<Inventory>().LoadFromInvSave(playerInv);

		UpgradeTracker.me.Load(upgrades);

		//load equipped items
		if(xEqpName!="" && xEqpName.Length > 1)
			PlayerStats.SetEquip(PlayerStats.getXEquip(), (UsableItem) Itemer.me.GetItem(xEqpName));
		if(cEqpName != "" && cEqpName.Length > 1)
			PlayerStats.SetEquip(PlayerStats.getCEquip(), (UsableItem) Itemer.me.GetItem(cEqpName));
		if(headgear != "" && headgear.Length > 1)
			PlayerStats.headEquip = (WearableItem) Itemer.me.GetItem(headgear);
		if(clothes != "" && clothes.Length > 1)
			PlayerStats.bodyEquip = (WearableItem) Itemer.me.GetItem(clothes);

		//followers
		if(followerSave != null){
			FollowerTracker.me.Load(followerSave);
		}

		//vehicle
		if(!string.IsNullOrEmpty(riding_obj)){
			GameObject g = GameObject.Instantiate(Prefabber.me.GetFromName(riding_obj));

			Vehicle v = g.GetComponent<Vehicle>();
			g.transform.parent = PlayerController.me.transform.parent;
			g.transform.position = PT.transform.position -= v.playerOffset;
			PT.transform.position += v.playerOffset;
			PlayerMovement.me.ground = g.GetComponent<Collider>();
			v.Invoke("OnInteract", 0.1f);
		}

		//worms
		WormTracker.me.Load(wormySave);
	}
}
