﻿using UnityEngine;

public class Enemy : MonoBehaviour {

	BoxCollider myColl;
	public bool bouncy = false;

	public string myName;

	void Start () {
		myColl = GetComponent<BoxCollider>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnCollisionEnter(Collision coll){
		//On Player Contact
		if(coll.transform.tag == "Player"){
			Rigidbody rb = coll.transform.GetComponent<Rigidbody>();
			Vector3 knockback = new Vector3(0f, 50f, 0f);
			float highmark = transform.position.y+myColl.bounds.extents.y/2f+myColl.bounds.center.y-0.1f;
			//Debug.Log(highmark);Debug.Log("highmark");Debug.Log(coll.transform.position.y);
			//if stomped on
			if (bouncy &&
				coll.transform.position.y > highmark){
				Debug.Log("stomped on");
				Vector3 bounceoffset = new Vector3(0f, 0.0f, 0.1f);
				rb.AddForceAtPosition(knockback, coll.contacts[0].point+bounceoffset, ForceMode.Impulse);
			}

		}
	}
}
