﻿using UnityEngine;

public class DemonAI : MonoBehaviour {

	public float range;
	public GameObject attack;

	Transform target;
	MyAnimation myAnim;
	MovementMachine myMM;
	public Sprite myAttackSprite;

	float timer = 0; //timer checks for aggro targets every second or whatever
	float aggroTime = 1f;

	public float attackCD = 2f; //attack cooldown stat
	public float attackAnimTime = 1f;
	float attackTimer = 0;

	bool isAttacking = false;
	bool canAttack = true;


	void Awake () {
		myMM = GetComponent<MovementMachine>();
		myAnim = GetComponentInChildren<MyAnimation>();
		attackTimer = Time.time + attackCD;
	}

	void Update () {


		//if attacking or "freeze frame"
		if (canAttack == false){

			if (Time.time > attackTimer+attackAnimTime && isAttacking){
				//
				myAnim.PlayAnim();
				isAttacking = false;
			}

			if (Time.time > attackTimer+attackCD){
				//
				canAttack = true;
			}

		}

		//default behavior: wander around, check for targets in range
		if (target == null){
			//myMM.Wander();

			if (Time.time > timer){
				target = FindAggroTarget();
				Debug.Log("my target " + target);
				timer = Time.time + aggroTime;
			}
		}
	

		float distanceTo = Vector3.Distance(transform.position, target.transform.position);

		if (Time.time > attackTimer && distanceTo <= range && canAttack){
			Attack();
		}
		else{
			//kite target
			//myMM.Kite(target, range);
		}

	}

	void Attack(){
		//attack target
		GameObject.Instantiate(attack, target.transform);

		attackTimer = Time.time;
		isAttacking = true;
		canAttack = false;

		myAnim.playing = false;
		myAnim.GetComponent<SpriteRenderer>().sprite = myAttackSprite;
	}

	Transform FindAggroTarget(){
		Transform closest= null;
		Collider[] hits;
		//get all colliders in range
		hits = Physics.OverlapSphere(transform.position, range);
		Debug.Log("ray hits = " + hits.Length);
		//check if any have character components
		foreach(Collider hit in hits){

			if (hit.transform.CompareTag("Enemy")){
				if (closest == null){
					closest = hit.transform;
				}
				else if (Vector3.Distance(transform.position, hit.transform.position) < 
					Vector3.Distance(transform.position, closest.position)){
					closest = hit.transform;
				}
			}
		}

		return closest;
	}
}
