﻿using UnityEngine;
/*
public class Kite : MovementBehavior {
	public Kite(Rigidbody rb, float s) : base(rb, s){
	}
	public override bool Move(){
		return true;
	}
	public override void Start(){
	}
	/*
	public static Vector3 Kite(Vector3 currentPosition, MovementMachine myMM, Transform target, float minD){
		//moves towards a target unless target is too close
		float dirMod = 1f; //controls whether u move closer or further
		float d = Vector3.Distance(currentPosition, target.position);

		if (d < minD){
			dirMod = -1f;
		}
		else if (d - minD < 1f){
			//don't move if u close
			return currentPosition;
		}

		Vector3 v = Vector3.MoveTowards(currentPosition,
			target.position,
			myMM.distance * dirMod);

		//v = FindFurtherstValidFrom(currentPosition, v);

		return v;
	}
}
*/