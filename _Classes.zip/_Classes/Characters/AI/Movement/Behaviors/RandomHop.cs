﻿using UnityEngine;

public class RandomHop : MovementBehavior{

	float randX;
	float randZ;
	float timer;
	int hops;
	int maxHops;

	public RandomHop(Rigidbody rb, MovementMachine mm, int max) : base (rb, mm){
		hops = 0;
		maxHops = max;
	}

	public override void Start(){
		hops = 0;
		timer = Time.time;
	}

	public override bool Move(){
		
		if (Time.time > timer){
			if (myRB.velocity.y == 0f){
				if (hops < maxHops){
					Debug.Log("Hop");
					myRB.velocity = Vector3.zero;
					randX = Mathf.Ceil((Random.value-0.5f)*20)* myMover.speed;
					randZ = Mathf.Ceil((Random.value-0.5f)*20) * myMover.speed;
					//Debug.Log("hop in " + randX + " " + randZ);
					myRB.AddForce(randX, 100f, randZ, ForceMode.Impulse);
					hops++;
					timer = Time.time + 1f;
					return false;
				}
				else{

					return true;
				}
			}
			Debug.Log("cant hop");
		}

		return false;
	}
}
