﻿using UnityEngine;

public class Wander : MovementBehavior{
	//Wander picks a random direction and a timer to move in that direction

	Vector3 direction;
	float movetime;
	float timer;


	public Wander(Rigidbody rb, MovementMachine mm, float timer) : base(rb, mm){
		movetime = timer;
	}

	public override void Start(){
		Random.InitState((int)(Time.time)+myRB.GetInstanceID());
		float yamt = (!gravity)? Random.value-0.5f : 0f;
		direction = new Vector3(Random.value-0.5f, yamt, Random.value-0.5f);
		direction.Normalize();
		timer= movetime;
		//myRB.velocity = new Vector3(direction.x, myRB.velocity.y, direction.y);
	}

	public override bool Move(){
		timer -= Time.deltaTime;
		Vector3 pos = myRB.transform.position+(direction*Time.deltaTime*myMover.speed);
		if(IsValidPos(pos))
		myRB.MovePosition(pos);
		return (timer <= 0);
	}
}
