﻿using UnityEngine;

public class MovementMachine : MonoBehaviour {

	/*
	 * 
	 * for controlling ai movement
	 * 
	 */

	public string name;
	public AudioClip myLocationalAudio;
	AudioSource A_S;

	//stats / characteristics
	Transform target; //if the movement requires a target

	//AI
	public Movement[] movements;
	MovementBehavior[] movementCycle;
	Character myCharacter;

	//default sprite direction
	public bool defaultFaceRight = true;

	//mode is the current movement mode
	int mode = 0;

	SpriteRenderer mySprite;
	Rigidbody myRb;
	MyAnimation[] myAnims;
	int currAnim;
	public float baseSpeed = 1f;
	[HideInInspector]
	public float speed = 1f;//speed at which the mob will move to its intended destination

	bool paused = false;
	Vector3 storedVel;

	public void StopAnim(){
		myAnims[currAnim].StopAnim();
	}

	public void Start(){
		speed = baseSpeed;
		mode = 0;
		Start(0);
	}		

	void Start(int i){
		mode = i;
		movementCycle[i].Start();
		movementCycle[mode].Start();

		if(movements[i].mySFX != null) LocalSfx.PlayFx(transform, movements[i].mySFX, false, 0.5f);

		//change animation or spawn prefab if valid
		if (movements[mode].animationName.Length > 0) 
			SetAnim(movements[mode].animationName);
		
		if (movements[mode].spawnPrefab != null)
			SpawnPrefab(movements[mode].spawnPrefab);
		
		//spawn a message
		FloatingTextSpawner.SpawnText(movements[mode].Say(), Color.white, transform);
	}

	void OnEnable () {
		myCharacter = GetComponent<Character>();
		//sprite information supposodly stored in the child object
		mySprite = GetComponentInChildren<SpriteRenderer>();
		myAnims = GetComponentsInChildren<MyAnimation>(true);
		myAnims[0].StopAnim();
		myRb = GetComponent<Rigidbody>();
		currAnim = 0;

		//populate movement cycle
		movementCycle = new MovementBehavior[movements.Length];
		for(int i = 0; i < movements.Length; i++){
			movementCycle[i] = movements[i].CreateBehavior(myRb, this);
		}

		if((myLocationalAudio!=null && A_S == null) || A_S != null){
			A_S = LocalSfx.PlayFx(transform, myLocationalAudio, true, 0.3f);
		}

	}

	void OnDisable(){
		if(A_S!=null)A_S.Stop();
	}

	void OnDestroy(){
		if(A_S!=null)A_S.Stop();
	}

	void OnPause () {
		if(!enabled) return;
		paused = true;
		myRb.Sleep();
	}

	void OnUnpause(){
		if(!enabled) return;
		paused = false;
		myRb.WakeUp();
	}

	void UpdateStats(){
		speed = baseSpeed * myCharacter.GetModStat("speed");
	}

	Vector3 pos = Vector3.zero;
	Vector3 lastPos = Vector3.zero;

	void Update(){
		if (!paused) Move();
	}

	public void Move () {
		
		//Move to next behavior
 		if (movementCycle[mode].Move()){
			//if (movementCycle.Length == 1) return;
			mode = (mode < movementCycle.Length-1)? mode + 1 : 0;
			Start(mode);
		}
			
		//toggle animations if moving or not
		/*
		lastPos = pos;
		pos = transform.position;
		if (Vector3.Distance(pos, lastPos) > 0f && myAnims[currAnim].playing == false){
			myAnims[currAnim].PlayAnim();
			//Debug.Log("play anim");
		} else if (myAnims[currAnim].playing == true){
			myAnims[currAnim].StopAnimOnNextExit();
		}
		*/

		//make sprite face the right directions
		if (Mathf.Abs(pos.x - lastPos.x) > 0.01f){
			if (pos.x < lastPos.x)
				FlipSprite(defaultFaceRight);
			else if (pos.x > lastPos.x) 
				FlipSprite(!defaultFaceRight);
		}
	}

	public void FlipSprite(bool dir){
		mySprite.flipX = dir;
	}


	//Looks for an attached animation with the specified name
	public void SetAnim(string which){
		//Debug.Log("new anim");
		foreach(MyAnimation m_a in myAnims){
			m_a.StopAnim();
		}
		MyAnimation newAnim;
		for(int i = 0; i< myAnims.Length;i++){
			if (myAnims[i].animName == which){
				if (i != currAnim){
				currAnim = i;
				myAnims[currAnim].SetAnim();
				}
			}
		}
		myAnims[currAnim].PlayAnim();
	}

	//spawns a prefab for instance a damager
	public void SpawnPrefab(GameObject spawn){
		if (spawn != null){
			Damager dam = spawn.GetComponent<Damager>();
			if (dam != null){
				//Damager.Cast(spawn, GetComponent<Character>(), Vector3.zero);
			}
			else{
				//GameObject go = GameObject.Instantiate(spawn);
				//go.transform.position += transform.position;
				//go.transform.SetParent(transform.parent, true);
			}
		}
	}

}
