﻿using UnityEngine;

public class Entity : MonoBehaviour {
	//stats
	public EntityAI AI;
	public CharacterSheet statSheet;
	public Character stats;
	public bool invincible = false;
	public bool ally = false;
	public bool healer = false;

	//target / movement
	[HideInInspector]
	public Transform target;
	[HideInInspector]
	public Vector3 move_vector;   
	Vector3 lastPos;
	//state header
	public enum State {aggro, passive} //if the entity can sense the player or not
	public State currentState = State.passive;

	float awareCheck = 0.1f; //periodically check line of sight
	float awareTimer = 0.5f;
	float aggrotimer = 0f;

	public bool SpriteFaceLeft = true;
	//helper
	[HideInInspector]
	public BoxCollider my_BC;
	[HideInInspector]
	public Rigidbody my_RB;
	bool is_k;
	MyAnimation[] myAnims;
	int currentAnim;
	Movement2[] currentCycle;
	int currentMovement;
	float cycleTimer;
	[HideInInspector]
	public bool knocked = false;
	public bool aggro = false;

	//Get References
	void Awake(){
		my_RB = GetComponent<Rigidbody>();
		is_k = my_RB.isKinematic;
		myAnims = GetComponentsInChildren<MyAnimation>();

		stats = gameObject.AddComponent<Character>();
		stats.statSheet = statSheet;
		stats.myEntity = this;
		//stats.InitializeStats();
		if(AI.passiveAI[0].myMoveClass != Movement2.MoveClass.Fly)
			Invoke("AddGF", 0.01f);
		if (GetComponent<Respawner>() == null)
		gameObject.AddComponent<Respawner>();

		//check difficulty 
		if(AI.gamer_mode_target_player && SaveFiler.GetDifficulty() == 1){
			AI.target_player = true;
		}
	}

	void AddGF(){
		gameObject.AddComponent<GroundFollower>();
	}

	void Start(){
		my_BC = GetComponent<BoxCollider>();
		ChangeState();
		target = AcquireTarget();
	}

	//Moving
	public void FixedUpdate(){
		Vector3 pos = transform.position;
		if (pos.x != lastPos.x){
			if (move_vector.x < 0f)
				FlipSprite(!SpriteFaceLeft);
			else if (move_vector.x > 0f) 
				FlipSprite(SpriteFaceLeft);
		}

		lastPos = transform.position;
		if(!GlobalStateMachine.paused && !knocked){

			currentCycle[currentMovement].Move(this);
			cycleTimer -= Time.deltaTime;
			//if(ally) Debug.Log( " curr timer = " + cycleTimer);
			if(cycleTimer <= 0f){
				currentMovement++;
				if(currentMovement == currentCycle.Length) currentMovement = 0;
				currentCycle[currentMovement].Set(this);
				float mod = 1f;
				if (stats != null){
					mod = Mathf.Lerp(.5f, 1f, (float) stats.GetStat("hp") / (float)stats.GetStat("maxhp"));
				}
				cycleTimer = (currentCycle[currentMovement].duration * mod);
			}

			if( Mathf.Abs(my_RB.velocity.y) > 0.1f){
				if(AI.jump_anim != null && AI.jump_anim.Length > 0){
					SetAnim(AI.jump_anim);
				}
			}
			else if (CheckGrounded.Check(transform.position)){
				SetAnim(currentCycle[currentMovement].animationName);
			}
		}

	}

	public void FlipSprite(bool dir){
		SpriteRenderer mySR = GetComponentInChildren<SpriteRenderer>();
		mySR.flipX = dir;
	}

	//Update
	public void Update(){
		if(!GlobalStateMachine.paused){
			CheckAware();
		}
	}

	void ChangeState(){
		Movement2[] new_MC = null;
		switch(currentState){
		case State.aggro:
			new_MC = AI.aggroAI;
			break;
		case State.passive:
			new_MC = AI.passiveAI;
			break;
		}
		currentCycle = new_MC;
		cycleTimer = 0f;
		currentMovement = 0;
	}


	//Awareness Checking
	void CheckAware(){
		awareCheck -= Time.deltaTime;
		if(aggrotimer > 0f) aggrotimer -= Time.deltaTime;
		//default behavior for monsters
		if (awareCheck < 0f && !ally){
			target = AcquireTarget();

			if(target != null && target != transform 
				&& Vector3.Distance(transform.position, target.position) < AI.awareRange 
				&& currentState == State.passive
				&& AI.target_player){
				BecomeAware();
			}
			else if ((target == null || target == transform) ||
				Vector3.Distance(transform.position, target.position) > (AI.unAwareRange)
				&& currentState == State.aggro){
				LoseAware();
			}
			awareCheck = 0.2f;
		}
		//behvaior for allies
		else if (awareCheck < 0f && ally){
			Transform t = AcquireTarget();
			Transform player = PlayerStats.me.transform;
			if(currentState == State.passive && t != player){
				BecomeAware();
			}
			else if (currentState == State.aggro && t == player){
				target= t;
				LoseAware();
			}
			awareCheck = 1f;
		}
	}

	void LoseAware(){
		if(AI.passiveAI.Length > 0 && aggrotimer <= 0f){
			currentMovement = 0;
			Debug.Log("un noticed");
			currentState = State.passive;
			ChangeState();
			aggro = false;
			}
	}

	public void BecomeAware(){
		if(AI.aggroAI.Length > 0){
			currentMovement = 0;
			Debug.Log("noticed");
			currentState = State.aggro;
			target = AcquireTarget();
			ChangeState();
			aggrotimer = 2f;
		}

	}

	Transform AcquireTarget(){
		if(healer == false){
			if(stats.attacker != null) return stats.attacker.transform;
			else if (ally && PlayerStats.myStats.attacker != null) return PlayerStats.myStats.attacker.transform;
			else if (ally && PlayerStats.myStats.target != null) return PlayerStats.myStats.target.transform;
			else return PlayerStats.me.transform;
		}
		else{
			if(ally) return PlayerStats.me.transform;
			else return GetNearestDamagedEntity();
		}
	}

	Transform GetNearestDamagedEntity(){
		Entity[] es = Zone.currentZone.GetComponentsInChildren<Entity>();
		Entity nearest = null;
		foreach(Entity e in es){
			if(e.stats.GetStat("hp") != e.stats.GetStat("maxhp")){
				if(nearest == null && e != this) nearest = e;
				else if (e != this && Vector3.Distance(e.transform.position, transform.position) <
					Vector3.Distance(nearest.transform.position, transform.position))
					nearest = e;
			}
		}
		if(nearest != null)
			return nearest.transform;
		else return transform;
	}

	//Damage / Death / Combat
	public void DropLoot(){
		if(statSheet.dropItems.Length > 0)
			statSheet.DropLoot(transform.position);
	}

	public void OnDamage (Damager d) {

		if (stats.GetStat("hp") <= 0 && !invincible){
			DeathAnimator.StartDeathAnim(this.gameObject);
			DropLoot();
			if(d.caster == PlayerStats.myStats){
				PlayerStats.AddXp(statSheet.killxp);
				QuestTracker.CheckAll(statSheet);
			}
		}

		if((aggro == false || !healer) && d.caster != null) BecomeAware();
	}


	//Animation Setting
	public void SetAnim(string a_name){
		if(myAnims[currentAnim].animName == a_name){
			return;
		}

		//Debug.Log("new anim");
		foreach(MyAnimation m_a in myAnims){
			m_a.StopAnim();
		}
		MyAnimation newAnim = null;
		for(int i = 0; i< myAnims.Length;i++){
			if (myAnims[i].animName == a_name){
				newAnim = myAnims[i];
				currentAnim = i;
			}
		}
		if(newAnim!=null){
			newAnim.SetAnim();
			newAnim.PlayAnim();
		}
	}

	//Pausing / Unpausing
	void OnPause () {
		my_RB.isKinematic = true;
	}

	void OnUnpause(){
		my_RB.isKinematic = is_k;
	}

	void OnDrawGizmosSelected(){
		Gizmos.color = Color.red;
		if(AI != null){
			Gizmos.DrawWireSphere(transform.position, AI.awareRange);
			Gizmos.color = Color.green;
			Gizmos.DrawWireSphere(transform.position, AI.unAwareRange);
		}

	}

	void OnDrawGizmos(){
		Gizmos.color = Color.red;
		//Gizmos.DrawWireCube(GetComponent<BoxCollider>().bounds.center+Vector3.up, GetComponent<BoxCollider>().bounds.size);
		Gizmos.DrawRay(transform.position, move_vector);
	}
}
