﻿using UnityEngine;

[CreateAssetMenu]
public class EntityAI : ScriptableObject {

	public bool target_player = false;
	public bool gamer_mode_target_player = false;
	public float awareRange, unAwareRange;
	public Movement2[] passiveAI;
	public Movement2[] aggroAI;

	public string jump_anim;
}

