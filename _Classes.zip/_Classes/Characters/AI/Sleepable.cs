﻿using UnityEngine;

public class Sleepable : MonoBehaviour {

	MyAnimation[] myAnims;
	MyAnimation currAnim;

	public bool asleep = false;
	public delegate void S_D();
	public S_D onSleep, onWake;

	void Awake(){
		myAnims = GetComponentsInChildren<MyAnimation>();
		if(myAnims.Length > 0)
			currAnim = myAnims[0];
	}

	public void FallAsleep(){
		foreach(MyAnimation ma in myAnims){
			if (ma.animName.Contains("sleep")){
				asleep = true;
				currAnim.StopAnim();
				currAnim = ma;
				ma.PlayAnim();
				onSleep();
			}
		}
	}

	public void WakeUp(){
		Debug.Log("waking up");
		foreach(MyAnimation ma in myAnims){
			Debug.Log("setting ani, up");
			if (!ma.animName.Contains("sleep")){
				asleep = false;
				currAnim.StopAnim();
				currAnim = ma;
				ma.PlayAnim();
				onWake();
				break;
			}
		}
	}
}
