﻿using UnityEngine;

public class EntityPath : MonoBehaviour {

	public Vector3[] path;
	public int curr;

	public void Set(SavedPath s_p){
		Set(s_p.points, s_p.radius, s_p.start_dir);
	}

	public void Set(int num_points, float radius, Vector3 starting_direction){
		Vector3 center = transform.position;
		path = new Vector3[num_points];
		curr = 0;

		float initial_angle = Mathf.Atan(starting_direction.x/starting_direction.z);
		float angle = (Mathf.PI*2f) / (float) num_points;

		//Debug.Log("angle " + angle + " offset " + initial_angle);
		for(int i = 0; i < num_points; i++){
			
			float x = center.x + (radius * Mathf.Cos(initial_angle + angle*i));
			float z = center.z + (radius * Mathf.Sin(initial_angle + angle*i));
			path[i] = new Vector3(x, center.y, z);
			//Debug.Log("path " + path[i]);
		}
	}

	public void Advance(){
		//Debug.Log("curr path " + curr + " pos " + path[curr]);
		curr = (curr + 1 == path.Length)? 0 : curr+1;
	}
}
