﻿using UnityEngine;

public class SleepyDemon : MonoBehaviour {

	enum State {sleep, rising, floating};
	State me = State.sleep;


	void Start () {
		
	}

	void Update () {

		if (me == State.sleep){
			WaitForPlayer ();
		}

		else if (me == State.rising){

		}
		
	}

	void WaitForPlayer(){
		if (Vector3.Distance(transform.position, GameObject.Find("Player").transform.position) < 1f){
			ChangeState(State.rising);
		}
	}

	void ChangeState(State desiredState){
		me = desiredState;
	}

	//Vector3 FindGround(){

	//}
}
