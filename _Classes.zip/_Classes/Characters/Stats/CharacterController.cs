﻿using UnityEngine;

public abstract class CharacterController : MonoBehaviour {

	public abstract void OnDamage();

}
