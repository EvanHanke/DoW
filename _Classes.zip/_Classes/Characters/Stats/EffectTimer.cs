﻿using UnityEngine;

//currently UNUSED
public class EffectTimer: MonoBehaviour{

}
