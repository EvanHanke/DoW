﻿using UnityEngine;

[System.Serializable]
public class SpellSaver{

	public string name, key;

	public SpellSaver(string n, string k){
		name = n;
		key = k;
	}

	public static SpellSaver[] Save(){
		Spell[] learned = SpellChecker.GetLearnedSpells();
		SpellSaver[] saver = new SpellSaver[learned.Length];
		for(int i = 0; i < learned.Length; i++){
			saver[i] = new SpellSaver(learned[i].name, learned[i].key);
		}
		return saver;
	}

	public static void Load(SpellSaver[] saved){
		Spell[] allSpells = Resources.LoadAll<Spell>("Spells/");
		if(saved != null)
		foreach(Spell s in allSpells){
			s.Load();
			foreach(SpellSaver ss in saved){
				if(ss.name == s.name){
					s.key = ss.key;
					s.learned = true;
				}
			}
		}
		SpellChecker.allSpells = allSpells;
	}
}
