﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpellChecker : MonoBehaviour {

	public static  Spell[] allSpells;
	public static SpellChecker me;

	void Awake(){
		me = this;
	}



	//used for spawning spell effects
	//checks allSpells and instantiates corresponding prefab
	//static method for easy referencing
	public static bool CheckSpell(string msg){
		return me.CheckSpell1(msg);
	}
	bool CheckSpell1(string msg){
		foreach(Spell spell in GetLearnedSpells()){
			if (spell.key == msg.ToUpper() && spell.learned){
				//check player mana
				if(!spell.blood){
					if (PlayerStats.myStats.GetStat("mp") - spell.manaCost < 0){
						PushMessage.Push("Not enough mana :(");
						return false;
					}
				
					PlayerStats.myStats.SpendMana(spell.manaCost);

				}
				else if (!PlayerStats.myStats.SpendHP(spell.manaCost)){
					PushMessage.Push("Not enough health :(");
				}

				QuestTracker.CheckAll(spell);
				//insantiate prefab
				GameObject g = GameObject.Instantiate(spell.prefab, Zone.currentZone.transform, true);
				g.transform.position += transform.position;
				Attack a = g.AddComponent<Attack>();
				a.c = PlayerStats.myStats;
				a.direction = PlayerController.me.GetDirection();
				a.target = PlayerStats.GetNearestTarget(15f);
				return true;
			}
		}
		return false;
	}

	//For UI information
	public static Spell[] GetLearnedSpells(){
		List<Spell> learned = new List<Spell>();
		if(allSpells == null){
			allSpells = Resources.LoadAll<Spell>("Spells/");
			foreach(Spell s in allSpells) s.Load();
		}
			
		foreach(Spell sp in allSpells){
			if (sp.learned) learned.Add(sp);
		}
		return learned.ToArray();
	}

	public bool NameTaken(string name){
		if (allSpells == null) SpellSaver.Load(null);

		foreach(Spell s in allSpells){
			if (s.key == name) return true;
		}
		return false;
	}
}
