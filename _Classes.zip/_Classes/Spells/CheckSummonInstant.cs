﻿using UnityEngine;

public class CheckSummonInstant : MonoBehaviour {

	public string key;

	void Start(){
		Recipe.CheckPhrase(key);
		GameObject.Destroy(gameObject);
	}
}
