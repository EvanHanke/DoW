﻿using UnityEngine;

[CreateAssetMenu]
public class Spell : ScriptableObject{
	public string key;
	[TextArea (3, 3)]
	public string description;
	public int manaCost;
	public bool blood = false;
	public bool selfHarm = false;
	public bool learned = false;
	public GameObject prefab;
	public Sprite glyph;
	public bool AUTOLEARN = false;
	public bool hidden = false;

	public void Load(){
		if(!AUTOLEARN){
			key = null;
			learned = false;
		}
		else{
			key = name.ToUpper();
			learned = true;
		}
		if(name == "Recall"){
			if(SaveFiler.activeSave != null){
				key = SaveFiler.activeSave.name;
			}
		}
	}
}