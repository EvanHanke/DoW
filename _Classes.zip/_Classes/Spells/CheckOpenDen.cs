﻿using UnityEngine;
using System.Collections.Generic;

public class CheckOpenDen : MonoBehaviour {

	public void Start(){
		GameObject player = PlayerStats.me.gameObject;
		SummoningToken[] keys = Zone.currentZone.GetComponentsInChildren<SummoningToken>();
		List<SummoningToken> kks = new List<SummoningToken>();
		List<Node> nns = new List<Node>();
		Node.SetBounds(0.2f, 7f);
		foreach(SummoningToken st in keys){
			if(st.id == 77){
				nns.Add( new Node(st.gameObject) );
			}
		}
		foreach(Node n in nns){
			foreach(Node nx in nns){
				n.CheckNeighbor(nx);
			}
		}

		foreach(Node node in Node.allNodes){

			if (!node.FindShape(7)){
				Debug.Log(Node.allNodes.IndexOf(node) + " not a valid root");
			}
			else{
				//if a valid polygon exists, test key nodes
				Debug.Log("Valid root node found at " + node.pos);
				Node validNode = node;
				if (Recipe.IsKeyTokenValid(player, node.myPolygon, 7)){
					Debug.Log("Valid key found at player");
					Invoke("Pause", 0.05f);
					CameraEfx.FadeInOut(5f, Open);
				}
				Debug.Log("No valid keys found");
			}
		}
	}

	public void Pause(){
		GlobalStateMachine.GPause();
	}

	public void Open(){
		Zone.ChangeZone("DOW", "DOW", 0);
		GlobalStateMachine.GUnpause();
	}
}
