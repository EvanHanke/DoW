﻿using UnityEngine;
using System.Collections.Generic;

public class Environment : MonoBehaviour {
	public static Environment me;

	List<GameObject> grasses, growthPs, decayPs;
	List<Vector3> growth, decay;
	GameObject[] soilBuddies;
	public Flower[] flwrs;
	public Rot[] rots;
	public GameObject growthParticle, decayParticle;

	void Awake(){
		me = this;
		grasses = new List<GameObject>();
		growthPs = new List<GameObject>();
		decayPs = new List<GameObject>();
		growth = new List<Vector3>();
		decay = new List<Vector3>();
		//UpdateEnvironment();
	}
	void Start(){
		DayActivator.Check();
	}

	public int GetCurrentHealth(){
		int e = ViroTrack.me.TotalzHealth(Zone.currentZone);
		//Debug.Log("Zone current health = " + e);
		return e;
	}

	public float CheckFlowerDensity(float r, Vector3 pos){
		int f = 0;
		foreach(Flower fr in flwrs){
			if(fr.state != 0)
			if (Vector3.Distance(pos, fr.transform.position) < r){
				f++;
			}
		}
		return ((float) f / r);
	}

	public bool PosFree(Vector3 pos){
		flwrs = Zone.currentSubZone.GetComponentsInChildren<Flower>();
		foreach(Flower fr in flwrs){
			if (Vector3.Distance(pos, fr.transform.position) < 0.3f){
				return false;
			}
		}
		return true;
	}

	public void UpdateEnvironment(){
		UpdateEnvironment(true);
	}
	public void UpdateEnvironment(bool grow){
		VisitorSpawner.me.spawnedVisitors = 0;
		//Debug.Log("upadting enviornonmt");
		DayActivator.Check();
		soilBuddies = GameObject.FindGameObjectsWithTag("Soil Buddy");
		rots = Zone.currentZone.GetComponentsInChildren<Rot>(false);

		//reset growth/decay paramterss
		foreach(GameObject g in grasses){
			GameObject.Destroy(g);
		}
		foreach(GameObject g in decayPs){
			GameObject.Destroy(g);
		}
		foreach(GameObject g in growthPs){
			GameObject.Destroy(g);
		}
		growth.Clear();
		decay.Clear();
		grasses.Clear();

		foreach(GameObject g in soilBuddies){
			SpawnGrasses(g.transform.position);
		}

		List<Flower> ft = new List<Flower>();
		ft.AddRange(Zone.currentSubZone.GetComponentsInChildren<Flower>());
		ft.AddRange(Zone.currentSubZone.addedPrefabs.GetComponentsInChildren<Flower>());	
		flwrs = ft.ToArray();
	

		//if(rots.Length > 0) Zone.currentSubZone.cursed = true;
		//else Zone.currentSubZone.cursed = false;

		//GROW
		if(grow){
			WormTracker.me.AddHunger();
			foreach(Flower f in flwrs){
				if(!IsCloseToRot(rots, f)){
					if (f.fertalized){
						f.Spread();
					}
					if (IsNearBuddy(f, soilBuddies) || f.watered){
						f.Fertalize();
						f.watered = false;
					}
					else{
						f.Grow();
					}
				}
				else{
					f.SetWithered();
				}
			}
		}



		Invoke("FrameCheck", 0.1f);
	}

	bool IsCloseToRot(Rot[] rots, Flower f){
		float d = 6f;
		foreach(Rot rot in rots){
			if(Vector3.Distance(rot.transform.position, f.transform.position) < d){
				return true;
			}
		}
		return false;
	}

	void CheckNPCS(NPC2[] npc, Rot[] rots){
		Debug.Log("check npcs " + npc.Length + " " + rots.Length);
		foreach(NPC2 np in npc){
			if(np.rot_sensitive){
				bool s_a = true;
				if(rots.Length > 0){
					foreach(Rot r in rots){
						if(Vector3.Distance(r.transform.position, np.transform.position) < 15f){
							s_a = false;
						}
					}
				}
				np.gameObject.SetActive(s_a);
			}
		}
	}

	void FrameCheck(){
		//update other environment stuff
		flwrs = Zone.currentZone.GetComponentsInChildren<Flower>();
		GrowArea.me.UpdateGrowArea(flwrs);
		ViroTrack.me.LogCurrent();
		MusicLoader.me.UpdateEnvironmentMusic();
		ViroThresh.CheckAll();

		CheckNPCS(Zone.currentSubZone.GetComponentsInChildren<NPC2>(true), rots);

		WormEgg[] wormys = Zone.currentZone.GetComponentsInChildren<WormEgg>();
		foreach(WormEgg w_e in wormys){ w_e.Check();}
		//check visitors
		if(Zone.currentSubZone.cursed == false)
			VisitorSpawner.me.CheckVisitors(GrowArea.me.allGrowAreas.ToArray());

		QuestTracker.UpdateQuests();
			
	}

	public bool IsNearBuddy(Flower f, GameObject[] buddies){
		foreach(GameObject g in buddies){
			if (Vector3.Distance(f.transform.position, g.transform.position) < 2f){
				return true;
			}
		}
		return false;
	}

	public void AddGrowth(Vector3 pos){
		SpawnGrasses(pos);
		growth.Add(pos);
		GameObject g = GameObject.Instantiate(growthParticle, Zone.currentSubZone.transform);
		g.transform.position = pos;
		growthPs.Add(g);
	}

	public void AddDecay(Vector3 pos){
		decay.Add(pos);
		GameObject g = GameObject.Instantiate(decayParticle, Zone.currentSubZone.transform);
		g.transform.position = pos;
		decayPs.Add(g);
	}

	void SpawnGrasses(Vector3 pos){
		GameObject grs = Prefabber.me.GetFromName("grass");
		int num = 1;
		for(int i = 0; i < num; i++){
			Vector3 randOffset = new Vector3(Random.value - 0.5f, 0f, Random.value - 0.5f) * 3f;
			Vector3 t = pos + randOffset;
			if (Physics.Raycast(pos + t, Vector3.down, 1f)){
				GameObject g = GameObject.Instantiate(grs, Zone.currentZone.transform);
				g.transform.position += t;
				grasses.Add(g);
			}
		}
	}

}
