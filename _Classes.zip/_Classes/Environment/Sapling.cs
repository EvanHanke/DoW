﻿using UnityEngine;

public class Sapling : MonoBehaviour {

	//turns into a plant gameobject over time

	public GameObject growPrefab;
	public float growtime = 10; //seconds
	float awakeTime;
	public int xp;

	//for setting the information of the sapling
	public void Set(GameObject go, float t, int xp){
		growPrefab = go;
		growtime = t;
		awakeTime = Time.time;
		this.xp = xp;
	}

	void Awake () {
		awakeTime = Time.time;
	}
	
	void Update () {
		if (Time.time > (awakeTime + growtime) ){
			Grow();
		}
	}

	void Grow(){
		PlayerStats.AddXp(xp);
		GameObject go = GameObject.Instantiate(growPrefab);
		go.transform.position = transform.position;
		go.transform.SetParent(transform.parent);
		GameObject.Destroy(gameObject);
	}
}
