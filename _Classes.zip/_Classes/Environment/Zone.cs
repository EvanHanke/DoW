﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class Zone : MonoBehaviour {
	public string displayName;
	public ViroMusic vMusic;

	public Color backgroundColor = Color.black;
	public Color uiColor = Color.black;
	public ZoneHueShift zone_hueshift;
	public Material skybox_mat;

	public Vector3 cameraOffest = Vector3.zero;
	public Vector3 cameraTilt;
	public bool staticCamera = false;
	public ZoneSave mySave;
	protected static GameObject player;
	public static Zone currentZone;
	public static Zone currentSubZone;
	[HideInInspector]
	public Zone parentZone; //reference to parent zone from sub zone

	//added items stored under empty parent gameobject
	[HideInInspector]
	public GameObject addedPrefabs;

	//every Zone requires a unique ID to save properly
	public int myID = 0;
	public Vector3[] warpPoints;
	public float lowerBound = -20f;

	public int timeLastUpdated;
	public bool cursed = false;

	bool enviro_load = false;
	int time_catchup_max = 4;

	//save data
	[HideInInspector]
	public Chest[] chests;
	[HideInInspector]
	public NPCInteractor[] npcs;
	[HideInInspector]
	public Interactable[] items;
	[HideInInspector]
	public AreaPopulater[] a_ps;
	[HideInInspector]
	public StateSaver[] states;
	[HideInInspector]
	public Vehicle[] vehicles;

	public static GameObject OpenZone(string zone){
		GameObject targetZone = Resources.Load("Zones/" + zone) as GameObject;
		targetZone = GameObject.Instantiate(targetZone);
		targetZone.name = zone;
		targetZone.SetActive(true);
		targetZone.transform.SetParent(GameObject.Find("TheGlobe").transform);
		currentZone = targetZone.GetComponent<Zone>();
		UIController.me.RemoveLabel();
		return targetZone;
	}

	public static void OpenSubZone(string subZone){
		foreach(SubZone t in currentZone.GetComponentsInChildren<SubZone>(true)){
			if (t.name == subZone){
				currentSubZone = t.GetComponent<SubZone>();
				t.gameObject.SetActive(true);

			}
			else t.gameObject.SetActive(false);
		}
	}

	//public List<GameObject> prefabs = new List<GameObject>(); //prefabs dropped by the player
	public static void ChangeZone(string targetZoneName,string subZone, Vector3 pos){
		ZoneChange zc= new ZoneChange(targetZoneName, subZone, pos);
		ZoneChanger.me.StartCoroutine("ChangeZone", zc);
	}

	public static void ChangeZone(string targetZoneName,string subZone, int pos){
		ZoneChange zc= new ZoneChange(targetZoneName, subZone, pos);
		ZoneChanger.me.StartCoroutine("ChangeZone", zc);
	}



	public static void Save(){
		SaveManager.me.SaveZone(currentSubZone);
	}

	public static void Load(){
		
		Debug.Log("loading");
		ZoneSave zs = null;
		if(SaveManager.me!=null)
		zs = SaveManager.me.RetrieveSave(currentSubZone.myID);

		if (zs != null){
			zs.Load(currentSubZone);
			Debug.Log("loaded zone " + zs.ToString());
			Debug.Log("current subzone " + currentSubZone.name);

		}
		else{
			Debug.Log("Trying to load non existing zone save " + currentZone.name);
			foreach(StateSaver ss in currentSubZone.GetComponentsInChildren<StateSaver>()){
				ss.Init();
			}
		}
	}

	void Awake(){

		if (!(this is SubZone)){
			myID *= 100;
			SubZone[] subs = GetComponentsInChildren<SubZone>(true);
			for(int i = 0; i < subs.Length; i++){
				subs[i].myID = myID+1+i;
				subs[i].parentZone = this;
				subs[i].addedPrefabs = new GameObject("Added Items");
				subs[i].addedPrefabs.transform.SetParent(transform);
				subs[i].addedPrefabs.name = name + " prefabs";
			}
			addedPrefabs = new GameObject("Added Items");
			addedPrefabs.transform.SetParent(transform);
			addedPrefabs.name = name + " prefabs";
			//current zone will be this root Zone object regardless if player is sent to a child zone
			player = (player == null)? GameObject.Find("Player") : player;

			//Initialize from scratch
			if(currentZone == null){
				currentZone = currentSubZone = this;
				SubZone sz = GetComponentInChildren<SubZone>();
				if(sz != null) currentSubZone  =sz;
			}
		}

	}

	void Start(){
		//load grab "savable" components
		items = GetComponentsInChildren<Interactable>(true);
		states = GetComponentsInChildren<StateSaver>(true);


		if (currentSubZone == this){
			Load();

			CameraEfx.me.SetFromZone(zone_hueshift);
			if(FakeBackground.me!=null)
				FakeBackground.me.UpdateShader();

			Environment.me.UpdateEnvironment(false);
			WormTracker.me.RefreshZone();
		}


		Debug.Log("CURR ZONE : " + currentZone.name + " \nCURR SUBZONE : " + currentSubZone.name + 
			" \n THIS ZONE : " + name);

	}

	void OnDrawGizmos(){
		if (warpPoints != null){
			for(int i = 0; i < warpPoints.Length; i++){
				Gizmos.DrawIcon(warpPoints[i]+transform.position, "warpicon.png", true);
				//UnityEditor.Handles.Label(warpPoints[i], i.ToString());
			}
		}
	}

	void Update(){
		//when the player falls
		if (player.transform.position.y < lowerBound){
			Debug.Log("out of bounds");
			PlayerController.ResetPos();
			AudioLoader.PlaySound("noisey1", 2f, true, 0.1f);
		}

		/*
		if(mySave != null){
			if(mySave.last_updated < TimeTracker.me.day){
				if(time_catchup_max > 0){
					mySave.last_updated++;
					time_catchup_max--;
					Environment.me.UpdateEnvironment();
				}
			}
		}*/
	}

}

[System.Serializable]
public class ZoneHueShift{
	public float sat = 0;
	public float r = 0;
	public float g = 0;
	public float b = 0;
}

public class ZoneChange{
	public string zone, subzone;
	public int door;
	public Vector3 pos;

	public ZoneChange(string a, string b, int c){
		zone = a;
		subzone = b;
		door = c;
		pos = Vector3.zero;
	}

	public ZoneChange(string a, string b, Vector3 c){
		zone = a;
		subzone = b;
		door = -1;
		pos = c;
	}
}