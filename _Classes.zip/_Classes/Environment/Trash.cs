﻿using UnityEngine;

public class Trash : MonoBehaviour {
	//displays random sprite

	public Sprite[] all_trash;

	void Awake(){
		SpriteRenderer s_r = GetComponentInChildren<SpriteRenderer>();
		int random_index = (int)(Mathf.Lerp(0f, 8f, Random.value));
		s_r.sprite = all_trash[random_index];
	}

	public static bool IsNearTrash(Vector3 pos, float distance){
		Trash[] tts = Zone.currentZone.GetComponentsInChildren<Trash>();
		foreach(Trash t in tts){
			if(Vector3.Distance(t.transform.position, pos) <= distance){
				return true;
			}
		}
		return false;
	}
}
