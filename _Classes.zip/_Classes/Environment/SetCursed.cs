﻿using UnityEngine;

public class SetCursed : MonoBehaviour {

	void Start(){
		CameraEfx.me.inverted = true;
	}
}
