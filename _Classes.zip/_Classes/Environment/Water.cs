﻿using UnityEngine;

public class Water : MonoBehaviour {

	void OnCollisionEnter(Collision c){

	}
}
