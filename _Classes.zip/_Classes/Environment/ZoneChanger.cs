﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class ZoneChanger : MonoBehaviour {


	public static MonoBehaviour me;
	// Use this for initialization
	void Awake () {
		me = this;
	}
	public IEnumerator ChangeZone(ZoneChange zc){
		//string targetZoneName, string subZone, int targetPoint
		string targetZoneName = zc.zone;
		string subZone = zc.subzone;
		int target = zc.door;
		Vector3 pos = zc.pos;
		bool alt_flag = (target == -1);
		Transform player = PlayerMovement.me.transform;

		if(Zone.currentZone != null){
			Zone.Save();
		}
		// && subZone != Zone.currentSubZone.name
		if (  Zone.currentZone != null){
			//save zone state before deleting
			if(Zone.currentZone != null){
				GameObject.Destroy(Zone.currentZone.gameObject);
				Debug.Log("before yield");
				yield return new WaitForEndOfFrame();
				Debug.Log("after yield");
				Zone.OpenZone(targetZoneName);
			}
			//creating zone from empty world
			else{
				Zone.OpenZone(targetZoneName);
			}

			//activate sub zone and deactivate other sub zones
			if (subZone != null && subZone.Length > 1 && subZone != targetZoneName){
				Zone.OpenSubZone(subZone);
			}
			else Zone.currentSubZone = Zone.currentZone;

			string d_n = Zone.currentSubZone.displayName;
			if(d_n.Length == 0) d_n = Zone.currentSubZone.name;
			PushMessage.Push(d_n);

		}
		//update player position
		if(alt_flag == false) {
			Vector3 aa = Zone.currentSubZone.warpPoints[target]+Zone.currentSubZone.transform.position;
			RaycastHit hit;
			if(Physics.Raycast(aa+Vector3.up, Vector3.down, out hit, 2f)){
				aa = hit.point;
			}
			player.transform.position = aa;
		}
		else{
			player.position = pos;
		}
		PlayerController.me.resetPos = player.transform.position;

		if(PlayerMovement.me.ride != null){
			PlayerMovement.me.ride.transform.position = player.transform.position;
			PlayerController.me.Ride(PlayerMovement.me.ride);
		}


		//update camera
		//Debug.Log("SETTING CAM INGO WITH " + currentZone.name);
		CameraFollower.me.ZoneUpdate(Zone.currentSubZone);

		Resources.UnloadUnusedAssets();
	}
}
