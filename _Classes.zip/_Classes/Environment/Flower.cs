﻿using UnityEngine;

public class Flower : InteractionScript {

	StateSaver stater;
	public int state = 1;
	bool sheared = false;
	Shearable shearable;
	SpriteRenderer sr;
	int last_updated;
	public Growable g;
	Interactable myInteractable;
	public bool fertalized = false;
	public bool watered = false;
	GameObject wetParticles;
	public LocalGrowArea myGrowArea;
	BoxCollider efxTrigger;
	Rigidbody efxRB;
	public GrowNode myNode;

	Vector3 pos, prevpos;
	Transform ground;

	public Growable.G GetState(){
		return g.life_cycle[state].myState;
	}

	public override string LabelDesc(){
		return "Pick " + g.life_cycle[state].name;
	}

	public override void OnInteract(){
		player.AcquireItem(g, 1, state);
		GameObject.Destroy(gameObject);
	}

	public bool IsGrown(){
		return (g.life_cycle[state].myState == Growable.G.grown);
	}

	public void Awake(){
		fertalized = false;
		myInteractable = GetComponent<Interactable>();
		shearable = gameObject.AddComponent<Shearable>();
		player= GameObject.Find("Player").GetComponent<PlayerController>();
		stater = GetComponent<StateSaver>();
		stater.onLoad = LoadState;
		stater.onInit = Init;
		sr = GetComponentInChildren<SpriteRenderer>();
		GetComponent<Interactable>().SetScript(this);
		efxTrigger = gameObject.AddComponent<BoxCollider>();
		efxTrigger.isTrigger = true;
		efxTrigger.size = (Vector3.one/4f);
		efxTrigger.center = new Vector3(0f, 0.5f, 0f);
		efxRB = gameObject.AddComponent<Rigidbody>();
		efxRB.constraints = RigidbodyConstraints.FreezeRotation;
		efxRB.isKinematic = true;

		gameObject.AddComponent<GroundFollower>();

		base.Awake();
	}

	public void Start(){
		RaycastHit hit;
		/*
		if(Physics.Raycast(transform.position, Vector3.down, out hit, 3f)){
			ground = hit.collider.transform;
			pos = prevpos = ground.transform.position;
			//transform.position = new Vector3(transform.position.x, hit.point.y, transform.position.z);
		} */
	}

	public void Init(){
		SetState(state, false);
	}

	void AdvanceTime(){
		if (wetParticles != null){
			GameObject.Destroy(wetParticles);
		}
	}

	void OnDestroy(){
		if (wetParticles != null){

			GameObject.Destroy(wetParticles);
		}
	}

	public void Grow(){
		//if(g.life_cycle[state].myState == Growable.G.budding && !watered) return;
	
		float grow_chance = 1f;
		if(myNode !=null && watered == false){
			int nn = myNode.neighbors.Count;
			if(nn < 3) grow_chance = 1f;
			else grow_chance = 0.5f;
		}
		else if (watered == true){
			grow_chance = 1f;
		}
		if(Trash.IsNearTrash(transform.position, 4f)){
			if(GetState() != Growable.G.grown)
				grow_chance = .4f;
			else grow_chance = 1f;
		}

		if(Random.value <= grow_chance){
			SetState(state + 1);
		}
		if(watered) ResetSheared();

		stater.my_time++;
		fertalized = false;
		watered = false;
		stater.Save("w", "0");
	}
	public void Fertalize(){
		ResetSheared();
		switch(g.life_cycle[state].myState){
		case Growable.G.budding:
			Grow();
			fertalized = true;
			Environment.me.AddGrowth(transform.position);
			break;
		case Growable.G.grown:
			fertalized = true;
			Environment.me.AddGrowth(transform.position);
			break;
		case Growable.G.withered:	
			SetState(state-1);
			break;
		}
	}
	public bool Spread(){
		//Debug.Log("trying to grow: area health = " + myGrowArea.area_health);
		GameObject bud = g.droppablePrefab;
			for(int i = 0; i < g.bounty; i++){
				Vector3 offset = new Vector3((Random.value - 0.5f)*4f, 0f, (Random.value - 0.5f)*4f);
				Ray r = new Ray(transform.position + Vector3.up, Vector3.down);
				if(Physics.Raycast(r, 2f) && 
				(Environment.me.CheckFlowerDensity(1f, transform.position+offset) <= 2f)){
					GameObject n = GameObject.Instantiate(bud, transform.position + offset, Quaternion.identity);
					n.transform.SetParent(Zone.currentSubZone.addedPrefabs.transform);
					n.GetComponent<StateSaver>().my_time = TimeTracker.me.day;
					n.GetComponent<Flower>().g = g;
					n.GetComponent<Flower>().SetState(0);

				}
				else return false;
			}
			fertalized = false;
			return true;
		//GameObject.Destroy(gameObject);
	}
	public void SetState(int s){
		SetState(s, true);
	}
	public void SetState(int s, bool grow){
		Growable.G prevState = g.life_cycle[state].myState;
		if (s < 0) s = 0;
		else if (s >= g.life_cycle.Length){
			if (fertalized == false){
				s = g.life_cycle.Length-1;
				}
			/*
			if (Spread()){
				Debug.Log("DESTROYY STASTE " + s);
				stater.my_state = s;
				state = s;
				GameObject.Destroy(gameObject);
				return;
			}
			*/
		}
		stater.my_state = s;
		state = s;
		//Debug.Log("state" + state);
		GrowState gs = g.life_cycle[s];
		sr.sprite = gs.worldSprite;
		switch(gs.myState){

		case Growable.G.budding:
			myInteractable.enabled = false;
			shearable.enabled = false;
			break;
		case Growable.G.grown:
			if(prevState == Growable.G.grown){
				if(Random.value <= 0.5f && grow)
					Spread();
			}
			ResetSheared();
			myInteractable.enabled = true;
			shearable.enabled = true;
			break;
		case Growable.G.clipped:
			myInteractable.enabled = true;
			shearable.enabled = false;
			break;
		case Growable.G.withered:	
			Environment.me.AddDecay(transform.position);
			myInteractable.enabled = true;
			shearable.enabled = false;
			break;
		}
		//CheckClipped();
		//Debug.Log(currentItem.name);
	}
	public void SetWithered(){
		SetState(g.life_cycle.Length-1);
	}
	void ResetSheared(){
		stater.Save("clipped", "0");
		sheared = false;
		shearable.bounty = g.bounty;
		shearable.shearableItem = g;
		if(g.life_cycle[state].myState == Growable.G.grown){
			sr.sprite = g.life_cycle[state].worldSprite;
		}
	}
	void Update(){

		if (shearable != null)
		if (shearable.bounty == 0 && sheared == false && g.life_cycle[state].myState == Growable.G.grown){
			PlayerStats.AddXp(g.harvest_xp);
			Shear();
		}

		if (wetParticles != null && watered == false){
			GameObject.Destroy(wetParticles);
		}

		if(ground != null){
			prevpos = pos;
			pos = ground.position;
			Vector3 delta = pos - prevpos;
			transform.position += delta;
			if(CheckGrounded.Check(transform.position) == false){
				ground = null;
			}
		}
	}
	void Shear(){
		sheared = true;
		stater.Save("clipped", "1");
		sr.sprite = g.clippedSprite;
	}

	public void LoadState(){
		SetState(stater.my_state, false);
		if(stater.Get("w") == "1"){
			SetWatered();
		}
		if(stater.Get("clipped") == "1"){
			Shear();
		}
	}

	public void OnTriggerEnter(Collider c){
		Damager d = c.GetComponent<Damager>();
		if(d != null){
			if (d.damage == 0 && d.water){
				SetWatered();
			}
		}
	}

	public void SetWatered(){
		if (!watered){
			watered = true;
			stater.Save("w", "1");
			wetParticles = GameObject.Instantiate(Particallor.me.GetParticle("WetParticles"), transform.parent);
			wetParticles.transform.position = transform.position;
		}
	}

	public override void OnApproach(){
		GetComponent<Interactable>().CheckAltScipts();
		//Debug.Log("approached");
	}
}
