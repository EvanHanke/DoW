﻿using UnityEngine;
using System.Collections.Generic;

public class PlantEffector : MonoBehaviour{

	public static PlantEffector me;
	public enum PEfx {sleep, wake}

	public PlantEffect[] p_efx;

	public void Awake(){
		me = this;
	}

	public void CheckEfx(LocalGrowArea growArea){
		//check to see if any effects can be activated
		//calculate "sub grow areas" based on just 1 kind of plant
		foreach(PlantEffect effect in p_efx){
			//get list of relevant plants within the zone
			Debug.Log("checking effect in grow area of size " + growArea.myNodes.Count);
			Growable g = effect.plant;
			List<GrowNode> contained = new List<GrowNode>();
			foreach(GrowNode gg in growArea.myNodes){
				if ((g == null || gg.myFlwr.g == g) && gg.myFlwr.IsGrown()){
					contained.Add(gg);
				}
			}
			Debug.Log("effect found " + contained.Count + " relevant samples");
			if(contained.Count >= effect.reqNumber){
				//calculate disntances and sub areas
				foreach(GrowNode cc in contained){
					cc.CalcNeighbors(contained);
				}
				foreach(GrowNode cc in contained){
					cc.CalcLocalZone();
				}

				//check for relevant sub areas to apply the effect

				List<LocalGrowArea> checkedAreas = new List<LocalGrowArea>();
				foreach(GrowNode cc in contained){
					if (!checkedAreas.Contains(cc.myArea)){
						Debug.Log("checking area");
						checkedAreas.Add(cc.myArea);
						if(cc.myArea.myNodes.Count >= effect.reqNumber){
							//apply the effect to all units within the area
							switch(effect.effect){
							case PEfx.sleep: SetSleep(cc.myArea); break;
							case PEfx.wake: SetAwake(cc.myArea); break;
							}
						}
					}
				}
			}
		}
	}

	//make sleepable units fall asleep within a zone
	public void SetSleep(LocalGrowArea lga){
		Sleepable[] sleepy = Zone.currentSubZone.GetComponentsInChildren<Sleepable>();
		foreach(Sleepable s in sleepy){
			if (lga.CheckContained(s.transform.position)){
				s.FallAsleep();
			}
		}
	}

	//wake wakable units wake up within a zone
	public void SetAwake(LocalGrowArea lga){
		Sleepable[] sleepy = Zone.currentSubZone.GetComponentsInChildren<Sleepable>();
		foreach(Sleepable s in sleepy){
			if (lga.CheckContained(s.transform.position)){
				Debug.Log("setting awake");
				s.WakeUp();
			}
		}
	}
}

[System.Serializable]
public class PlantEffect{
	public PlantEffector.PEfx effect;
	public Growable plant;
	public int reqNumber;
}