﻿using UnityEngine;

public class SubZone : Zone {
	
	//Like a zone, but exists within a greater system


}
