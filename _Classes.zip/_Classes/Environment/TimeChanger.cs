﻿using UnityEngine;

public class TimeChanger : MonoBehaviour {
	public int currentStage;
	TimeStage[] myStages;
}

[System.Serializable]
public class TimeStage{
	public GameObject prefab;
	public float time;
}
