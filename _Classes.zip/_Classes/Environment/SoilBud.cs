﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoilBud : MonoBehaviour {

	StateSaver save;
	int life;

	void Awake(){
		save = GetComponent<StateSaver>();
		life = 3;
		save.my_time = 3;
	}

	void Update(){
		if (life != save.my_state){
			life = save.my_state;
		}
	}

	void AdvanceTime(){
		LocalGrowArea lga = null;
		foreach(Flower f in Environment.me.flwrs){
			if (Vector3.Distance(f.transform.position, transform.position) < 2f){
				lga = f.myGrowArea;
			}
		}
		if (lga != null){
			life--;
			save.my_state--;
			if (life <= 0){
				GameObject.Destroy(gameObject);
			}
			lga.area_health++;
		}
	}
}
