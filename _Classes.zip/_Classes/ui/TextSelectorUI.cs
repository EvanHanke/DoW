﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextSelectorUI : MonoBehaviour {

	/*
	 * for displaying and selecting dialogue response topics
	 */ 

	//components to update based off state
	Text[] text;
	RectTransform selector;
	RectTransform topIndicator, botIndicator;

	//state information
	int scroll; //scroll offset
	int currSelected; //currently selected option
	string[] options; //option

	void Awake(){
		//Grab componenets
		text = GetComponentsInChildren<Text>();
		RectTransform[] rts = GetComponentsInChildren<RectTransform>();
		foreach(RectTransform rt in rts){
			switch(rt.name){
			case "Selector":
				selector = rt;
				break;
			case "BotIndicator":
				botIndicator = rt;
				break;
			case "TopIndicator":
				topIndicator = rt;
				break;
			}
		}
		scroll = currSelected = 0;
		options = new string[2];
		for(int i = 0; i < 2; i++){
			options[i] = "this is option" + i;
		}
		UpdateVisual();
	}


	void Update () {
		if (MyInput.GetState("UP") == 'p'){
			AudioLoader.PlayMenuBlip();
			currSelected = (currSelected > 0)? currSelected - 1 : options.Length-1;
			UpdateVisual();
		}

		if (MyInput.GetState("DOWN") == 'p'){
			AudioLoader.PlayMenuBlip();
			currSelected = (currSelected < options.Length - 1)? currSelected + 1: 0;
			UpdateVisual();
		}
	}

	public void Set(string[] options){
		this.options = options;
		scroll = currSelected = 0;
		UpdateVisual();
	}
	public int Selected(){
		return currSelected;
	}
	//update visual
	void UpdateVisual(){
		UpdateScrollOffset();
		UpdateText();
		UpdateSelector();
		UpdateIndicators();
		//Debug.Log("curr selected " + currSelected + " scroll offest " + scroll );
	}

	void UpdateScrollOffset(){
		scroll = (currSelected > 2)? currSelected-2 : 0;
	}

	void UpdateText(){
		int remainingOptions = options.Length - scroll;
		int numToShow = (remainingOptions < 3)? remainingOptions : 3;
		//update the text with option string
		for(int i = 0; i < numToShow; i++){
			text[i].text = options[i+scroll];
		}
		//deactivate unused text
		for(int i = 2; i >= numToShow; i--){
			text[i].text = " ";
		}
	}

	void UpdateSelector(){
		float newY = -(currSelected - scroll) * 33f;
		float newX = selector.anchoredPosition.x;
		selector.anchoredPosition = new Vector2(newX, newY);
	}

	void UpdateIndicators(){
		//top
		if (options.Length-scroll > 3)
			botIndicator.gameObject.SetActive(true);
		else
			botIndicator.gameObject.SetActive(false);
		//bottom
		if (scroll > 0)
			topIndicator.gameObject.SetActive(true);
		else
			topIndicator.gameObject.SetActive(false);
	}

}
