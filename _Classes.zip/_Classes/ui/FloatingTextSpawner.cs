﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FloatingTextSpawner : MonoBehaviour {

	public GameObject textPrefab;
	static GameObject player;
	static FloatingTextSpawner fts;

	static float queTime = 0.8f; //time between each message

	static Dictionary<Transform, Queue> quedMsgs = new Dictionary<Transform, Queue>();

	void Awake(){
		fts = this;
		player = GameObject.Find("Player");

		//SpawnText("where am I...");
	}

	static void SpawnText(FloatingMsg f){
		SpawnText(f.msg, f.color, f.target);
	}

	public static void SpawnText(string s){
		SpawnText(s, Color.white);
	}

	public static void SpawnText(string s, Color c){
		SpawnText(s, c, player.transform);
	}

	public static void SpawnText(string s, Color c, Transform t){
		SpawnText(s, c, t, null);
	}

	public static void SpawnText(string s, Color color, Transform where, string sound){
		
		if (quedMsgs.ContainsKey(where)){
			quedMsgs[where].msgs.Add(new FloatingMsg(s, color, where, sound));
		}
		else{
			quedMsgs[where] = new Queue(new FloatingMsg(s, color, where));
			ImmediateSpawnText(quedMsgs[where].Pop());
		}
			
	}

	static void ImmediateSpawnText(FloatingMsg msg){
		if(msg.target == null) return;
		GameObject go = GameObject.Instantiate(fts.textPrefab, msg.target);
		BoxCollider go_bc = msg.target.GetComponent<BoxCollider>();
		if (go_bc != null)
			go.transform.position += new Vector3(0f, (go_bc.bounds.extents.y*2f)+0.1f, 0f);
		go.GetComponent<TextMesh>().text = msg.msg;
		go.GetComponent<TextMesh>().color = msg.color;
		go.GetComponent<BackResizer>().Init();

		if(msg.sound != null){
			AudioLoader.PlaySound(msg.sound, 1f, true, 0.3f);
		}
	}

	void Update(){
		foreach(Transform t in quedMsgs.Keys){
			if (quedMsgs[t].lastPushTime < (Time.time - queTime) && quedMsgs[t].msgs.Count > 0){
				ImmediateSpawnText(quedMsgs[t].Pop());
			}
		}
	}

}

//Each transform has its own queue
class Queue{
	public List<FloatingMsg> msgs;
	public float lastPushTime;

	public Queue(FloatingMsg msg){
		lastPushTime = 0f;
		msgs = new List<FloatingMsg>();
		msgs.Add(msg);
	}

	public FloatingMsg Pop(){
		FloatingMsg msg = msgs[0];
		msgs.RemoveAt(0);
		lastPushTime = Time.time;
		return msg;
	}
}

class FloatingMsg{
	public string msg;
	public Color color;
	public Transform target;
	public string sound;

	public FloatingMsg(string s, Color c, Transform t){
		msg = s;
		color = c;
		target = t;
	}
	public FloatingMsg(string s, Color c, Transform t, string snd){
		msg = s;
		color = c;
		target = t;
		sound = snd;
	}
}