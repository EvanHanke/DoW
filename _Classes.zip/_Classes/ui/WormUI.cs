﻿using UnityEngine;
using UnityEngine.UI;

public class WormUI : MonoBehaviour {

	string worm_name;
	WormAI my_worm;
	Text text;
	UserInputter uin;

	string[] msgs = {"It is just vibing.", "It acknowledges your vibe. \nPress <Z> to give it a name."};

	void Awake(){
		text = GetComponentInChildren<Text>();
	}

	void Update () {
		if (MyInput.GetState("SHIFT", true) == 'p'){
			GameObject.Destroy(gameObject);
			GlobalStateMachine.GUnpause();
		}
		if(MyInput.GetState("Z", true) == 'p'){
			if(my_worm.isNameable){
				uin = UIController.me.UserInput();
				uin.onReturn = Name;
				uin.onCancel = Cancel;
				this.enabled = false;
			}
			else{
				GameObject.Destroy(gameObject);
				GlobalStateMachine.GUnpause();
			}
		}
	}

	public void Cancel(){
		this.enabled = true;
	}

	public void Name(string s){
		this.enabled = true;
		if(!string.IsNullOrEmpty(s)){

			my_worm.NameMe(s);
			Set(my_worm);
		}
		Interactor.me.RefreshLabels();
	}

	public void Set(WormAI worm){
		my_worm = worm;
		if(worm.worm.hunger > 0)
			text.text = worm.myname + " is hungry.\n";
		else
			text.text = worm.myname + " is not hungry.\n";
		
		if(worm.isNameable) text.text += msgs[1];
		else text.text += msgs[0];
	}

}
