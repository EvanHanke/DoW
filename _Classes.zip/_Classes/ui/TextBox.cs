﻿using UnityEngine;
using UnityEngine.UI;

public class TextBox : MonoBehaviour {
	public static bool freeze = false;
	//Prefabs
	//
	GameObject bodyObj;
	Text bodyTxt;
	GameObject userInputObj;	//

	//Print variables
	//
	string message = "empty message"; //the message to be displayed
	string currMessage = ""; //the message currently displayed
	string next; //text on the userinput

	float startTime;
	float nextTime;
	int counter = 0;
	bool done = true;
	public bool isDone(){ return done; }
	//

	//Style
	//
	float printSpeed = 5f; //characters per second
	Color textColor;
	//

	//animation
	bool destroy = false;

	void Awake () {
		//grab the components
		bodyTxt = GetComponentInChildren<Text>();
		//userInputTxt = texts[2];
		bodyObj = transform.GetChild(0).gameObject;
		bodyObj.SetActive(false);
		//userInputObj.SetActive(false);

		transform.localScale = new Vector3(1f, 0f, 1f);
	}

	public void Print(Line line){
		line.dEvent.Trigger();
		Print(line.message);
		//enable the components
		//grab the information for the message

	}
	public void Print(string s){

		message = s;

		//prep variables
		currMessage = "";
		done = false;
		counter = 0;


		//clear body text n disable userinput obj
		bodyTxt.text = "";
		bodyObj.SetActive(true);

		//start the clock
		startTime = Time.time;
		nextTime = 0f;	
	}

	public void QuickComplete(){
		AudioLoader.PlayTextBoxSound();
		Debug.Log("QuickComplete()");
		bodyTxt.text = message;
		done = true;
	}

	void Update () {

		//animations
		if (transform.localScale.y != 1f && destroy == false){
			transform.localScale = Vector3.MoveTowards(transform.localScale, Vector3.one, Time.deltaTime*2f);
			return;
		}

		else if (transform.localScale.y != 0f && destroy){
			transform.localScale = Vector3.MoveTowards(transform.localScale, new Vector3(1f, 0f, 1f), Time.deltaTime*2f);
			return;
		}
		else if (transform.localScale.y == 0f && destroy){
			GameObject.Destroy(gameObject);
		}

		//text printing
		
		if (!done && !freeze){
			if (Time.time > nextTime){
				AudioLoader.PlayTextBoxSound();
				do{
					if(counter < message.Length){
						currMessage += message[counter];
						counter++;
					}
				}
				while(counter < message.Length-1 && char.IsWhiteSpace(message[counter]) == false );
				nextTime = Time.time + (1f/printSpeed);
				if (currMessage.Equals(message))
					done = true;
				bodyTxt.text = currMessage;
			}
		}
		
	}

	//called so that the textbox can animate closing before destroying
	public void Destroy(){
		destroy = true;
	}
}
