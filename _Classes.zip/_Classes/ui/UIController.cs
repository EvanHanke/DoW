﻿using UnityEngine;
using UnityEngine.UI;

//Controller for activating/deactivating UI elements
public class UIController : MonoBehaviour {

	public static UIController me;

	GlobalStateMachine GSM;

	public GameObject textSelectorPrefab;
	public GameObject msgBoxPrefab;
	public GameObject labelPrefab;
	public GameObject buySellItemPrefab;
	public GameObject moneyPanelPrefab;
	public GameObject AltarMenuPrefab;
	public GameObject deathPrefab;
	public GameObject userInputPrefab;
	public GameObject bellPrefab;
	public GameObject wormholePrefab;

	GameObject textSelector;
	GameObject msgBox;
	GameObject label;  //default for z interactions
	GameObject altLabel; //the the case of x and c interactions
	GameObject money;

	bool updateMessage = false;
	public TextBox tb;

	void Update(){
		if(tb != null){
			if (MyInput.GetState("Z") == 'p'){
				if(!tb.isDone()) tb.QuickComplete();
				else{
					tb.Destroy();
					GSM.Unpause();
				}
			}
		}
	}

	void Awake(){
		GSM = GetComponentInParent<GlobalStateMachine>();
		me = this;
	}

	public bool labelOn(){
		return (label != null);
	}
	public bool msgBoxOn(){
		return (msgBox != null);
	}

	public void CreateBellMenu(){
		GameObject b = GameObject.Instantiate(bellPrefab);
		b.transform.SetParent(transform, false);
	}
	public GameObject CreateWHMenu(){
		GameObject b = GameObject.Instantiate(wormholePrefab);
		b.transform.SetParent(transform, false);
		return b;
	}
	public void CreateAltarMenu(MoonAltar ma){
		//create the message box
		GameObject am = GameObject.Instantiate<GameObject>(AltarMenuPrefab);
		am.transform.SetParent(transform, false);
		am.GetComponent<AltarMenu>().zone_target = ma.myWarpPoint;
		//pause the game
		GSM.Pause();
	}


	public TextBox CreateMsgBox(){
		return CreateMsgBox(false);
	}
	public TextBox CreateMsgBox(bool l_m){
		//create the message box
		msgBox = GameObject.Instantiate<GameObject>(msgBoxPrefab);
		msgBox.transform.SetParent(transform, false);

		if(l_m) 
		{
			Debug.Log("low msg");
			msgBox.GetComponent<RectTransform>().anchorMin = new Vector2(0.5f, 0f);
			msgBox.GetComponent<RectTransform>().anchorMax = new Vector2(0.5f, 0f);
			msgBox.GetComponent<RectTransform>().anchoredPosition = new Vector2(0f, 150f);
		}

		//pause the game
		GSM.Pause();

		return msgBox.GetComponent<TextBox>();
	}

	public void PrintMsg(string s){
		tb = CreateMsgBox();
		tb.Print(s);
	}
		
	public TextSelectorUI CreateTextSelector(string[] options){
		textSelector = GameObject.Instantiate<GameObject>(textSelectorPrefab);
		textSelector.transform.SetParent(transform, false);
		textSelector.GetComponent<TextSelectorUI>().Set(options);

		return textSelector.GetComponent<TextSelectorUI>();
	}

	public MoneyPanel CreateMoneyPanel(){
		if (money != null) return null;
		//create the money panel box
		money = GameObject.Instantiate<GameObject>(moneyPanelPrefab);
		money.transform.SetParent(transform, false);

		return money.GetComponent<MoneyPanel>();
	}

	public void CreateDeathPanel(){
		GameObject.Instantiate(deathPrefab, transform);
	}

	public void DestroyMoneyPanel(){
		if(money != null){
			GameObject.Destroy(money);
		}
	}

	public void DestroyMsgBox(){
		if (msgBox != null){
			//destroy the object
			GameObject.Destroy(msgBox);
			//unpause the world
			GSM.Unpause();
		} else{
			Debug.Log("Trying to destroy a message box while message box does not exist!");
		}
	}

	public void CreateLabel(string txt){
		
		//Debug.Log("label created");
		if (label != null){
			label.GetComponentInChildren<Text>().text = txt;
			return;
			}

		label = GameObject.Instantiate<GameObject>(labelPrefab);
		label.GetComponentInChildren<Text>().text = txt;
		label.transform.SetParent(transform, false);

	}

	public void CreateAltLabel(string txt){
		
		if (altLabel != null) return;
		altLabel = GameObject.Instantiate<GameObject>(labelPrefab);
		altLabel.GetComponentInChildren<Text>().text = txt;
		altLabel.transform.SetParent(transform, false);
		altLabel.GetComponent<RectTransform>().anchoredPosition += new Vector2(0, 70f);


	}

	public void RemoveLabel(){
		if (label != null){
			GameObject.Destroy(label);
		}
	}

	public void RemoveAltLabel(){
		if (altLabel != null){
			GameObject.Destroy(altLabel);
		}
	}

	public UserInputter UserInput(){
		GameObject inputter = GameObject.Instantiate(userInputPrefab);
		inputter.transform.SetParent(transform, false);
		return inputter.GetComponent<UserInputter>();
	}
}
