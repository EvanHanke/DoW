﻿using UnityEngine;
using UnityEngine.UI;

public class MenuController : MonoBehaviour {

	public static MenuController me;
	public static bool menuOpen = false;

	public GameObject inventoryPrefab;
	public GameObject selfPrefab;
	public GameObject inputterPrefab;
	public GameObject optionPrefab;
	public GameObject spellListPrefab;
	public GameObject questPrefab;
	public GameObject optionsPrefab;
	public GameObject quitUI;

	bool destroy = false;
	float wait;
	UIController ui;
	GlobalStateMachine GSM;

	int auto = -1;

	string[] labels = {"Speak", "Pockets", "Status", "Quest", "Spells", "Config", "Quit"};
	UIList options;

	public static bool destroyFlag = false; //if another window wants the menu to auto close after completes

	GameObject openWindow; //currently open ui window if not this

	//Text[] texts; //all text objects of the menu; not needed?
	int selected; //currently selected menu item
	RectTransform selector; //selector visual

	public static void InputShortcut(){
		GameObject inputter = GameObject.Instantiate(me.inputterPrefab);
		inputter.transform.SetParent(me.transform.parent, false);
	}

	void Awake () {
		me = this;
		menuOpen = true;
		options = GetComponent<UIList>();

		ui = GameObject.Find("UI").GetComponent<UIController>();
		//grab componenets
		GSM = GameObject.Find("Game").GetComponent<GlobalStateMachine>();
		GSM.Pause();
		selector = GameObject.Find("Selector").GetComponent<RectTransform>();
		wait = Time.time + Time.deltaTime;
		//ui.CreateMoneyPanel();

		options.Init(7, optionPrefab, 50, selector, labels);
		auto = -1;
		//transform.localScale = new Vector3(0f, 1f, 1f);

	}

	public void Shortcut(int option){
		auto = option;
	}
	
	void Update () {
		if (!(Time.time > wait)) return;

		//if another UI element is open
		if (openWindow != null) return;

		//animations
		/*
		if (transform.localScale.x != 1f && destroy == false){
			transform.localScale = Vector3.MoveTowards(transform.localScale, Vector3.one, Time.deltaTime*2f);
			return;
		}

		else if (transform.localScale.x != 0f && destroy){
			transform.localScale = Vector3.MoveTowards(transform.localScale, new Vector3(0f, 1f, 1f), Time.deltaTime*2f);
			return;
		}
		*/
		if (destroy){
			GameObject.Destroy(gameObject);
		}

		//if destroyflag is marked by another ui element
		if (destroyFlag && openWindow == null){
			destroyFlag = false;
			GameObject.Destroy(gameObject);
		}

		if (MyInput.GetState("UP", true) == 'p'){
			options.Dinc();
			AudioLoader.PlayMenuBlip();
		}
		if(MyInput.GetState("DOWN", true) == 'p'){
			AudioLoader.PlayMenuBlip();
			options.Inc();
		}

		selected = options.GetSelected();

		if (MyInput.GetState("Z", true) == 'r' || auto != -1){
			MyInput.Clear();
			AudioLoader.PlayMenuSelect();
			if(auto != -1) {
				destroyFlag = true;
				selected = auto;
			}
			auto = -1;
			switch(selected){
				case 0:
				//open user input
				openWindow = UIController.me.UserInput().gameObject;
				break;

				case 1:
				//open inventory
				GameObject inv = GameObject.Instantiate(inventoryPrefab);
				inv.transform.SetParent(transform.parent, false);
				openWindow = inv;
				break;

				case 2:
				//open self
				GameObject self = GameObject.Instantiate(selfPrefab);
				self.transform.SetParent(transform.parent, false);
				openWindow = self;
				break;

				case 3:
				//open Quest
				GameObject quest = GameObject.Instantiate(questPrefab);
				quest.transform.SetParent(transform.parent, false);
				openWindow = quest;
				break;

				case 4:
				//open Spells
				GameObject spells = GameObject.Instantiate(spellListPrefab);
				spells.transform.SetParent(transform.parent, false);
				openWindow = spells;
				break;

				case 5:
				GameObject ops = GameObject.Instantiate(optionsPrefab);
				ops.transform.SetParent(transform.parent, false);
				openWindow = ops;
				break;

				case 6:
				GameObject q= GameObject.Instantiate(quitUI);
				q.transform.SetParent(transform.parent, false);
				openWindow = q;
				break;
			}
		}
		else if (MyInput.GetState("SHIFT", true) == 'p'){
			destroy = true;
			AudioLoader.PlayMenuCancel();
		}

	}

	void UpdateSelectorVisual(){
		selector.anchoredPosition = new Vector3(0, -300-60*selected, 0);
	}

	void OnDestroy(){
		menuOpen = false;
		GSM.Unpause();
	}
		
}
