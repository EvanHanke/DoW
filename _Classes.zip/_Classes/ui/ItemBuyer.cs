﻿using UnityEngine;
using UnityEngine.UI;

public class ItemBuyer : MonoBehaviour{

	public delegate void OnTrade();
	public OnTrade onComplete, onCancel, onDestroy;

	GameObject buysell;
	Inventory playerInv;

	Text[] allTexts;
	Text buyText; //pointers for easy referencing the array
	Text infotext;

	Image takeItemSpr;
	Image giveItemSpr;
	RectTransform selector;
	int takeAmt, giveAmt;

	Item giveItem;
	Item takeItem;
	int quant = 1;
	int selected = 0;

	UIController ui;
	UIList list;

	public bool unique = false;

	string[] ops = {"Buy x for x", "Quit"};

	public void Set(GameObject i, Item take, Item give, int takeAmt, int giveAmt){
		buysell = i;
		takeItem = take;
		giveItem = give;
		this.takeAmt = takeAmt;
		this.giveAmt = giveAmt;
		ui = GameObject.Find("UI").GetComponent<UIController>();
		selector = GameObject.Find("Selector1").GetComponent<RectTransform>();
		buysell.GetComponentInParent<GlobalStateMachine>().Pause();

		Show();
	}

	public void Show(){
		playerInv = GameObject.Find("Player").GetComponent<Inventory>();

		buyText = GameObject.Find("BuyText").GetComponent<Text>();
		infotext = GameObject.Find("ItemInfo").GetComponent<Text>();
		infotext.text = Item.GetFullDesc(giveItem);
		takeItemSpr = GameObject.Find("TakeItemSprite").GetComponent<Image>();
		giveItemSpr = GameObject.Find("GiveItemSprite").GetComponent<Image>();
		UpdateLabels();

		AudioLoader.PlaySound("jingle", 2f, true, 0.5f);

		ops[0] = GetTxt();
		list = new UIList();
		list.Init(2, buyText.gameObject, 50f, selector, ops);

		Debug.Log("Show itembuyer");
	}


	public void Update() {
		if(MyInput.GetState("UP", true) == 'p'){
			list.Dinc();
			AudioLoader.PlayMenuBlip();
		}
		if(MyInput.GetState("DOWN", true) == 'p'){
			list.Inc();
			AudioLoader.PlayMenuBlip();
		}

		if (MyInput.GetState("RIGHT", true) == 'p' && !unique){
			//increase quantity
			quant++;
			UpdateLabels();
			AudioLoader.PlayMenuBlip();
		}
		else if (MyInput.GetState("LEFT", true) == 'p' && !unique){
			if (quant < 2) return;
			//increase quantity
			quant--;
			UpdateLabels();
			AudioLoader.PlayMenuBlip();
		}

		else if (MyInput.GetState("Z", true) == 'p'){
			//if u have enough money
			if(list.GetSelected() == 0){
				if (playerInv.QuantityOf(takeItem) >= quant * takeAmt){
					playerInv.RemoveItem(takeItem, quant * takeAmt); 
					PlayerController.me.AcquireItem(giveItem, quant * giveAmt);
					if (onComplete != null){
						onComplete();
						if(unique){
							GameObject.Destroy(buysell);
						}
					}
					return;
				}
			}
			else{
				//alternate cancel key
				if (onCancel != null){
					onCancel();
				}
				GameObject.Destroy(buysell);
			}
		}
		else if (MyInput.GetState("SHIFT", true) == 'p'){
			//alternate cancel key
			if (onCancel != null){
				onCancel();
			}
			GameObject.Destroy(buysell);
			//return true;
		}	
	}

	void UpdateLabels(){
		takeItemSpr.sprite = takeItem.image;
		giveItemSpr.sprite = giveItem.image;


	}

	string GetTxt(){
		return string.Format("Trade {0} {1} (You have {2}) for {3} {4}.", quant * takeAmt, takeItem.name, 
			playerInv.QuantityOf(takeItem), quant*giveAmt, giveItem.name);
	}

	void OnDestroy(){
		AudioLoader.PlayMenuCancel();
		if (onDestroy != null) onDestroy();
	}
}
