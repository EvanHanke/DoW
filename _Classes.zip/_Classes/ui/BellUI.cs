﻿using UnityEngine;
using UnityEngine.UI;

public class BellUI : MonoBehaviour {
	RectTransform selector;
	int selected;
	Vector3 sel_anchor;

	public void Start(){
		GlobalStateMachine.GPause();
		selector = transform.GetChild(1).GetComponent<RectTransform>();
		sel_anchor = selector.position;
	}

	public void Update(){
		if (MyInput.GetState("Z", true) == 'p'){
			GameObject.Destroy(gameObject);
			AudioLoader.PlaySound("Gong", .3f, true);
			if (selected == 0)
				CameraEfx.FadeInOut(1f, Advance);
			else{
				CameraEfx.FadeInOut(1f, Recall);
			}
		}
		if(MyInput.GetState("SHIFT", true) == 'p'){
			GameObject.Destroy(gameObject);
			GlobalStateMachine.GUnpause();
		}
		if(MyInput.GetState("DOWN", true) == 'p'){
			selected = (selected == 0)? 1 : 0;
			RefreshSelector();
		}
		else if(MyInput.GetState("UP", true) == 'p'){
			selected = (selected == 0)? 1 : 0;
			RefreshSelector();
		}
	}

	void RefreshSelector(){
		Vector3 pos = sel_anchor + new Vector3(0, -60f * selected, 0f);
		selector.position = pos;
	}

	public void Advance(){
		TimeTracker.AdvanceTime();
		GlobalStateMachine.GUnpause();

	}

	public void Recall(){
		AudioLoader.PlaySound("Gong", 1f, true);
		TimeTracker.RecallTime();
		GlobalStateMachine.GUnpause();
	}
}
