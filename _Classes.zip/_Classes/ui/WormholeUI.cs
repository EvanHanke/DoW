﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WormholeUI : MonoBehaviour {

	RectTransform selector;
	int selected;
	Vector3 sel_anchor;
	public Wormhole wh;

	public void Start(){
		GlobalStateMachine.GPause();
		selector = transform.GetChild(1).GetComponent<RectTransform>();
		sel_anchor = selector.position;
	}

	public void Update(){
		if (MyInput.GetState("Z", true) == 'p'){
			switch(selected){
			case 0:
				WormHoleSave w = Wormholer.me.GetNextLink(wh.my_save);
				if(w != null){
					Zone.ChangeZone(w.zone, w.subzone, new Vector3(w.x, w.y, w.z));
					GameObject.Destroy(gameObject);
					GlobalStateMachine.GUnpause();
				}
				else{
					PushMessage.Push ("You need at least 2 wormholes to be open");
				}
				break;
			case 1:
				//CLOSE
				GameObject.Destroy(gameObject);
				GameObject pc = GameObject.Instantiate(
					Prefabber.me.GetFromName("Paper Chain"));
				pc.transform.parent = Zone.currentSubZone.addedPrefabs.transform;
				pc.transform.position = wh.transform.position;
				Wormholer.me.Remove(wh.my_save);
				GameObject.Destroy(wh.gameObject);
				GlobalStateMachine.GUnpause();
				break;
			case 2:
				GameObject.Destroy(gameObject);
				GlobalStateMachine.GUnpause();
				break;
			}
		}
		if(MyInput.GetState("SHIFT", true) == 'p'){
			GameObject.Destroy(gameObject);
			GlobalStateMachine.GUnpause();
		}
		if(MyInput.GetState("DOWN", true) == 'p'){
			selected = (selected < 2)? selected+1 : 0;
			RefreshSelector();
		}
		else if(MyInput.GetState("UP", true) == 'p'){
			selected = (selected > 0)? selected - 1 : 2;
			RefreshSelector();
		}
	}

	void RefreshSelector(){
		Vector3 pos = sel_anchor + new Vector3(0, -40f * selected, 0f);
		selector.position = pos;
	}

}
