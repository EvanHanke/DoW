﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SpellsUIController : MonoBehaviour {

	//Creates a list of all the spells the player has discovered

	UIList spellList;
	Spell[] learnedSpells;
	Text manaCostTxt;
	Text descText;
	GameObject labelPrefab;
	RectTransform selector;
	Image glyph;

	void Awake(){
		List<Spell> s = new List<Spell>();
		foreach(Spell ss in SpellChecker.GetLearnedSpells()){
			if (!ss.hidden) s.Add(ss);
		}
		learnedSpells = s.ToArray();
		spellList = GetComponentInChildren<UIList>();
		selector = GameObject.Find("SpellSelector").GetComponent<RectTransform>();

		glyph = GameObject.Find("GlyphImage").GetComponent<Image>();
		manaCostTxt = GameObject.Find("SpellManaCost").GetComponent<Text>();
		descText = GameObject.Find("SpellDescription").GetComponent<Text>();
		labelPrefab = GameObject.Find("SpellLabel");

		if (learnedSpells.Length > 0){
			spellList.Init(5, labelPrefab, 80f, selector, SpellListNames(learnedSpells));
			RefreshInfo(spellList.GetSelected());
		}
	}

	string[] SpellListNames(Spell[] spells){
		string[] names = new string[spells.Length];
		for(int i = 0 ; i < names.Length; i++){
			names[i] = spells[i].key;
		}
		return names;
	}

	void RefreshInfo(int which){
		Spell spell = learnedSpells[which];
		manaCostTxt.text = "Mana Cost: " + spell.manaCost;
		descText.text = spell.description;
		glyph.sprite = learnedSpells[which].glyph;
	}

	void Update(){
		if (MyInput.GetState("SHIFT", true) == 'p' || MyInput.GetState("SPLS") == 'p'){
			GameObject.Destroy(gameObject);
		}

		//read user inputs to cycle through list
		else if (learnedSpells.Length > 0){
			if(MyInput.GetState("DOWN") == 'p'){
				spellList.Inc();
				RefreshInfo(spellList.GetSelected());
			}
			else if(MyInput.GetState("UP") == 'p'){
				spellList.Dinc();
				RefreshInfo(spellList.GetSelected());
			}

		}
	}
}
