﻿using UnityEngine;
using UnityEngine.UI;

public class DeathUI : MonoBehaviour {

	UIList options;
	GameObject opt1;
	GameObject selector;

	string[] labels = {"Respawn at Altar", "Visit the Land of the Dead", "Quit"};

	float animTimer = 2f;
	AudioSource efx_source;

	void Awake(){
		opt1 = transform.GetChild(3).gameObject;
		selector = transform.GetChild(4).gameObject;

		options = new UIList();
		transform.localScale = new Vector3(0, 1f, 1f);

		AudioLoader.StopAll();
		MusicLoader.me.StopMusic();
		efx_source = AudioLoader.PlaySound("death_efx", 0.5f, false, .5f, false);

		UIController.me.RemoveLabel();
		UIController.me.RemoveAltLabel();
	}

	void Update(){
		if(efx_source != null && !efx_source.isPlaying){
			//AudioLoader.PlayMusic("death_soundtrack");
			efx_source = AudioLoader.PlaySound("death_soundtrack", .2f, false, 1f, true);
		}

		if (animTimer > 0f){
			animTimer -= Time.deltaTime;
			transform.localScale += new Vector3(0.5f * Time.deltaTime, 0f, 0f);
			if (animTimer <= 0){
				options.Init(3, opt1, 26, selector.GetComponent<RectTransform>(), labels);
			}
			return;
		}

		if (MyInput.GetState("UP", true) == 'p'){
			options.Dinc();
			options.RefreshSelector();
			AudioLoader.PlayMenuBlip();
		}
		if(MyInput.GetState("DOWN", true) == 'p'){
			options.Inc();
			options.RefreshSelector();
			AudioLoader.PlayMenuBlip();
		}
		if(MyInput.GetState("Z", true) == 'p'){
			switch(options.GetSelected()){
			case 0: 
				SpawnPoint.RespawnAtAltar();
				break;
			case 1:
				SpawnPoint.RespawnDead();
				break;
			}
			AudioLoader.PlayMenuSelect();
			PlayerController.me.StopCry();
			PlayerStats.myStats.RestoreAll();
			GlobalStateMachine.GUnpause();
			GameObject.Destroy(gameObject);
		}
	}
}
