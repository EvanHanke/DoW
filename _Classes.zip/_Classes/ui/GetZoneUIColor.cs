﻿using UnityEngine;
using UnityEngine.UI;
public class GetZoneUIColor : MonoBehaviour {

	public void Start(){
		MaskableGraphic mg = GetComponent<MaskableGraphic>();
		mg.color = Zone.currentZone.uiColor;
	}
}
