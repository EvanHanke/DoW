﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class SelfPanel : MonoBehaviour {

	UIList effectsList;

	Character player;
	Text description;
	RectTransform selector;

	public GameObject sLabelPrefab;

	Effect[] efs;
	string[] efsNames;

	void Awake () {
		effectsList = GetComponentInChildren<UIList>();

		player = GameObject.Find("Player").GetComponent<Character>();
		description = GameObject.Find("EfxDescp").GetComponent<Text>();
		description.text = "";
		selector = GameObject.Find("EfxSelector").GetComponent<RectTransform>();

		UpdateStatuses();
		effectsList.Init(4, sLabelPrefab, 50, selector, efsNames);
	}

	void UpdateStatuses(){
		//get all effects from Character object
		efs = player.GetAllEffects();
		//get the names
		efsNames = new string[efs.Length];

		for(int i = 0; i < efs.Length; i++){
			efsNames[i] = effLabelText(efs[i]);

			if(efs[i].duration > 0f){
				efsNames[i] += " (" + ((int) efs[i].GetTimeLeft()) + "s)";
			}
		}
		UpdateDescription(effectsList.GetSelected());
	}

	void Update () {
		if(MyInput.GetState("SHIFT", true) == 'p' || MyInput.GetState("SLF") == 'p'){
			GameObject.Destroy(gameObject);
		}

		else if (efs.Length > 0){
			if (MyInput.GetState("DOWN") == 'p'){
				effectsList.Inc();
				UpdateDescription(effectsList.GetSelected());
			}
			else if (MyInput.GetState("UP") == 'p'){
				effectsList.Dinc();
				UpdateDescription(effectsList.GetSelected());
			}
		}
	}

	void UpdateDescription(int selected){

		if (efs.Length == 0){
			description.text = "";
			return;
		}

		description.text = efs[selected].ToRichString();
	}


	string effLabelText(Effect e){
		return (e.GetStacks() > 1)? (e.effectName + " (LvL " + e.GetStacks() + ")") : e.effectName;
	}
}
	