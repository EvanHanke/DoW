﻿using UnityEngine;
using UnityEngine.UI;


public class StatLabel : MonoBehaviour {

	Text[] myText;
	string[] a_texts = {"Health: ", "Mana: " , "Power: ", "Magic Power: ", "Armor: " , "Magic Armor: "};

	public void Awake(){
		myText = GetComponentsInChildren<Text>();
		myText[0].text = formattedNames();
		myText[1].text = formattedValues();
	}

	public string formattedNames(){
		string s = string.Format(
			"{0,-7} \n" +
			"{1,-7} \n" +
			"{2,-7} \n" +
			"{3,-7} \n"+
			"{4,-7} \n"+
			"{5,-7} \n",
			a_texts[0],
			a_texts[1],
			a_texts[2],
			a_texts[3],
			a_texts[4],
			a_texts[5]);
		return s;
	}

	public string formattedValues(){
		string s = string.Format(
			"{0,-7} \n" +
			"{1,-7} \n" +
			"{2,-7} \n" +
			"{3,-7} \n"+
			"{4,-7} \n"+
			"{5,-7} \n",
			GetStatColored("maxhp"), 
			GetStatColored("maxmp"), 
			GetStatColored("power"), 
			GetStatColored("magic_pow"),
			GetStatColored("armor"), 
			GetStatColored("magic_def"));
		return s;
	}

	public string GetStatColored(string statname){
		int stat = PlayerStats.myStats.GetStat(statname);
		int rawstat = PlayerStats.myStats.GetStatRaw(statname);
		if( stat > rawstat) return TextColorer.ToColor(stat.ToString(), Color.yellow);
		else if (stat < rawstat) return TextColorer.ToColor(stat.ToString(), Color.red);
		else return stat.ToString();
	}
}
