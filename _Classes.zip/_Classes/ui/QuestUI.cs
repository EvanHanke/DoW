﻿using UnityEngine;
using UnityEngine.UI;

public class QuestUI : MonoBehaviour {
	//UI for displaying the player's collected quests

	UIList questList;
	Text description, stageDescription, goalsLabel;

	//for insantiating the list
	GameObject listObj;
	RectTransform selector;

	Quest[] quests;
	string[] names;

	void Awake () {
		description = GameObject.Find("QuestDescription").GetComponent<Text>();

		questList = GetComponentInChildren<UIList>();

		listObj = GameObject.Find("QuestLabel");
		selector = GameObject.Find("QuestSelector").GetComponent<RectTransform>();
		quests = QuestTracker.GetQuests();
		names = GetQuestNames(quests);

		questList.Init(6, listObj, 81f, selector, names);
		RefreshInfo(0);
	}

	void Update(){
		if (MyInput.GetState("SHIFT", true) == 'p' || MyInput.GetState("QST") == 'p'){
			GameObject.Destroy(gameObject);
		}
		else if (quests.Length > 0){
			if(MyInput.GetState("DOWN") == 'p'){
				questList.Inc();
				RefreshInfo(questList.GetSelected());
			}
			else if(MyInput.GetState("UP") == 'p'){
				questList.Dinc();
				RefreshInfo(questList.GetSelected());
			}
		}
	}

	void RefreshInfo(int which){
		if (quests.Length == 0) return;
		Quest q = quests[which];

		description.text = q.description;
		string currText = "";
		string goalText = "";
		Color c= Color.green;
		if(!q.failed && !q.completed){
			currText = ("\n" + q.stages[q.currentStage].description);
			foreach(QuestGoal g in q.stages[q.currentStage].goals){
				goalText += "\n" + g.ToString();
			}
		}
		else if( q.completed){
			currText = ("\n" + q.completedInfo);
			c = Color.yellow;
		}
		else if (q.failed){
			currText = ("\n" + q.failedInfo);
			c = Color.Lerp(Color.red, Color.yellow, 0.5f);
		}

		description.text += TextColorer.ToColor( "\n" + currText, c);
		description.text += TextColorer.ToColor( "\n" + goalText, Color.cyan);
	}

	string[] GetQuestNames(Quest[] quests){
		string[] n = new string[quests.Length];
		int i = 0;
		foreach (Quest q in quests){
			if(!q.completed && !q.failed)
				n[i] = q.name;
			else{
				n[i] = TextColorer.ToColor(q.name, Color.grey);
			}
			i++;
		}
		return n;
	}
}
