﻿using UnityEngine;
using UnityEngine.UI;


public class BookUI : MonoBehaviour {

	public GameObject bookUIPrefab;
	public static BookUI me;
	public static GameObject bookUI;

	static Text pageText;
	static Text pageNumberText;
	static Image picture;
		
	static int c = 0;
	static Book book; //book currently being displayed

	void Awake(){
		me = this;

	}

	public static void ShowBook(Book b){
		GlobalStateMachine.GPause();

		bookUI = GameObject.Instantiate(me.bookUIPrefab);
		bookUI.transform.SetParent(GameObject.Find("UI").transform, false);
		book = b;
		c = 0;

		picture = GameObject.Find("Picture").GetComponent<Image>();
		pageText = GameObject.Find("Page").GetComponent<Text>();
		pageNumberText = GameObject.Find("PageNum").GetComponent<Text>();

		ShowPage(0);
	}

	static void ShowPage(int p){
		pageText.text = book.pages[p];
		pageNumberText.text = "Page     " + (p+1);

		if(book.pictures.Length <= p || book.pictures[p] == null){
			picture.gameObject.SetActive(false);
		}
		else{
			picture.gameObject.SetActive(true);
			picture.sprite = book.pictures[p];
		}
	}

	static void CloseBook(){
		GameObject.Destroy(bookUI);
		if (!MenuController.menuOpen) GlobalStateMachine.GUnpause();
	}

	void Update () {
		if (bookUI != null){
			if (MyInput.GetState("Z") == 'p'){

				if (c < book.pages.Length-1){
					c ++;
					ShowPage(c);
				}
				else{
					CloseBook();
				}
			}
			if (MyInput.GetState("X") == 'p'){
				if (c > 0){
					c --;
					ShowPage(c);
				}
				else{
					CloseBook();
				}
			}
			if (MyInput.GetState("SHIFT", true) == 'p'){
				CloseBook();
			}
		}
	}
}
