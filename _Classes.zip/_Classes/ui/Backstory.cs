﻿using UnityEngine;
using UnityEngine.UI;


public class Backstory : MonoBehaviour {
	
	public SetPage[] pages;
	string[] words;
	float[] word_alpha_values;
	int currWord;
	float speed = 3f;
	bool pageDone;

	Transform sets;
	Text storyText;
	int currPage;

	public delegate void MyD();
	public MyD OnComplete;
	AudioSource music_AS;

	void Awake(){
		storyText = GetComponentInChildren<Text>();
		sets = GameObject.Find("Sets").transform;
		foreach(SetPage sp in pages){
			sp.Set();
		}
		SetPage(pages[0]);


	}

	void Start(){
		GlobalStateMachine.GUnpause();
		music_AS = AudioLoader.PlaySound("templesong", 0.5f, true, .25f, true);
	}

	void Update(){
		pages[currPage].Update();

		if(currWord < words.Length && !pageDone){
			if(IncrementAlpha(currWord, speed * Time.deltaTime) >= 1f){
				currWord++;
			}
		}
		else{
			pageDone = true;
		}

		if(MyInput.GetState("Z", true) == 'p'){
			if(!pageDone){
				AudioLoader.PlaySound("Glitch_4.L");
				currWord = words.Length;
				SetAll(1f);
			}
			else{
				if(currPage + 1 < pages.Length){
					if(!pages[currPage].done){
						pages[currPage].QuickComplete();
					}

					currPage++;
					SetPage(pages[currPage]);
					Debug.Log("next page " + currPage);


				}
				else{
					CameraEfx.FadeInOut(3f, ReturnToGame);
					this.enabled = false;
				}
			}
		}

		storyText.text = ShownWords();
	}

	void ReturnToGame(){
		GlobalStateMachine.GPause();
		music_AS.Stop();
		transform.parent.GetComponentInChildren<Environment>(true).gameObject.SetActive(true);
		//GameObject.Find("TheGlobe").SetActive(true);
		gameObject.SetActive(false);
		if(OnComplete!=null){
			OnComplete();
		}
	}
	//helper methods
	void SetPage(SetPage page){
		currWord= 0;
		words = page.text.Split(' ');
		word_alpha_values = new float[words.Length];
		SetAll(0f);
		pageDone = false;
	}

	void SetAll(float amt){
		for(int i = 0; i < words.Length; i++){
			word_alpha_values[i] = amt;
		}
	}

	float IncrementAlpha(int index, float amt){
		if(word_alpha_values[index] == 0f){AudioLoader.PlaySound("Glitch_4.L");}
		word_alpha_values[index] += amt;
		return word_alpha_values[index];
	}

	string ShownWords(){
		string newString = "";
		for(int i = 0; i < words.Length ; i++){
			string new_word;
			Color word_color = new Color(1f, 1f, 1f, word_alpha_values[i]);
			new_word = words[i].Insert(0, "<color=#" + ColorUtility.ToHtmlStringRGBA(word_color) + ">") + "</color>";
			newString += (new_word + " ");
		}
		return newString;
	}
}

[System.Serializable]
public class SetPage{
	[TextArea(3,3)]
	public string text;
	public GameObject activateObj;
	public GameObject deactivateObj;
	Vector3 a_target, b_target;

	float timer;
	SpriteRenderer[] a_SRs, b_SRs;
	public bool done = false;

	public void Set(){
		if(activateObj!=null){
			a_SRs = activateObj.GetComponentsInChildren<SpriteRenderer>();
			a_target = activateObj.transform.position;
			activateObj.transform.position -= new Vector3(0f, 0f, -10f);
			activateObj.SetActive(false);
		}
		if(deactivateObj != null){
			b_SRs = deactivateObj.GetComponentsInChildren<SpriteRenderer>();
			deactivateObj.SetActive(false);
		}
		
		if(a_SRs!=null){
			foreach(SpriteRenderer s_r in a_SRs){
				s_r.color = new Color(1f, 1f,1f, 0f);
			}
		}
		if(b_SRs!=null){
			foreach(SpriteRenderer s_r in b_SRs){
				s_r.color = new Color(1f, 1f,1f, 0f);
			}
		}


		done = false;
		timer = 1f;
	}

	//animate fade in/out
	public void Update(){
		if(activateObj != null && !activateObj.activeSelf) activateObj.SetActive(true);

		if(!done){
			timer -= Time.deltaTime;
			float a_alpha = 1f-timer;
			float b_alpha = timer;

			if(a_SRs!=null){
				activateObj.transform.position -= new Vector3(0f, 0f, Time.deltaTime * 10f);
				foreach(SpriteRenderer s_r in a_SRs){
					s_r.color = new Color(1f, 1f,1f, a_alpha);
				}
			}
			if(b_SRs!=null){
				foreach(SpriteRenderer s_r in b_SRs){
					s_r.color = new Color(1f, 1f,1f, b_alpha);
				}
			}
			if(deactivateObj != null){
				deactivateObj.transform.position += new Vector3(0f, 0f, Time.deltaTime * 10f);
			}
			if (timer <= 0f) {
				if(deactivateObj != null){
					deactivateObj.SetActive(false);
				}

				done = true;
			}
		}
	}

	public void QuickComplete(){
		if(a_SRs!=null){
			foreach(SpriteRenderer s_r in a_SRs){
				s_r.color = Color.white;;
			}
		}
		if(b_SRs!=null){
			foreach(SpriteRenderer s_r in b_SRs){
				s_r.color = new Color(1f, 1f,1f, 0f);
			}
		}
		if(deactivateObj != null){
			deactivateObj.SetActive(false);
		}
	}
}