﻿
public class ConsumableItem : UsableItem {
	
}
