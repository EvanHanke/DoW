﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaveAnimator : MonoBehaviour {

	MyAnimation[] waves;

	void Start () {
		waves = GetComponentsInChildren<MyAnimation>();
		if (waves == null) return;
		int counter = 0;
		int max = waves[0].frames.Length;
		for(int i = 0; i < waves.Length; i++){
			waves[i].SetAnim(counter);
			counter = (counter + 1 < max)? counter + 1 : 0; 
		}
	}
	
}
