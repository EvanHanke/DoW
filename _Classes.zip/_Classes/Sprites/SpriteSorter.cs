﻿using UnityEngine;
using System.Collections.Generic;

public class SpriteSorter : MonoBehaviour {

	SpriteRenderer[] allSprites;
	List<SpriteRenderer> blocking;

	Transform camera;
	Transform player;

	float refreshTimer;

	void Awake () {
		blocking = new List<SpriteRenderer>();
		RefreshSprites();
		refreshTimer = Time.time;
	}

	void Start(){
		camera = Camera.main.transform;
		player = PlayerController.me.transform;
	}

	void FixedUpdate () {
		if (refreshTimer < Time.time){
			refreshTimer = Time.time + 0.25f;
			RefreshSprites(); //may cause speed loss?
			for(int i = 0; i < allSprites.Length; i++){
				if (allSprites[i].tag != "UI")
				allSprites[i].sortingOrder = (int) - (allSprites[i].transform.position.z*100f);


				Ray from_cam = new Ray(camera.position, player.position-camera.position );
				//Ray from_cam = new Ray(camera.position, camera.forward );
				if (allSprites[i].transform.position.z < player.position.z && 
					allSprites[i].bounds.IntersectRay(from_cam) && allSprites[i].bounds.extents.y > 1f &&
					allSprites[i].gameObject.tag != "gear"){
						blocking.Add(allSprites[i]);
						allSprites[i].color = new Color(allSprites[i].color.r, allSprites[i].color.g, allSprites[i].color.b, 0.75f);
				}
				else if (blocking.Contains(allSprites[i])){
					blocking.Remove(allSprites[i]);
					allSprites[i].color = new Color(allSprites[i].color.r, allSprites[i].color.g, allSprites[i].color.b, 1);
				}

			}
		}
	}

	public void RefreshSprites(){
		allSprites = GetComponentsInChildren<SpriteRenderer>();
	}
}
