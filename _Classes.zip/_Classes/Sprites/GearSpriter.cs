﻿using UnityEngine;

public class GearSpriter : MonoBehaviour {
	//follows player movement animation and direction to offset gear sprites and use correct facing direction sprite
	PlayerMovement pm;
	SpriteRenderer mySprite;
	public enum Slot {head, body};
	public Slot mySlot;

	void Awake(){
		pm = GetComponentInParent<PlayerMovement>();
		mySprite = GetComponent<SpriteRenderer>();
	}


	void LateUpdate(){
		mySprite.sortingOrder = PlayerController.me.GetComponentInChildren<SpriteRenderer>().sortingOrder+1;
		int frame = pm.walkingAnim.currFrame;
		Vector3 offset = Vector3.zero;
		if ((frame == 1 || frame == 3) && mySlot == Slot.head){
			offset += new Vector3(0f, 0.92f, -0.01f);
		}
		else{
			offset += new Vector3(0f, .96f, -0.01f);
		}

		if(PlayerMovement.me.facing == PlayerMovement.Directions.back && mySlot == Slot.body){
			offset += new Vector3(-0.07f, 0f, 0f);
		}
		transform.localPosition = offset;

		if(mySlot == Slot.head){
			if(PlayerStats.headEquip != null && PlayerMovement.me.jumping == false){
				mySprite.sprite = PlayerStats.headEquip.spriteFromDirection((int)pm.facing);
				mySprite.flipX = PlayerController.me.playerSprite.flipX;
				mySprite.color = new Color(1f, 1f, 1f, PlayerStats.headEquip.spriteAlpha);
			}
			else if (PlayerMovement.me.jumping == false){
				mySprite.sprite = null;
			}
		}
		else if (PlayerStats.bodyEquip != null && PlayerMovement.me.jumping == false){
			mySprite.sprite = PlayerStats.bodyEquip.spriteFromDirection((int)pm.facing);
			mySprite.flipX = PlayerController.me.playerSprite.flipX;
			mySprite.color = new Color(1f, 1f, 1f, PlayerStats.bodyEquip.spriteAlpha);
		}
		else if (PlayerMovement.me.jumping == false){
			mySprite.sprite = null;
		}
	}

	public void Toggle(bool t){
		mySprite.enabled = t;
	}
}
