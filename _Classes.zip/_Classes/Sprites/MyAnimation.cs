﻿using UnityEngine;

[System.Serializable]
public class SoundFrame{
	public AudioClip sound;
	public int frame;
	public float volume = 0.7f;
}

public class MyAnimation : MonoBehaviour {

	public string animName;

	public Sprite[] frames;
	public SoundFrame[] sounds;

	public float fps = 2;
	public SpriteRenderer myRenderer;

	public int[] exitFrames;
	bool end = false;
	bool done = false;

	public int startingOffset = 0;
	public int currFrame = 0;
	float nextFrameTime = 0;

	public bool playing = false;
	public bool noloop = false;
	bool resume = true;

	void OnPause(){
		//resume = playing;
		//playing = false;
	}
	void OnUnpause(){
		//playing = resume;
		//nextFrameTime = Time.time + (1.0f/fps);
	}

	//if this anim doesn't loop it will set IsDone to true on completion

	public bool IsDone(){
		return done;
	}

	//display first frame but don't start animation
	public void SetAnim(){
		SetAnim(0);
	}

	public void SetAnim(int which){
		done = false;
		currFrame = which;
		myRenderer.sprite = frames[which];
	}

	public void PlayAnim(){
		playing = true;
		end = false;
	}

	public void StopAnim(){
		playing = false;
	}

	public void StopAnimOnNextExit(){
		end = true;
	}

	void Awake () {
		resume = playing;
		myRenderer = transform.GetComponent<SpriteRenderer>();
	}

	void FixedUpdate () {
		if (Time.time >= nextFrameTime && playing){
			if (currFrame == frames.Length-1 && noloop){
				done = true;
				playing = false;
			}
			else{
				IncrementFrame();
			}
		}
	}

	void IncrementFrame(){
		//inc frame variable


		currFrame = (currFrame == frames.Length-1)? 0 : currFrame + 1;
		myRenderer.sprite = frames[currFrame];

		//see if its time to end the animation
		if (end){
			for(int i = 0 ; i < exitFrames.Length; i++){
				if (currFrame == exitFrames[i]){
					playing = false;
					end = false;
					return;
				}
			}
		}

		//check if there is a sound frame to play
		foreach(SoundFrame sf in sounds){
			if (sf.frame == currFrame)
				LocalSfx.PlayFx(transform.parent, sf.sound, false, sf.volume);
		}

		//prepare next frame
		nextFrameTime = Time.time + (1.0f/fps);
	}

}
