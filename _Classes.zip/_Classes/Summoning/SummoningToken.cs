﻿using UnityEngine;

public class SummoningToken : MonoBehaviour {
	public int id;
}
