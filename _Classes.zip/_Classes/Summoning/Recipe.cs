﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Recipe : MonoBehaviour {

	static List<Recipe> allRecipes = new List<Recipe>();

	public static void CheckPhrase(string s){
		Debug.Log("incanted phrase length "+ s.ToCharArray().Length);

		foreach(Recipe r in allRecipes){
			Debug.Log("recipe " + r.phrase);
			if (r.phrase.Equals(s)){
				r.TryToSummon();
			}
		}

	}
	public static void CheckAll(){
		foreach(Recipe r in allRecipes){
			r.TryToSummon();
		}
	}

	public float minDis;
	public float maxDis;

	public GameObject border;
	public int borderSize;

	public GameObject keyToken; //key token which is transfigured
	public GameObject result;
	public GameObject particles;

	public string phrase;

	public CheckCondition condition;

	GameObject validKey; //set by the test function if valid found

	Node validNode;

	void Awake(){
		allRecipes.Add(this);
		Debug.Log("new phrase added of length" + phrase.ToCharArray().Length);
	}

	public void TryToSummon(){
		Debug.Log("Looking for valid node");
		Node.ClearNodes();
		Node.SetBounds(minDis, maxDis);

		if(condition.Check() && TestValid(Zone.currentZone.gameObject)){
			
			GameObject go = GameObject.Instantiate(result, validKey.transform.position, Quaternion.identity);
			if(particles != null)
				GameObject.Instantiate(particles, validKey.transform.position, Quaternion.identity);
			
			go.transform.SetParent(Zone.currentSubZone.addedPrefabs.transform);
			GameObject.Destroy(validKey);

		}
	}

	//test if valid combination exists in the given zone
	public bool TestValid(GameObject zone){
		if(zone == null){
			Debug.Log("null keytoken");
			return false;
		}
		GameObject[] borderPoss = FindPossibleTokens(border.GetComponent<SummoningToken>().id, zone);
		GameObject[] keyPoss = FindPossibleTokens(keyToken.GetComponent<SummoningToken>().id, zone);

		if (borderPoss.Length < borderSize ){
			Debug.Log("not enough valid nodes in the scene");
			return false; //need a minimum number of border tokens to be valid
		}

		if (keyPoss.Length == 0 ){
			Debug.Log("not enough valid keys in the scene");
			return false; //need a minimum number of border tokens to be valid
		}

		foreach(GameObject go in borderPoss){
			//create nodes
			Node newNode = new Node(go);
		}
		foreach(Node n in Node.allNodes){
			foreach(Node nn in Node.allNodes)
				n.CheckNeighbor(nn);
		}
			
		Debug.Log("Succesffuly generated matrix of " + Node.allNodes.Count);

		foreach(Node node in Node.allNodes){
			
			if (!node.FindShape(borderSize)){
				Debug.Log(Node.allNodes.IndexOf(node) + " not a valid root");
			}
			else{
				//if a valid polygon exists, test key nodes
				Debug.Log("Valid root node found at " + node.pos);
				validNode = node;
				foreach(GameObject key in keyPoss){
					if (IsKeyTokenValid(key, node.myPolygon, borderSize)){
						Debug.Log("Valid key found at " + key.transform.position);
						validKey = key;
						return true;
					}
				}
				Debug.Log("No valid keys found");
			}
		}

		Debug.Log("No valid root nodes found");

		return false;
	}

	//checks if key token is within the polygon of nodes
	//alienryderflex.com/polygon/
	public static bool IsKeyTokenValid(GameObject key, Node[] nodes,int borderSize){
		float[] polyX = new float[nodes.Length]; //polygon x coords
		float[] polyY = new float[nodes.Length]; //polygon y coords
		float keyX, keyY; //key position
		int i, j;
		j = borderSize-1;
		bool oddNodes = false;

		for(int a = 0; a < nodes.Length; a++){
			polyX[a] = nodes[a].pos.x+100f;
			polyY[a] = nodes[a].pos.z+100f;
		}
		keyX = key.transform.position.x+100f;
		keyY = key.transform.position.z+100f;
		Debug.Log("key found at " + keyX + " " + keyY);
		Debug.Log("nodes + " + nodes.Length);
		for(i = 0; i < borderSize; i++){
			if((polyY[i] < keyY && polyY[j] >= keyY
				||  polyY[j] < keyY && polyY[i] >= keyY)){
				if (polyX[i]+(keyY-polyY[i])/(polyY[j]-polyY[i])*(polyX[j]-polyX[i])<keyX) {
					oddNodes=!oddNodes; 
				}
			}
			j=i;
		}


		return oddNodes;
	}

	GameObject[] FindPossibleTokens(int id, GameObject zone){

		SummoningToken[] allTokens = zone.GetComponentsInChildren<SummoningToken>();
		List<GameObject> valids = new List<GameObject>();
		foreach(SummoningToken st in allTokens){
			if (st.id == id) valids.Add(st.gameObject);
		}
		return valids.ToArray();
	}

	void OnDrawGizmos(){
		foreach(Node n in Node.allNodes){
			foreach(Node nn in n.neighbors){
				Gizmos.color = Color.white;
				Gizmos.DrawLine(n.pos, nn.pos);
			}
		}
		if (validNode != null){
			int j = validNode.myPolygon.Length-1;
			for(int i = 0; i < validNode.myPolygon.Length; i++){
				Gizmos.color = Color.red;
				Gizmos.DrawLine(validNode.myPolygon[i].pos, validNode.myPolygon[j].pos);
				j = i;
			}
		}
	}
}

public class Node{

	static float min, max; //min max distance between neighbors

	public static List<Node> allNodes = new List<Node>();

	GameObject myGo;

	public List<Node> neighbors;

	public Vector3 pos;

	public Node[] myPolygon;

	public Node(GameObject go){
		neighbors = new List<Node>();
		myGo = go;
		pos = go.transform.position;
		allNodes.Add(this);
	}

	public void CheckNeighbor(Node other){
		float d = Vector3.Distance(pos, other.pos);

		if (d > min && d < max){
			if (!neighbors.Contains(other)){
				neighbors.Add(other);
				other.neighbors.Add(this);
			}
		}
	}


	public bool FindShape(int numSides){
		List<Node> path = new List<Node>();
		return NavigateWeb(this, 0, numSides, path);
	}

	public bool NavigateWeb(Node root, int count, int target, List<Node> path){
		if (neighbors.Count == 0){
			Debug.Log("no neighbors");
			return false; //not a valid node if it has no neighbors
		}
		if (count > target){
			Debug.Log("path 2 long");
			return false;
		}

		if (this != root ) path.Add(this);

		Node nearest = null;
		float d = max;
		//Get Nearest Neighbor
		foreach(Node branch in neighbors){
			if(nearest == null || !path.Contains(branch)){
				float a =  Vector3.Distance(branch.pos, pos);
				if(a < d){
					nearest = branch;
					d = a;
				}
			}
		}


		if (nearest == root && count+1 == target){ 
			//if neighbor is the root and sides match, valid found
			path.Add(root);
			root.myPolygon = path.ToArray();
			return true;
		}
		else if (nearest == root || nearest == null){
			return false;
		}
		else{
			//iterate to next node if child is not the prev
			return nearest.NavigateWeb(root, count+1, target, path);
		} 


		//if node is not part of a valid shape, remove it from the list
		path.Remove(this);
		PrintPath(path);
		return false;
	}

	public void PrintPath(List<Node> path){
		string pp = "";
		foreach(Node p in path){
			pp += ", " + allNodes.IndexOf(p);
		}
		Debug.Log("PATH " + pp);
	}

	//Nodes must be cleared each time the map is updated
	public static void ClearNodes(){
		allNodes.Clear();
	}

	//min/max distances between neighbor nodes must be set by Recipe before used
	public static void SetBounds(float mn, float mx){
		min = mn;
		max = mx;
	}
}

