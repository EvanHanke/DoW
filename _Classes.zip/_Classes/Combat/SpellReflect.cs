﻿using UnityEngine;

public class SpellReflect : MonoBehaviour {

	public Character player;

	public void Start(){
		player = PlayerStats.myStats;
	}

	public void Update(){
		if(player != null)
		foreach(Damager d in Zone.currentZone.GetComponentsInChildren<Damager>()){
				Debug.Log("checking " + d.name);
			if(Vector3.Distance(d.transform.position, player.transform.position) < 4f){
				Check(d);
			}
		}
	}

	public void Check(Damager d){
		Debug.Log("checking " + d.name);
		if(d.GetComponent<Entity>() == null && d.caster != player){
			int threshold  = d.caster.GetStatPow(d.damageType) + d.damage;
			if(player.GetStat("air") > threshold){
				Reflect(d);
			}
		}
	}

	public void Reflect(Damager d){
		if(d.caster == null) return;

		Character prev_caster = d.caster;
		d.caster = player;
		foreach(Component c in d.transform.GetComponents<Component>()){
			if ( !(c is Damager) && !(c is Transform) && !(c is Collider)){
				GameObject.Destroy(c);
			}
		}
		d.gameObject.AddComponent<SimpleProjectile>().Set(prev_caster.transform.position - d.transform.position, 
			8f, 3f);
	}
}
