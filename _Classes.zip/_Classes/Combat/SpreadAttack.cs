﻿using UnityEngine;

public class SpreadAttack : MonoBehaviour {
	
	public GameObject prefab;
	public float speed;
	public float distance;

	public int number;
	[Range(0f, 1f)]
	public float spread_amt;
	public Vector3 randomness;

	public Vector3 direction;
	Attack at;
	Vector3 center;

	void Start(){
		Invoke("Init", 0.1f);
	}

	public void Init(){
		//grab attack information
		at = GetComponent<Attack>();

		direction= at.direction.normalized;
		transform.position = at.c.transform.position;

		//spread the shots in a polygon
		center = at.c.transform.position + Vector3.up/2f;
		float angle = Mathf.PI*spread_amt; //angle in radians representing max cone
		float phaseX = Mathf.Asin(direction.x / 1f);
		float phaseZ = Mathf.Acos(direction.z / 1f);
		angle = (angle / (float)(number))/2f;
		for(int i = 0; i < number/2; i++){
			for(int j  = 0; j < 2; j++){
				float mod = (j == 0)? 1f : -1f;
				Spawn(phaseX, phaseZ, angle*(i+1)*mod);
			}
		}
		if((number+2) % 2 == 1) Spawn(phaseX, phaseZ, 0f);
	
		GameObject.Destroy(gameObject);

	}

	void Spawn(float initialX, float initialZ, float R){
		GameObject n_a = GameObject.Instantiate(prefab, transform.parent);
		Vector3 offset = new Vector3(Mathf.Sin(initialX + R), 0f, Mathf.Cos(initialZ + R));
		n_a.transform.position = center+offset;
		Attack a = n_a.AddComponent<Attack>();
		a.c = at.c;
		a.direction = offset;
		n_a.AddComponent<SimpleProjectile>().Set(center+offset - transform.position, speed, distance);
		Damager d = n_a.GetComponent<Damager>();
		if(at != null && d != null){
			d.caster = at.c;
		}
	}

}
