﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Collections;


public class CombatInfo : MonoBehaviour {

	Text text;
	RawImage back;
	public static CombatInfo me;

	void Awake(){
		text= GetComponentInChildren<Text>();
		back = GetComponentInChildren<RawImage>();
		Show(false);
		me = this;
	}

	void Show(bool a){
		text.gameObject.SetActive(a);
		back.gameObject.SetActive(a);
	}

	public void Check(){
		StopCoroutine("Check1");
		StartCoroutine("Check1");
	}

	IEnumerator Check1(){
		yield return new WaitForFixedUpdate();
		if(PlayerStats.me!=null){
			Character c = PlayerStats.myStats.target;
			if(c!=null){
				Show(true);
				text.text = string.Format("{0} ({2}/{1})", c.statSheet.name, c.statSheet.hp, c.GetStat("hp"));
			}
			else{
				Show(false);
			}
		}
	}
}
