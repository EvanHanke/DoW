﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SimpleProjectile : MonoBehaviour {

	public Vector3 direction;
	public float speed;
	public float lifetime;

	public void Set(Vector3 dir, float s, float t){
		direction = dir;
		speed = s;
		lifetime = t;
	}

	void Awake(){
		Invoke("Init", 0.1f);
	}

	void Init(){
		Attack a = GetComponent<Attack>();
		if(a != null){
			if(a.target != null){
				direction = (a.target.position - transform.position);
			}
			else{
				direction = a.direction;
			}
		}
	}

	public void FixedUpdate(){
		if(GlobalStateMachine.paused == false){
			if(lifetime != null){
				lifetime -= Time.deltaTime;
				transform.position += direction.normalized*speed*Time.deltaTime;
				if(lifetime < 0f){

					GameObject.Destroy(gameObject);
				}
			}
		}
	}
}
