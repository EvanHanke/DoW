﻿using UnityEngine;

public class FireWhipAttack : MonoBehaviour {

	public GameObject firePrefab;

	public int damage;

	// Update is called once per frame
	void Update () {
		Attack at = GetComponent<Attack>();
		if(at != null){
			Vector3 pos = at.direction*2f + at.c.transform.position;
			GameObject a = GameObject.Instantiate(firePrefab, transform.parent);
			a.transform.position = pos;
			Damager d = a.GetComponent<Damager>();
			d.damage = damage;
			d.knockback = 6f;
			d.caster = at.c;
			a.AddComponent<SimpleProjectile>().Set(at.direction, 4f, 2f);
			GameObject.Destroy(gameObject);
		}
		
	}
}
