﻿using UnityEngine;

public class InstantRecall : MonoBehaviour {
	
	void Start () {
		SpawnPoint.RespawnAtAltar();
		GameObject.Destroy(gameObject);
	}
}
