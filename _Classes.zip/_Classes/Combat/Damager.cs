﻿using UnityEngine;
using System.Collections.Generic;

public class Damager : MonoBehaviour {

	public AudioClip looped_audio;
	public float volume = 0.7f;
	/*
	 * For dealing damage and effects
	 */ 
	public int damage = 1;
	public float knockback = 1f;
	public bool multi = false;
	public Effect[] effects;
	public bool ignore_attack = false;

	public enum Element {magic, phys};
	public Element damageType = Element.phys;

	public bool water = false;

	public Character caster;
	public List<string> immune;

	Character other;
	public void Awake(){
		immune = new List<string>();
		if(looped_audio != null) LocalSfx.PlayFx(transform, looped_audio, true, volume);
	}

	void Start(){
		Character c = GetComponent<Character>();
		if(c != null) {
			caster = c;
			immune.Add(c.statSheet.archetype);
		}
	}



	void OnTriggerEnter(Collider c){
		 other = c.transform.GetComponent<Character>();
		if (other != null){
			Invoke("Hit", 0.01f);
		}
	}

	void Hit(){
		Ray checkRay = new Ray();
		RaycastHit hit;
		if(other != null)
		if(!immune.Contains(other.statSheet.archetype) && other != caster){
			other.HitDamage(this, damageType);
			//if (!multi) immune.Add(other.statSheet.archetype); // Destroy the damager component if its only supposed to hit once
		}
	}

}
