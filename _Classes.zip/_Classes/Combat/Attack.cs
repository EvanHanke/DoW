﻿using UnityEngine;

public class Attack : MonoBehaviour {
	public Vector3 direction;
	public Character c;
	public Transform target;
	Damager d;

	void Start(){
		d = GetComponent<Damager>();
		if(d != null && !d.ignore_attack) {
			Init();
		}
	}	

	void Init(){
		
		d.caster = c;
		if((d.effects.Length > 0 && d.effects[0].healAmt == 0) || d.effects.Length == 0){
			d.immune.Add(c.statSheet.archetype);

		}
	}
}
