﻿using UnityEngine;

public class DeathAnimator : MonoBehaviour {

	public static void StartDeathAnim(GameObject target){


		foreach(Component c in target.GetComponents<Component>()){
			if (!(c is Transform) && !(c is AudioSource))
				GameObject.Destroy(c);
		}
		target.AddComponent<DeathAnimator>();

	}

	float timer;
	bool a = false;

	void LateUpdate () {
		if(!a){
			AudioClip a_c = AudioLoader.GetAC("spinny1");
			LocalSfx.PlayFx(transform, a_c, false, 0.3f);
			a = true;
		}
		timer += Time.deltaTime;

		Vector3 rot = new Vector3(0, 15, 0);
		transform.Rotate(rot);
		Vector3 shrink = new Vector3(0.3f, 0.3f, 0.3f);
		transform.localScale -= shrink * Time.deltaTime;

		if (timer > 3){
			GameObject.Destroy(gameObject);
		}
	}
}
