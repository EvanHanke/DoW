﻿using UnityEngine;

public class FireHazard : MonoBehaviour {

	void OnTriggerStay(Collider c){
		Damager d = c.gameObject.GetComponent<Damager>();
		if(d != null){
			
			if (d.water){
				Debug.Log("hittt");
				float scaleAmt = 1f * Time.deltaTime;
				transform.localScale -= new Vector3(scaleAmt, scaleAmt, scaleAmt);
				if (transform.localScale.magnitude < 0.1f){
					GameObject.Destroy(gameObject);
				}
			}
		}
	}
}
