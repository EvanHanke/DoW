﻿using UnityEngine;

public class LeafyAttack : MonoBehaviour {

	Character c, target;
	float timer, timer2 = 1f;
	float r = 4f;
	bool init = false;

	void Init(){
		c = GetComponent<Damager>().caster;
		target = c.target;
		timer2 = 0f;
		init = true;
	}

	void Update(){
		if(GlobalStateMachine.paused) return;
		if(timer > 0f){
			timer -= Time.deltaTime;
			transform.position += Vector3.back*Time.deltaTime;
		}
		else{
			if (init == false){
				Init();
			}
			else if(timer2 < 3f && c != null){
				timer2 += Time.deltaTime;
				Vector3 pos = new Vector3(Mathf.Sin(Mathf.PI*2f*(timer2))*r, .5f,
					Mathf.Cos(Mathf.PI*2f*timer2)*r);
				transform.position= c.transform.position + pos;
			}
			else if (target != null){
				gameObject.AddComponent<SimpleProjectile>().Set( target.transform.position - transform.position,
					6f, 3f);
				GameObject.Destroy(this);
			}
			else{
				gameObject.AddComponent<SimpleProjectile>().Set( GetComponent<Attack>().direction,
					6f, 3f);
				GameObject.Destroy(this);
			}
		}
	}
}
