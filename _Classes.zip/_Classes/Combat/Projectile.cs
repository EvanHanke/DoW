﻿using UnityEngine;

public class Projectile : MonoBehaviour {

	//Class for instantiating the initial orientation and movement of a projectile from Player orientation
	Vector3 orientation;
	public float speed;
	public float lifetime;
	[HideInInspector]
	public float life;
	public AudioClip sfx;
	AudioSource a_s;

	public bool rotate = false;

	void Start () {
		orientation = PlayerController.me.GetDirection().normalized;
		if(sfx!=null){
			a_s = LocalSfx.PlayFx (transform, sfx, true, 0.5f);
		}
		if(rotate){
			transform.LookAt(orientation+transform.position);
		}
	}

	void Update () {
		if(lifetime == -1) return;
		if (!GlobalStateMachine.paused){
			life += Time.deltaTime;
			transform.position += orientation*Time.deltaTime*speed;

			if (life >= lifetime) GameObject.Destroy(this.gameObject);
		}
	}

	public void AdvanceTime(){
		GameObject.Destroy(gameObject);
	}

	void OnDestroy(){
		if(a_s != null) a_s.Stop();
	}
}
