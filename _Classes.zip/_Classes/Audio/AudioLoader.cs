﻿using UnityEngine;
using UnityEngine.Audio;
using System.Collections.Generic;

public class AudioLoader : MonoBehaviour {
	/*
	 * For loading and playing sound effect files
	 * Mostly for UI elements
	 * 
	 */

	AudioClip[] clips;
	Dictionary<string, AudioClip> clip_names;
	Dictionary<string, AudioSource> playing_sources;

	public List<AudioSource> sources;
	public AudioSource textBoxVoice;
	AudioSource musicVoice;

	public static AudioLoader me;
	public static float voice_mod = 1f;
	public static float sfx_volume = 0.5f;
	public static bool muted = false;

	public void Toggle(){
		muted = !muted;
		if(muted){
			sfx_volume = 0f;

		}
		else{
			sfx_volume = 0.5f;
		}
		foreach(AudioSource aa in GetComponentsInChildren<AudioSource>()){
			if(aa.transform.name != "Music")
				aa.volume = sfx_volume;
		}
	}

	void Awake(){
		clips = Resources.LoadAll<AudioClip>("Audio/");
		clip_names = new Dictionary<string, AudioClip>();
		playing_sources = new Dictionary<string, AudioSource>();
		sources = new List<AudioSource>();
		textBoxVoice = gameObject.AddComponent<AudioSource>();

		musicVoice = gameObject.AddComponent<AudioSource>();
		musicVoice.loop = true;


		foreach(AudioClip clip in clips){
			clip_names.Add(clip.name, clip);
		}

		Debug.Log("Loaded audio clips: " + clips.Length);

		me = this;
	}

	public static void StopAll(){
		foreach(AudioSource a_s in me.sources){
			a_s.Stop();
		}
	}

	public static AudioClip GetAC(string name){
		if (me.clip_names.ContainsKey(name)) return me.clip_names[name];
		else return null;
	}

	public static void StopMusic(){
		me.musicVoice.Stop();
	}

	public static void PlayMusic(string file){
		if (!me.clip_names.ContainsKey(file)) return;
		AudioClip music = me.clip_names[file];
		if (me.musicVoice.clip != music){
			me.musicVoice.clip = music;
			me.musicVoice.volume = 0.2f;
			me.musicVoice.Play();
		}
	}

	public static void PlaySound(string sound_name){
		PlaySound(sound_name, 1f, false);
	}
	public static void PlaySound(string sound_name, float time_stretch){
		PlaySound(sound_name, time_stretch, false);
	}
	public static void PlaySound(string sound_name, float time_stretch, bool restart){
		PlaySound(sound_name, time_stretch, restart, 1f);
	}
	public static void PlaySound(string sound_name, float time_stretch, bool restart, float volume){
		PlaySound(sound_name, time_stretch, restart, volume, false);
	}
	public static AudioSource PlaySound(string sound_name, float time_stretch, bool restart, float volume, bool loop){
		if (!me.clip_names.ContainsKey(sound_name)) return null;
		AudioSource new_source;
		if (!me.playing_sources.ContainsKey(sound_name) || restart){
			new_source = GetUnusedSource();
			if(!restart)
			me.playing_sources.Add(sound_name, new_source);
		}
		else{
			new_source = me.playing_sources[sound_name];
			if (new_source.isPlaying && restart == false){
				if(!new_source.isPlaying) new_source.Play();
				return me.playing_sources[sound_name];
			}
		}
		new_source.volume = (volume*sfx_volume);
		new_source.pitch = 1f*time_stretch;
		new_source.clip = me.clip_names[sound_name];
		new_source.Play();
		new_source.loop = loop;
		return new_source;
	}

	public void PlayFile(AudioFile a_f){
		PlaySound(a_f.fileName, a_f.speed, true, a_f.volume, false);
	}

	public static void PlayMenuBlip(){
		AudioLoader.PlaySound("Select1.L", 1f, true, 0.5f);
	}
	public static void PlayMenuSelect(){
		AudioLoader.PlaySound("slow_select", 1f, true,  0.5f);
	}
	public static void PlayMenuCancel(){
		AudioLoader.PlaySound("slow_backselect", 1f, true,  0.5f);
	}
	public static void PlayTextBoxSound(){
		AudioLoader.PlaySound("short_blip", (1f + (Random.value * 0.1f)) * voice_mod, true, 0.5f);
	}

	static AudioSource GetUnusedSource(){
		foreach(AudioSource a_s in me.sources){
			if(a_s != null && !a_s.isPlaying){
				return a_s;
			}
		}

		AudioSource new_source = me.gameObject.AddComponent<AudioSource>();
		me.sources.Add(new_source);
		return new_source;
	}
}

[System.Serializable]
public class AudioFile{
	public string fileName;
	public float volume;
	public float speed;
}