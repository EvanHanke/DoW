﻿using UnityEngine;

[CreateAssetMenu]
public class ViroMusic : ScriptableObject {
	public float set_speed = 0f;
	public AudioClip melody, decayHarm, growthHarm, rhythm;

}
