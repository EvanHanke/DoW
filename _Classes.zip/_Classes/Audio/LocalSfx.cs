﻿using UnityEngine;
using System.Collections.Generic;

public static class LocalSfx{

	public static void PlayFx(Transform t, AudioClip a_c, bool loop){
		PlayFx(t, a_c, loop, 1f);
	}
	public static AudioSource PlayFx(Transform t, AudioClip a_c, bool loop, float v){
		return PlayFx(t, a_c, loop, v, 1f);
	}
	//looks for an available audio source and plays a local clip
	public static AudioSource PlayFx(Transform t, AudioClip a_c, bool loop, float v_mod, float speed){
		AudioSource[] a_ss = t.GetComponents<AudioSource>();
		AudioSource available = null;
		foreach(AudioSource a_s in a_ss){
			if((!a_s.isPlaying)){
				available = a_s;
				break;
			}
		}
		if (available == null){
			available = t.gameObject.AddComponent<AudioSource>();
		}

		available.loop = loop;
		available.pitch = speed;
		SetAudioSource(available, a_c, v_mod);
		available.Play();
		return available;
	}

	public static void SetAudioSource(AudioSource a_s, AudioClip a_c, float v){
		a_s.clip = a_c;
		a_s.spatialize = true;

		a_s.spatialBlend = 1.0f;
		a_s.volume = AudioLoader.sfx_volume * v;
		a_s.rolloffMode = AudioRolloffMode.Custom;
		AudioSource curve = GameObject.Find("LocalSFXModel").GetComponent<AudioSource>();
		a_s.maxDistance = curve.maxDistance;
		a_s.SetCustomCurve(AudioSourceCurveType.CustomRolloff, curve.GetCustomCurve(AudioSourceCurveType.CustomRolloff));
	}

	public static void PlayAudioFile(AudioFile a_f, Transform t){
		AudioClip c= AudioLoader.GetAC(a_f.fileName);
		PlayFx(t, c, false, a_f.volume, a_f.speed);
	}
}
