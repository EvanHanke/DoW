﻿using UnityEngine;

public class MusicLoader : MonoBehaviour {

	public float volume = 0.3f;
	public float speedMod = 1f;
	public static MusicLoader me;
	ViroMusic currentVM;
	AudioSource[] chans;
	AudioEchoFilter echo;
	float[] targetVolumes;
	float targetSpeed;
	float lerp = 0f;
	public float ride_speed = 0f;

	public bool muted = false;
	bool fadeOut, fadeIn;
	float fade_time = 1f;
	delegate void OnFade();
	OnFade onOut;

	public void Toggle(){
		muted = !muted;
		if(muted) StopMusic();
		else StartMusic();
	}

	public void Awake(){
		chans = new AudioSource[4];
		targetVolumes = new float[4];
		for(int i = 0; i < 4; i++){
			chans[i] = gameObject.AddComponent<AudioSource>();
			chans[i].loop = true;
			chans[i].volume = 0f;
			targetVolumes[i] = 0f;
		}

		targetSpeed = 1f;

		//echo = gameObject.AddComponent<AudioEchoFilter>();
		gameObject.AddComponent<AudioChorusFilter>();
		me = this;

		fadeOut = fadeIn = false;
		onOut = Check;
	}

	public void StopMusic(){
		foreach(AudioSource a_s in chans){
			a_s.Stop();
		}
	}
	public void StartMusic(){
		if(!muted)
		foreach(AudioSource a_s in chans){
			a_s.Play();
		}
	}

	void Start(){
		//Check();
		UpdateEnvironmentMusic();
	}

	void Update(){
		if(fadeOut){
			if(FadeOut()){
				onOut();
				fadeOut = false;
				fadeIn = true;
			}
		}
		else if (fadeIn){
			if (FadeIn()){
				fadeIn = false;
			}
		}
		if(speedMod != targetSpeed+ride_speed){
			if(lerp == 0f) lerp = Time.time;
			for(int i= 0; i < 4; i++){
				speedMod = Mathf.Lerp(speedMod, targetSpeed+ride_speed, (Time.time - lerp) / 500f);
				chans[i].pitch = speedMod;
			}
		}

	}

	public void UpdateEnvironmentMusic(){
		if(!muted){
			Check();
			fadeOut = true;
		}
	}

	public bool FadeOut(){
		//Debug.Log("fadeout");
		bool a = false;

		float delta = (fade_time*Time.deltaTime);
		foreach(AudioSource chan in chans){
			//Debug.Log(chan.volume);
			chan.volume -= delta*volume;
			if(chan.volume <= 0f) chan.volume = 0f;
			else a = true;
		}


		return !a;
	}
	public bool FadeIn(){
		//Debug.Log("fadein");
		bool a = false;
		float delta = (fade_time*Time.deltaTime);
		for(int i = 0; i < 4; i++){
			chans[i].volume += delta*volume;
			if(chans[i].volume > targetVolumes[i]) chans[i].volume = targetVolumes[i];
			else a = true;
		}
		return !a;
	}

	public void SetSpeed(float s){
		for(int i = 0; i < 4; i++){
			targetSpeed = s;
		}
	}

	public void Check(){
		ViroMusic vm = Zone.currentZone.vMusic;
		//grab correct music object
		if(vm!=null && vm !=currentVM){
			currentVM = vm;

			chans[0].clip = vm.melody;
			chans[1].clip = vm.growthHarm;
			chans[2].clip = vm.decayHarm;
			chans[3].clip = vm.rhythm;

			foreach(AudioSource chan in chans){
				chan.Play();
			}
		}

		//set track volumes
		targetVolumes[0] = volume;
		int health = ViroTrack.me.TotalzHealth(Zone.currentZone);
		//Debug.Log(health + " zone health");
		if (health > 0){
			targetVolumes[1] = volume;
			targetVolumes[2] = 0f;
		}
		else if (health < 0) {
			targetVolumes[2] = volume;
			targetVolumes[1] = 0f;
		}
		else if (health == 0){
			targetVolumes[1] = 0f;
			targetVolumes[2] = 0f;
		}

		//set track speeds
		int vis = VisitorSpawner.me.spawnedVisitors;
		if(vis > 0){
			targetVolumes[3] = volume * (Mathf.Clamp((float) vis / 10f, 0.1f, 1f));
		}
		else{
			targetVolumes[3] = 0f;
		}

		if(vm!= null && vm.set_speed != 0f) SetSpeed(vm.set_speed);
		else SetSpeed(Mathf.Clamp((float) health / 100f, 0.4f, 1.1f));

	}



}
